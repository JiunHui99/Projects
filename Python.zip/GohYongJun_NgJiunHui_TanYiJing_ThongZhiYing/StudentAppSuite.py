import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk, simpledialog, filedialog
import math
import json
import os
import re
import random
from os.path import join, dirname, abspath

class BaseApp:
    def __init__(self, main_window):
        self.main_window = main_window
        
    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        window.geometry(f"{width}x{height}+{x}+{y}")

    def on_exit(self):
        pass
    
    def back_to_main_menu(self, window=None):
        self.on_exit()
        if window:
            window.destroy()
        elif hasattr(self, "root") and self.root:
            self.root.destroy()
        elif hasattr(self, "window") and self.window:
            self.window.destroy()
        self.main_window.deiconify()

    def bind_mousewheel(self, widget, canvas):
        def _on_mousewheel(event):
            if os.name == 'nt':
                canvas.yview_scroll(-1 * int(event.delta / 120), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
    
# ======================== MAIN MENU CLASS ========================
class StudyAppSuite(BaseApp):
    def __init__(self):
        self.menu = tk.Tk()
        self.menu.title("TARCIAN - Study App Suite")
        self.menu.config(bg="lightyellow")
        self.center_window(self.menu, 700, 600)
        self.create_main_menu()

    def create_main_menu(self):
        for widget in self.menu.winfo_children():
            widget.destroy()

        header_frame = tk.Frame(self.menu, bg="powderblue", height=80)
        header_frame.pack(fill="x", pady=0)
        header_frame.pack_propagate(False) 
            
        title_label = tk.Label(
            header_frame, 
            text="Tarcian Study Life ˙ᵕ˙",
            pady=10, 
            relief="solid", bd=0.5,
            padx=100,
            font=("Helvetica", 24, "bold"), 
            bg="powderblue", 
            fg="black"
        )
        title_label.pack(pady=10)
        
        subtitle_label = tk.Label(
            self.menu, 
            text="Choose One For Today", 
            font=("Courier New", 10), 
            bg="lightyellow", 
            fg="#000000",
            pady=5
        )
        subtitle_label.pack(pady=5)

        button_frame = tk.Frame(self.menu, bg="lightyellow")
        button_frame.pack(pady=10)
        
        # Pomodoro Timer Button
        pomodoro_btn = tk.Button(
            button_frame,
            text="Pomodoro Timer\n🍅",
            font=("Courier New", 13, "bold"),
            bg="tomato",
            fg="black",
            width=30,
            pady=5,
            command=self.launch_pomodoro,
            relief="sunken",
            bd=2
        )
        pomodoro_btn.pack(pady=8)
        
        # Learning Forum Button
        forum_btn = tk.Button(
            button_frame,
            text="Peer Learning Forum\n💬",
            font=("Courier New", 13, "bold"),
            bg="orchid1",
            fg="black",
            width=30,
            pady=5,
            command=self.launch_forum,
            relief="sunken",
            bd=2
        )
        forum_btn.pack(pady=8)

        # Flashcard Quizzer Button
        flashcard_btn = tk.Button(
            button_frame,
            text="Flashcard Quizzer\n🧠",
            font=("Courier New", 13, "bold"),
            bg="lightblue",
            fg="black",
            width=30,
            pady=5,
            command=self.launch_flashcard,
            relief="sunken",
            bd=2
        )
        flashcard_btn.pack(pady=8)

        # GPA Calculator Button
        gpa_btn = tk.Button(
            button_frame,
            text="GPA Calculator\n🎓",
            font=("Courier New", 13, "bold"),
            bg="lightgreen",
            fg="black",
            width=30,
            pady=5,
            command=self.launch_gpa,
            relief="sunken",
            bd=2
        )
        gpa_btn.pack(pady=8)

        exit_btn = tk.Button(
            button_frame,
            text="Exit\n🚪",
            font=("Courier New", 11, "bold"),
            pady=5,
            bg="springgreen",
            fg="black",
            width=15,
            command=self.menu.quit,
            relief="sunken",
            bd=2
        )
        exit_btn.pack(pady=8)
        
    def launch_pomodoro(self):
        self.menu.withdraw()
        pomodoro_app = PomodoroApp(self.menu)
        
    def launch_forum(self):
        self.menu.withdraw()
        forum_app = ForumApp(self.menu)

    def launch_flashcard(self):
        self.menu.withdraw()
        flashcard_window = tk.Toplevel()
        flashcard_window.protocol("WM_DELETE_WINDOW", lambda: self.close_and_return(flashcard_window))
        flashcard_app = FlashcardGUI(flashcard_window, self.menu)

    def launch_gpa(self):
        self.menu.withdraw()
        gpa_window = tk.Toplevel()
        gpa_window.protocol("WM_DELETE_WINDOW", lambda: self.close_and_return(gpa_window))
        gpa_app = GPACalculator(gpa_window, self.menu)

    def close_and_return(self, window):
        window.destroy()
        self.menu.deiconify()
        
    def run(self):
        self.menu.mainloop()

# ======================== POMODORO TIMER APPLICATION ========================
class PomodoroData:
    file_name = "pomodoro_data.json"

    def __init__(self, work=25, short_break=5, long_break=15, history="", session_logs=None):
        self.work = work
        self.short_break = short_break
        self.long_break = long_break
        self.history = history  # Completion Record
        self.session_logs = session_logs if session_logs is not None else []

    def to_dict(self):
        return {
            "work": self.work,
            "short_break": self.short_break,
            "long_break": self.long_break,
            "history": self.history,
            "session_logs": self.session_logs
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            work=data.get("work", 25),
            short_break=data.get("short_break", 5),
            long_break=data.get("long_break", 15),
            history=data.get("history", ""),
            session_logs=data.get("session_logs", [])
        )

    def save_to_file(self):
        try:
            file_path = join(dirname(abspath(__file__)), self.file_name)
            with open(file_path, "w") as file:
                json.dump(self.to_dict(), file, indent=2)
            print("Pomodoro data saved.")
        except Exception as e:
            print(f"Error saving data: {e}")

    def load_from_file(self):
        try:
            file_path = join(dirname(abspath(__file__)), self.file_name)
            with open(file_path, "r") as file:
                data = json.load(file)
            loaded_data = PomodoroData.from_dict(data)
            self.work = loaded_data.work
            self.short_break = loaded_data.short_break
            self.long_break = loaded_data.long_break
            self.history = loaded_data.history
            print("Pomodoro data loaded.")
        except FileNotFoundError:
            print("No saved Pomodoro data found. Using defaults.")
        except Exception as e:
            print(f"Error loading data: {e}")

class PomodoroApp(BaseApp):
    def __init__(self, main_window):
        super().__init__(main_window)
        self.reps = 0
        self.timer = None
        self.paused = False
        self.remaining_time = 0
        self.pomodoro_data = PomodoroData()
    
        self.window = tk.Toplevel()
        self.window.title("Study Pomodoro Timer")
        self.window.geometry("800x600")
        self.window.config(bg="lightyellow")
        self.window.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.center_window(self.window, 800, 600)
        
        self.create_ui()
        self.load_data()
        
    def create_ui(self):
        main_frame = tk.Frame(self.window, bg="lightyellow")
        main_frame.pack(fill="x")

        self.title_label = tk.Label(main_frame, text="Timer ", fg="black", bg="powderblue", font=("Helvetica", 30,"bold"),pady=15)
        self.title_label.pack(fill="x")

        self.canvas = tk.Canvas(main_frame, width=240, height=180, bg="lightyellow", highlightthickness=0)
        self.timer_text = self.canvas.create_text(120, 90, text="00:00", fill="black", font=("Courier", 35, "bold"))
        self.canvas.pack()

        input_frame = tk.Frame(main_frame, bg="lightyellow",bd=1,relief="solid",padx=30,pady=5)
        input_frame.pack(pady=10)

        tk.Label(input_frame, text="Work (min):", bg="lightyellow",fg="black",padx=10,pady=5).grid(row=0, column=0, sticky="e", padx=5, pady=2)
        self.work_entry = tk.Entry(input_frame, width=15,)
        self.work_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(input_frame, text="Short Break (min):", bg="lightyellow",fg="black",padx=10,pady=5).grid(row=1, column=0, sticky="e", padx=5, pady=2)
        self.short_break_entry = tk.Entry(input_frame, width=15)
        self.short_break_entry.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(input_frame, text="Long Break (min):", bg="lightyellow",fg="black",padx=10,pady=5).grid(row=2, column=0, sticky="e", padx=5, pady=2)
        self.long_break_entry = tk.Entry(input_frame, width=15)
        self.long_break_entry.grid(row=2, column=1, padx=5, pady=5)

        button_frame = tk.Frame(main_frame, bg="lightyellow")
        button_frame.pack(pady=10)

        start_button = tk.Button(button_frame, text="Start", command=self.start_button_clicked, highlightthickness=0, width=8,pady=3,bg="springgreen")
        self.pause_button = tk.Button(button_frame, text="Pause", command=self.toggle_pause, highlightthickness=0, width=8,pady=3,bg="indianred1")
        skip_button = tk.Button(button_frame, text="Skip", command=self.skip_section, highlightthickness=0, width=8,pady=3,bg="lavender")
        reset_button = tk.Button(button_frame, text="Reset", command=self.reset_timer, highlightthickness=0, width=8,pady=3,bg="skyblue")

        start_button.pack(side="left", padx=10)
        self.pause_button.pack(side="left", padx=10)
        skip_button.pack(side="left", padx=10)
        reset_button.pack(side="left", padx=10)

        complete_title = tk.Label(main_frame, text="Complete Sessions", fg="black", bg="lightyellow", font=("Courier", 16, "bold", "underline"))
        complete_title.pack(pady=(10, 5))

        self.check_label = tk.Label(main_frame, fg="green", bg="lightyellow", font=("Courier", 20))
        self.check_label.pack()
    
        back_button = tk.Button(main_frame, text="← Back To Menu", command=self.back_to_menu, 
                               bg="springgreen", fg="black", font=("Courier New", 10))
        back_button.pack(pady=10)

    def validate_input(self, entry):
        """Force user to enter a positive integer before proceeding."""
        while True:
            try:
                value = int(entry.get())
                if value > 0:
                    return value
                else:
                    messagebox.showerror("Invalid Input", "Value must be greater than 0.")
                    entry.delete(0, tk.END)
                    entry.focus()
                    return None
            except ValueError:
                messagebox.showerror("Input Error", "Please enter a number.")
                entry.delete(0, tk.END)
                entry.focus()
                return None

    def reset_timer(self):
        if self.timer:
            self.window.after_cancel(self.timer)
        self.timer = None
        self.reps = 0
        self.paused = False
        self.remaining_time = 0
        self.work_sessions = 0
        self.short_break_sessions = 0
        self.long_break_sessions = 0

        # Clear the log and history of pomodoro_data
        self.pomodoro_data.session_logs.clear()
        self.pomodoro_data.history = ""

        self.pause_button.config(text="Pause")
        self.canvas.itemconfig(self.timer_text, text="00:00")
        self.title_label.config(text="Timer")
        self.check_label.config(text="")

        self.save_data()

    def skip_section(self):
        if self.timer is None and not self.paused:
            messagebox.showwarning("No Active Timer", "No timer is currently running to skip.")
            return

        if self.timer:
            self.window.after_cancel(self.timer)
        self.timer = None
        self.paused = False
        self.remaining_time = 0
        self.pause_button.config(text="Pause")

        if self.reps % 2 == 1:
            current_marks = self.check_label.cget("text")
            self.check_label.config(text=current_marks + "✔")

        self.save_data()
        self.start_timer()

    def start_timer(self):
        if self.timer is not None or self.paused:
            return

        self.reps += 1  # Each call increases the count

        work_sec = self.work_min * 60
        short_break_sec = self.short_break_min * 60
        long_break_sec = self.long_break_min * 60

        self.session_num = (self.reps + 1) // 2

        if self.reps % 8 == 0:
            self.pomodoro_data.session_logs.append(f"Long Break {self.reps // 8} started") 
            self.count_down(long_break_sec)
            self.title_label.config(text="Long Break")
        elif self.reps % 2 == 0:
            self.pomodoro_data.session_logs.append(f"Short Break {self.reps // 2} started")
            self.count_down(short_break_sec)
            self.title_label.config(text="Short Break")
        else:
            session_num = (self.reps + 1) // 2
            self.pomodoro_data.session_logs.append(f"Work Session {session_num} started")  # Begin Log
            self.count_down(work_sec)
            self.title_label.config(text=f"Work")

    def start_button_clicked(self):
        """Triggered when Start button is pressed."""
        work_min = self.validate_input(self.work_entry)
        short_break_min = self.validate_input(self.short_break_entry)
        long_break_min = self.validate_input(self.long_break_entry)

        # If one of the inputs is invalid, the startup is aborted
        if not all([work_min, short_break_min, long_break_min]):
            return

        # The input will be assigned and started only if it is legal
        self.work_min = work_min
        self.short_break_min = short_break_min
        self.long_break_min = long_break_min
        self.start_timer()

    def count_down(self, count):
        """Handles the timer countdown."""
        self.remaining_time = count  # Remaining time for each update
        minutes = math.floor(count / 60)
        seconds = count % 60
        self.canvas.itemconfig(self.timer_text, text=f"{minutes:02d}:{seconds:02d}")

        if count > 0:
            self.timer = self.window.after(1000, self.count_down, count - 1)
        else:
            self.timer = None  

            message = ""

            if self.reps % 8 == 0:
                message = "Long break completed! Click OK to start a work session."
                self.pomodoro_data.session_logs.append(f"Long Break {self.reps // 8} completed")
            elif self.reps % 2 == 0:
                break_num = self.reps // 2
                message = "Short break completed! Click OK to start a work session."
                self.pomodoro_data.session_logs.append(f"Short Break {break_num} completed")
            else:
                self.current_marks = self.check_label.cget("text")
                self.check_label.config(text=self.current_marks + "✔")
                session_num = (self.reps + 1) // 2
                message = "Work session completed! Click OK to start your break."
                self.pomodoro_data.session_logs.append(f"Work Session {session_num} completed")

            messagebox.showinfo("Session Complete", message)

            self.save_data()
            self.start_timer()

    def toggle_pause(self):
        # Prevent clicking pause before the timer starts
        if self.timer is None and self.remaining_time == 0:
            messagebox.showwarning("No Active Timer", "No timer is currently running to pause or resume.")
            return

        if self.paused:
            self.paused = False
            self.pause_button.config(text="Pause")
            self.count_down(self.remaining_time)
        else:
            self.paused = True
            self.pause_button.config(text="Resume")
            if self.timer:
                self.window.after_cancel(self.timer)
                self.timer = None

    def save_data(self):
        try:
            self.pomodoro_data.work = int(self.work_entry.get())
            self.pomodoro_data.short_break = int(self.short_break_entry.get())
            self.pomodoro_data.long_break = int(self.long_break_entry.get())
            self.pomodoro_data.history = self.check_label.cget("text")
            self.pomodoro_data.save_to_file()
        except ValueError:
            pass

    def load_data(self):
        self.pomodoro_data.load_from_file()
        self.work_entry.insert(0, str(self.pomodoro_data.work))
        self.short_break_entry.insert(0, str(self.pomodoro_data.short_break))
        self.long_break_entry.insert(0, str(self.pomodoro_data.long_break))
        self.check_label.config(text=self.pomodoro_data.history)

    def on_closing(self):
        self.save_data()
        self.window.destroy()
        self.main_window.deiconify()  # Show main menu again
        
    def back_to_menu(self):
        self.save_data()
        self.window.destroy()
        self.main_window.deiconify()  # Show main menu again

# ======================== LEARNING FORUM APPLICATION ========================
class ForumDataManage:
    def __init__(self):
        self.USER_FILE = "users.json"
        self.POST_FILE = "posts.json"
    
    def load_users(self):
        if os.path.exists(self.USER_FILE):
            with open(self.USER_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def save_users(self, users):
        with open(self.USER_FILE, "w", encoding="utf-8") as f:
            json.dump(users, f, indent=2, ensure_ascii=False)

    def load_posts(self):
        if os.path.exists(self.POST_FILE):
            with open(self.POST_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def save_posts(self, posts):
        with open(self.POST_FILE, "w", encoding="utf-8") as f:
            json.dump(posts, f, indent=2, ensure_ascii=False)

    #================== Email Validation ==========================
    def valid_email(self, email):
        pattern = r'^[\w\.-]+@(gmail\.com|email\.com|yahoo\.com)$'
        return re.match(pattern, email) is not None

class ForumApp(BaseApp):
    def __init__(self, main_window):
        super().__init__(main_window)
        self.data_manager = ForumDataManage()
        self.current_user = None
        self.users = {}
        self.posts = []
        
        self.load_data()
        self.login_page()
    
    def load_data(self):
        self.users = self.data_manager.load_users()
        self.posts = self.data_manager.load_posts()

    # ================== Register/Login =======================
    def register(self, window, email, password, nickname):
        email = (email or "").strip()
        password = (password or "").strip()
        nickname = (nickname or "").strip().upper()

        if not email or not password or not nickname:
            messagebox.showerror("Error", "Information Not Done!")
            return
        if not self.data_manager.valid_email(email):
            messagebox.showerror("Error", "Email format not acceptable! ")
            return
        if email in self.users:
            messagebox.showerror("Error", "Email already exist!")
            return

        self.users[email] = {"password": password, "nickname": nickname}
        self.data_manager.save_users(self.users)
        messagebox.showinfo("Success", "Successfully Register, use email to login.")
        window.destroy()

    def login(self, window, email, password):
        if email not in self.users or self.users[email]["password"] != password:
            messagebox.showerror("Error", "Email or Password incorrect!")
            return

        if not email or not password:
            messagebox.showerror("Error", "Information Not Done!")
            return
            
        self.current_user = {"email": email, "nickname": self.users[email]["nickname"]}
        window.destroy()
        self.forum_page()

    def register_page(self):
        reg_win = tk.Toplevel()
        reg_win.title("Register Section")
        reg_win.configure(bg="lightyellow")
        self.center_window(reg_win, 300, 230)

        tk.Label(reg_win, text="Enter your Email:", bg="#fcd2b2",fg="black", font=("Courier New", 10, "normal")).pack(pady=10)
        email_entry = tk.Entry(reg_win, width=20, bd=1, relief="groove", bg="#fffaf0", fg="#474747", insertbackground="grey")
        email_entry.pack()

        tk.Label(reg_win, text="Enter your Password:", bg="#fcd2b2", fg="black", font=("Courier New", 10, "normal")).pack(pady=10)
        pw_entry = tk.Entry(reg_win, show="*", width=20, bd=1, relief="groove", bg="#fffaf0", fg="#474747", insertbackground="grey")
        pw_entry.pack()

        tk.Label(reg_win, text="Enter your Name:", bg="#fcd2b2",fg="black", font=("Courier New", 10, "normal")).pack(pady=10)
        nick_entry = tk.Entry(reg_win, width=20, bd=1, relief="groove", bg="#fffaf0", fg="#474747", insertbackground="grey")
        nick_entry.pack()

        tk.Button(
            reg_win, text="Done", bg="springgreen", fg="#000000", font=("Courier New", 10, "bold"),
            command=lambda: self.register(reg_win, email_entry.get(), pw_entry.get(), nick_entry.get())
        ).pack(pady=10)

    def login_page(self):
        login_win = tk.Toplevel()
        login_win.title("Login Section")
        login_win.configure(bg="lightyellow")
        login_win.protocol("WM_DELETE_WINDOW", lambda: self.back_to_main_menu(login_win))
        self.center_window(login_win, 350, 280)

        header = tk.Frame(login_win, bg="powderblue", height=40)
        header.pack(fill="x")

        back_btn = tk.Button(
            header,
            text="← Back To Menu",
            bg="lightcoral",
            fg="black",
            pady=1,
            font=("Courier New", 10, "normal"),
            command=self.back_to_main_menu
        )
        back_btn.pack(side="left", padx=5, pady=3)

        tk.Label(login_win, text="Enter your Email:", bg="#fcd2b2",fg="black",font=("Courier New", 10, "normal")).pack(pady=10)
        email_entry = tk.Entry(login_win, bd=1, relief="groove", width=20, bg="#fffaf0", fg="#474747", insertbackground="grey")
        email_entry.pack(pady=5)

        tk.Label(login_win, text="Enter your Password:", bg="#fcd2b2",fg="black", font=("Courier New", 10, "normal")).pack(pady=10)
        pw_entry = tk.Entry(login_win, show="*", bd=1, relief="groove", bg="#fffaf0", fg="#474747", insertbackground="grey")
        pw_entry.pack(pady=5)

        tk.Button(
            login_win, text="Login", bg="springgreen", fg="black", font=("Courier New", 10, "bold"),
            command=lambda: self.login(login_win, email_entry.get(), pw_entry.get())
        ).pack(pady=5)

        tk.Button(
            login_win, text="Register Here", bg="lightblue", fg="black", font=("Courier New", 10, "normal"),
            command=lambda: self.register_page()
        ).pack(pady=5)

    # ============== Main Forum Page ==============
    def forum_page(self):
        forum = tk.Toplevel()
        forum.title("Peer Learning Forum")
        forum.protocol("WM_DELETE_WINDOW", lambda: self.back_to_main_menu(forum))
        forum.config(bg="lightyellow")
        self.center_window(forum, 800, 600)

        header = tk.Frame(forum, bg="lightblue", height=50)
        header.pack(fill="x")
        tk.Label(header, text="Welcome to Peer Learning Forum ˙ᵕ˙", pady=10, bg="lightblue", font=("Helvetica", 14, "bold")).pack(side="left", padx=10, pady=10)
        
        tk.Button(header, text="← Back To Menu", bg="orchid2", fg="black", command=lambda: self.back_to_main_menu(forum)).pack(side="right", padx=5)
        tk.Button(header, text="+ Add Post", bg="lightgreen", command=lambda: self.add_post_window(content_frame)).pack(side="right", padx=10)
        tk.Button(header, text="Logout", bg="lightpink", command=lambda: [forum.destroy(), self.login_page()]).pack(side="right", padx=8)

        canvas = tk.Canvas(forum, bg="lightyellow")
        scrollbar = tk.Scrollbar(forum, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg="lightyellow")

        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.bind_mousewheel(forum, canvas)
        content_frame = scroll_frame
        self.view_posts(content_frame)
        
    # ============== Forum Function ==============
    def add_post_window(self, container):
        def submit():
            content = text.get("1.0", "end").strip()
            if not content:
                messagebox.showwarning("Error", "Content can't be empty!")
                return
            post = {
                "author": self.current_user["nickname"],
                "content": content,
                "comments": [],
                "likes": 0
            }
            self.posts.insert(0, post)
            self.data_manager.save_posts(self.posts)
            self.view_posts(container)
            addpost.destroy()

        addpost = tk.Toplevel()
        addpost.title("Add Post")
        addpost.configure(bg="#f7e8e8")
        self.center_window(addpost, 400, 300)

        tk.Label(addpost, text="Whats For Today:", bg="lightsalmon", font=("Courier New", 10, "bold")).pack(pady=15)
        text = scrolledtext.ScrolledText(addpost, wrap="word", width=40, height=8, relief="solid", bd=1, fg="#000000", bg="#ffffff", font=("Courier New", 9, "bold"))
        text.pack(pady=5)

        tk.Button(addpost, text="Submit", bg="springgreen", fg="#000000", font=("Courier New", 9, "bold"), command=submit).pack(pady=5)

    def add_comment(self, post, container, comment_entry):
        comment_text = comment_entry.get().strip()
        if not comment_text:
            return
        post["comments"].append({"author": self.current_user["nickname"], "content": comment_text, "likes": 0})
        comment_entry.delete(0, tk.END)
        self.data_manager.save_posts(self.posts)
        self.view_posts(container)

    def like_post(self, post, container):
        post["likes"] += 1
        self.data_manager.save_posts(self.posts)
        self.view_posts(container)

    def view_posts(self, container):
        for widget in container.winfo_children():
            widget.destroy()

        for post in self.posts:
            postcard = tk.Frame(container, bd=1, relief="groove", padx=40, pady=20, bg="#ffebeb")
            postcard.pack(padx=110,pady=15, fill="x", expand=True)

            tk.Label(postcard, text=f"♾ {post['author']} :", font=("Helvetica", 9, "bold"), bg="#f4ff5f").pack(anchor="w")
            tk.Label(postcard, text=post["content"], width=60, bg="#ffffff", pady=15, padx=10, bd=1, relief="solid", font=("Courier New", 10, "normal")).pack(anchor="w", pady=10)

            btn_frame = tk.Frame(postcard, bg="#ffebeb")
            btn_frame.pack(pady=2, fill="x")

            like_btn = tk.Button(btn_frame, text=f"❤︎{post['likes']}", bg="lightpink", command=lambda p=post: self.like_post(p, container))
            like_btn.pack(side="right", padx=5)

            comments_frame = tk.Frame(postcard, bg="#eebbbb", width=50)
            comments_frame.pack(fill="x", padx=5, pady=5)

            for c in post["comments"]:
                tk.Label(comments_frame, text=f"•‿• {c['author']} : {c['content']}", anchor="w", bg="#CEE7FB").pack(fill="x")

            comment_input_frame = tk.Frame(postcard, bg="#ffebeb")
            comment_input_frame.pack(fill="x", pady=3)

            comment_entry = tk.Entry(comment_input_frame, width=65, bg="#ffffff")
            comment_entry.pack(side="left", padx=15)

            tk.Button(comment_input_frame, text="Comment", bg="#d1ffc7", fg="#000000", font=("Courier New", 8, "normal"), 
                     command=lambda p=post, e=comment_entry: self.add_comment(p, container, e)).pack(side="left")

# ======================== FLASHCARD QUIZZER APPLICATION ========================
class SimpleFlashcard:
    def __init__(self, question, answer):
        self.question = question
        self.answer = answer
        # Initialize performance counters
        self.times_correct = 0
        self.times_wrong = 0
   
    def mark_correct(self):
        """Increment the 'correct' counter after a correct attempt."""
        self.times_correct += 1
   
    def mark_wrong(self):
        self.times_wrong += 1
   
    def get_accuracy(self):
        """
        Return accuracy percentage across attempts for this card.
        If never attempted, return 0 to avoid division by zero.
        """
        total_attempts = self.times_correct + self.times_wrong
        if total_attempts == 0:
            return 0
        else:
            return (self.times_correct / total_attempts) * 100

class FlashcardGUI(BaseApp):
    def __init__(self, root, main_window):
        super().__init__(main_window)
        self.root = root
        self.root.title("🧠 Flashcard Quizzer")
        self.root.configure(bg="#8bb1f9")
        self.center_window(root, 800, 650)
       
        self.flashcards = []
        self.load_flashcards()
       
        self.create_widgets()
       
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
   
    def create_widgets(self):
        title_label = tk.Label(self.root, text="🧠 Flashcard Quizzer",
                              font=("Helvetica", 40, "bold"), bg="#8bb1f9", fg='#2c3e50')
        title_label.pack(pady=20)
       
        button_frame = tk.Frame(self.root, bg='#8bb1f9')
        button_frame.pack(pady=30)
       
        button_style = {"font": ("Arial", 15), "width": 20, "height": 2, "bg": "#2F71EA",
                       "fg": "white", "relief": "flat", "cursor": "hand2"}
       
        tk.Button(button_frame, text="📝 Add New Flashcard", command=self.add_flashcard,
                 **button_style).pack(pady=5)
        tk.Button(button_frame, text="👀 View All Flashcards", command=self.view_all_flashcards,
                 **button_style).pack(pady=5)
        tk.Button(button_frame, text="📚 Practice Mode", command=self.practice_flashcards,
                 **button_style).pack(pady=5)
        tk.Button(button_frame, text="🎯 Quiz Mode", command=self.take_quiz,
                 **button_style).pack(pady=5)
        tk.Button(button_frame, text="📊 View Statistics", command=self.show_statistics,
                 **button_style).pack(pady=5)
        
        tk.Button(button_frame, text="← Back To Menu", command=lambda: self.back_to_main_menu(self.root),
                 bg="steelblue4", fg="white", font=("Arial", 13), padx=5,pady=5).pack(pady=10)
       
        self.status_label = tk.Label(self.root, text=f"Total flashcards: {len(self.flashcards)}",
                                   font=("Arial", 15, "bold"), bg="#8bb1f9", fg='#2c3e50')
        self.status_label.pack(pady=5)

   
    def load_flashcards(self):
        filename = "my_flashcards.json"
        if os.path.exists(filename):
            try:
                with open(filename, 'r') as file:
                    data = json.load(file)
                    for card_data in data:
                        # Rehydrate SimpleFlashcard objects from stored dicts
                        card = SimpleFlashcard(card_data['question'], card_data['answer'])
                        card.times_correct = card_data['times_correct']
                        card.times_wrong = card_data['times_wrong']
                        self.flashcards.append(card)
            except:
                messagebox.showerror("Error", "Could not load saved flashcards!")
   
    def save_flashcards(self):
        filename = "my_flashcards.json"
        data = []
        for card in self.flashcards:
            card_data = {
                'question': card.question,
                'answer': card.answer,
                'times_correct': card.times_correct,
                'times_wrong': card.times_wrong
            }
            data.append(card_data)
       
        try:
            with open(filename, 'w') as file:
                json.dump(data, file, indent=2)
            return True
        except:
            messagebox.showerror("Error", "Could not save flashcards!")
            return False
   
    def add_flashcard(self):
        dialog = AddFlashcardDialog(self.root)
        self.root.wait_window(dialog.dialog)
       
        if dialog.result:
            question, answer = dialog.result
            new_card = SimpleFlashcard(question, answer)
            self.flashcards.append(new_card)
            self.update_status()
            messagebox.showinfo("Success", "Flashcard added successfully!")
   
    def view_all_flashcards(self):
        if not self.flashcards:
            messagebox.showinfo("Info", "You don't have any flashcards yet!")
            return
       
        ViewFlashcardsWindow(self.root, self.flashcards)
   
    def practice_flashcards(self):
        if not self.flashcards:
            messagebox.showinfo("Info", "You don't have any flashcards to practice!")
            return
       
        PracticeWindow(self.root, self.flashcards.copy())
        self.update_status()
   
    def take_quiz(self):
        if not self.flashcards:
            messagebox.showinfo("Info", "You don't have any flashcards for the quiz!")
            return

        max_questions = len(self.flashcards)
        num_questions = simpledialog.askinteger("Quiz Setup",
                                               f"How many questions? (1-{max_questions})",
                                               minvalue=1, maxvalue=max_questions)
        if num_questions:
            quiz_cards = random.sample(self.flashcards, num_questions)
            QuizWindow(self.root, quiz_cards)
            self.update_status()
   
    def show_statistics(self):
        if not self.flashcards:
            messagebox.showinfo("Info", "No flashcards to show statistics for!")
            return
       
        StatisticsWindow(self.root, self.flashcards)
   
    def update_status(self):
        self.status_label.config(text=f"Total flashcards: {len(self.flashcards)}")
   
    def on_closing(self):
        if self.save_flashcards():
            messagebox.showinfo("Saved", "Flashcards saved successfully!")
        self.root.destroy()
        self.main_window.deiconify()

class AddFlashcardDialog:
    def __init__(self, parent):
        self.result = None # Will hold the tuple if user confirms
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Add New Flashcard")
        self.center_window(self.dialog, 550, 400)
        self.dialog.configure(bg='#f0f0f0')
        self.dialog.transient(parent)
        self.dialog.grab_set()
    
        tk.Label(self.dialog, text="📝 Add New Flashcard", font=("Arial", 20, "bold"),
                bg="#f0f0f0").pack(pady=20)
       
        tk.Label(self.dialog, text="Question:", font=("Arial", 14), bg='#f0f0f0').pack(anchor='w', padx=20)
        self.question_entry = tk.Text(self.dialog, height=3, font=("Arial", 10))
        self.question_entry.pack(padx=20, pady=5, fill='x')
       
        tk.Label(self.dialog, text="Answer:", font=("Arial", 14), bg='#f0f0f0').pack(anchor='w', padx=20)
        self.answer_entry = tk.Text(self.dialog, height=3, font=("Arial", 10))
        self.answer_entry.pack(padx=20, pady=5, fill='x')
       
        button_frame = tk.Frame(self.dialog, bg='#f0f0f0')
        button_frame.pack(pady=20)
       
        tk.Button(button_frame, text="Add Flashcard", command=self.add_card,
                 bg='#27ae60', fg='white', font=("Arial", 12, "bold"), padx=20).pack(side='left', padx=5)
        tk.Button(button_frame, text="Cancel", command=self.cancel,
                 bg='#e74c3c', fg='white', font=("Arial", 12, "bold"), padx=20).pack(side='left', padx=5)
   
    def add_card(self):
        question = self.question_entry.get(1.0, tk.END).strip()
        answer = self.answer_entry.get(1.0, tk.END).strip()
       
        if not question or not answer:
            messagebox.showerror("Error", "Both question and answer are required!")
            return
       
        self.result = (question, answer)
        self.dialog.destroy()
   
    def cancel(self):
        self.dialog.destroy()
    
    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        window.geometry(f"{width}x{height}+{x}+{y}")

class ViewFlashcardsWindow:
    def __init__(self, parent, flashcards):
        self.window = tk.Toplevel(parent)
        self.window.title("All Flashcards")
        self.window.geometry("700x500")
        self.center_window(self.window, 700, 500)
        self.window.configure(bg="#dd8787")
       
        tk.Label(self.window, text="👀 All Your Flashcards", font=("Arial", 30, "bold"),
                bg="#dd8787").pack(pady=10)
       
        canvas = tk.Canvas(self.window, bg='#ef9d9d')
        scrollbar = ttk.Scrollbar(self.window, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg='#ef9d9d')
       
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Add a 'card' panel for each flashcard in the list
        for i, card in enumerate(flashcards, 1):
            card_frame = tk.Frame(scrollable_frame, bg="#f0f0f0", relief='solid', bd=2)
            card_frame.pack(fill='x', padx=20, pady=5)
           
            tk.Label(card_frame, text=f"Card {i}", font=("Arial", 15, "bold"),
                    bg='#f0f0f0', fg='#2c3e50').pack(anchor='w', padx=10, pady=5)
           
            tk.Label(card_frame, text=f"Q: {card.question}", font=("Arial", 12),
                    bg='#f0f0f0', wraplength=600, justify='left').pack(anchor='w', padx=20)
           
            tk.Label(card_frame, text=f"A: {card.answer}", font=("Arial", 12),
                    bg='#f0f0f0', fg='#27ae60', wraplength=600, justify='left').pack(anchor='w', padx=20)
           
            accuracy = card.get_accuracy()
            stats_text = f"Stats: {accuracy:.1f}% correct ({card.times_correct} right, {card.times_wrong} wrong)"
            tk.Label(card_frame, text=stats_text, font=("Arial", 10, "bold"),
                    bg='#f0f0f0', fg="#6a7273").pack(anchor='w', padx=20, pady=(0, 10))
       
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
            
    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        window.geometry(f"{width}x{height}+{x}+{y}")

class PracticeWindow:
    def __init__(self, parent, flashcards):
        # Work on a shuffled copy so original order is preserved
        self.flashcards = flashcards
        random.shuffle(self.flashcards)
        self.current_index = 0
        self.correct_count = 0
        self.show_answer = False
       
        self.window = tk.Toplevel(parent)
        self.window.title("Practice Mode")
        self.window.geometry("600x400")
        self.center_window(self.window, 600, 400)
        self.window.configure(bg="#b0e594")
       
        self.create_practice_widgets()
        self.show_question()
   
    def create_practice_widgets(self):
        tk.Label(self.window, text="📚 Practice Mode", font=("Arial", 40, "bold"),
                bg='#b0e594', fg='#2c3e50').pack(pady=20)
       
        self.progress_label = tk.Label(self.window, text="", font=("Arial", 10, "bold"), bg="#b0e594")
        self.progress_label.pack()
       
        self.card_frame = tk.Frame(self.window, bg='white', relief='solid', bd=2)
        self.card_frame.pack(padx=40, pady=20, fill='both', expand=True)
       
        self.question_label = tk.Label(self.card_frame, text="", font=("Arial", 14, "bold"),
                                     bg='white', wraplength=500, justify='center')
        self.question_label.pack(expand=True)
       
        self.answer_label = tk.Label(self.card_frame, text="", font=("Arial", 14, "bold"),
                                   bg='white', fg='#27ae60', wraplength=500, justify='center')
       
        button_frame = tk.Frame(self.window, bg='#b0e594')
        button_frame.pack(pady=20)
       
        self.action_button = tk.Button(button_frame, text="Show Answer", command=self.toggle_answer,
                                     bg='#3498db', fg='white', font=("Arial", 14, "bold"), padx=20)
        self.action_button.pack(pady=5)
       
        self.result_frame = tk.Frame(button_frame, bg='#b0e594')
       
        tk.Button(self.result_frame, text="✓ Correct", command=self.mark_correct,
                 bg='#27ae60', fg='white', font=("Arial", 10, "bold"), padx=15).pack(side='left', padx=5)
        tk.Button(self.result_frame, text="✗ Wrong", command=self.mark_wrong,
                 bg='#e74c3c', fg='white', font=("Arial", 10, "bold"), padx=15).pack(side='left', padx=5)
   
    def show_question(self):
        if self.current_index >= len(self.flashcards):
            self.show_results()
            return
       
        card = self.flashcards[self.current_index]
        self.progress_label.config(text=f"Card {self.current_index + 1} of {len(self.flashcards)}")
        self.question_label.config(text=card.question)
        self.answer_label.pack_forget()
        self.show_answer = False
        self.action_button.config(text="Show Answer")
        self.result_frame.pack_forget()
   
    def toggle_answer(self):
        if not self.show_answer:
            card = self.flashcards[self.current_index]
            self.answer_label.config(text=card.answer)
            self.answer_label.pack(expand=True)
            self.show_answer = True
            self.action_button.config(text="Next Card")
            self.result_frame.pack(pady=10)
        else:
            self.next_card()
   
    def mark_correct(self):
        self.flashcards[self.current_index].mark_correct()
        self.correct_count += 1
        self.next_card()
   
    def mark_wrong(self):
        self.flashcards[self.current_index].mark_wrong()
        self.next_card()
   
    def next_card(self):
        self.current_index += 1
        self.show_question()
   
    def show_results(self):
        total_cards = len(self.flashcards)
        percentage = (self.correct_count / total_cards) * 100
       
        result_text = f"Practice Complete!\n\nYou got {self.correct_count} out of {total_cards} correct\n({percentage:.1f}%)"
       
        if percentage >= 80:
            result_text += "\n\nExcellent work! 🌟"
        elif percentage >= 60:
            result_text += "\n\nGood job! Keep studying! 📚"
        else:
            result_text += "\n\nKeep practicing! You'll improve! 💪"
       
        messagebox.showinfo("Practice Results", result_text)
        self.window.destroy()
    
    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        window.geometry(f"{width}x{height}+{x}+{y}")

class QuizWindow:
    def __init__(self, parent, flashcards):
        self.flashcards = flashcards
        self.current_index = 0
        self.correct_count = 0
       
        self.window = tk.Toplevel(parent)
        self.window.title("Quiz Mode")
        self.center_window(self.window, 600, 400)
        self.window.configure(bg="#f09def")
       
        self.create_quiz_widgets()
        self.show_question()
   
    def create_quiz_widgets(self):

        tk.Label(self.window, text="🎯 Quiz Mode", font=("Arial", 40, "bold"),
                bg='#f09def', fg='#2c3e50').pack(pady=20)
       
        self.progress_label = tk.Label(self.window, text="", font=("Arial", 15, "bold"), bg="#f09def")
        self.progress_label.pack()
       
        self.question_label = tk.Label(self.window, text="", font=("Arial", 20, "bold"),
                                     bg='#f09def', wraplength=500)
        self.question_label.pack(pady=20)
       
        tk.Label(self.window, text="Your Answer:", font=("Arial", 14, "bold"), bg='#f09def').pack()
        self.answer_entry = tk.Entry(self.window, font=("Arial", 14), width=40)
        self.answer_entry.pack(pady=10)
        self.answer_entry.bind('<Return>', lambda e: self.submit_answer())
       
        tk.Button(self.window, text="Submit Answer", command=self.submit_answer,
                 bg='#3498db', fg='white', font=("Arial", 14, "bold"), padx=20).pack(pady=10)
       
        self.result_label = tk.Label(self.window, text="", font=("Arial", 14, "bold"), bg='#f09def')
        self.result_label.pack(pady=10)
   
    def show_question(self):
        """Display the current question and reset the entry and feedback."""
        if self.current_index >= len(self.flashcards):
            self.show_final_results()
            return
    
        card = self.flashcards[self.current_index]
        self.progress_label.config(text=f"Question {self.current_index + 1} of {len(self.flashcards)}")
        self.question_label.config(text=card.question)
        self.answer_entry.delete(0, tk.END)
        self.answer_entry.focus()
        self.result_label.config(text="")
   
    def submit_answer(self):
        user_answer = self.answer_entry.get().strip()
        if not user_answer:
            messagebox.showwarning("Warning", "Please enter an answer!")
            return
       
        card = self.flashcards[self.current_index]
        correct_answer = card.answer.strip()
       
        if user_answer.lower() == correct_answer.lower():
            self.result_label.config(text="✓ Correct!", fg='#27ae60')
            card.mark_correct()
            self.correct_count += 1
        else:
            self.result_label.config(text=f"✗ Wrong! Correct answer: {correct_answer}", fg='#e74c3c')
            card.mark_wrong()
       
        self.current_index += 1
        self.window.after(2000, self.show_question)
   
    def show_final_results(self):
        total_questions = len(self.flashcards)
        percentage = (self.correct_count / total_questions) * 100
       
        result_text = f"Quiz Complete!\n\nFinal Score: {self.correct_count}/{total_questions} ({percentage:.1f}%)\n\n"
       
        if percentage >= 80:
            result_text += "Excellent work! 🌟"
        elif percentage >= 60:
            result_text += "Good job! Keep studying! 📚"
        else:
            result_text += "Keep practicing! You'll improve! 💪"
       
        messagebox.showinfo("Quiz Results", result_text)
        self.window.destroy()

    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        window.geometry(f"{width}x{height}+{x}+{y}")

class StatisticsWindow:
    def __init__(self, parent, flashcards):
        self.window = tk.Toplevel(parent)
        self.window.title("Statistics")
        self.center_window(self.window, 600, 500)
        self.window.configure(bg="#eff29c")
       
        tk.Label(self.window, text="📊 Your Statistics", font=("Arial", 40, "bold"),
                bg='#eff29c', fg='#2c3e50').pack(pady=18)
       
        # Aggregate numbers across all cards
        total_cards = len(flashcards)
        total_correct = sum(card.times_correct for card in flashcards)
        total_wrong = sum(card.times_wrong for card in flashcards)
        total_attempts = total_correct + total_wrong
       
        stats_frame = tk.Frame(self.window, bg='white', relief='solid', bd=2)
        stats_frame.pack(padx=40, pady=20, fill='x')
       
        tk.Label(stats_frame, text="Overall Statistics", font=("Arial", 15, "bold"),
                bg='white', fg='#2c3e50').pack(pady=10)
       
        tk.Label(stats_frame, text=f"Total flashcards: {total_cards}",
                font=("Arial", 14), bg='white').pack(pady=5)
       
        if total_attempts > 0:
            overall_accuracy = (total_correct / total_attempts) * 100
            tk.Label(stats_frame, text=f"Overall accuracy: {overall_accuracy:.1f}%",
                    font=("Arial", 14), bg='white').pack(pady=5)
            tk.Label(stats_frame, text=f"Total questions answered: {total_attempts}",
                    font=("Arial", 14), bg='white').pack(pady=5)
            tk.Label(stats_frame, text=f"Correct answers: {total_correct}",
                    font=("Arial", 13, "bold"), bg='white', fg='#27ae60').pack()
            tk.Label(stats_frame, text=f"Wrong answers: {total_wrong}",
                    font=("Arial", 13, "bold"), bg='white', fg='#e74c3c').pack(pady=(0, 10))
        else:
            tk.Label(stats_frame, text="You haven't practiced any cards yet!",
                    font=("Arial", 14, "bold"), bg='white', fg='#7f8c8d').pack(pady=10)
       
        weak_cards = [card for card in flashcards if card.get_accuracy() < 70 and (card.times_correct + card.times_wrong) > 0]
       
        if weak_cards:
            tk.Label(self.window, text=f"Cards that need more practice ({len(weak_cards)} cards):",
                    font=("Arial", 14, "bold"), bg='#eff29c', fg='#e74c3c').pack(pady=(10, 5))
           
            weak_frame = tk.Frame(self.window, bg='#f0f0f0')
            weak_frame.pack(fill='both', expand=True, padx=40)
           
            canvas = tk.Canvas(weak_frame, bg='#f0f0f0')
            scrollbar = ttk.Scrollbar(weak_frame, orient="vertical", command=canvas.yview)
            scrollable_frame = tk.Frame(canvas, bg='#f0f0f0')
           
            scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
           
            # Show each weak card with its current accuracy
            for card in weak_cards:
                card_text = f"• {card.question} ({card.get_accuracy():.1f}% correct)"
                tk.Label(scrollable_frame, text=card_text, font=("Arial", 12),
                        bg='#f0f0f0', wraplength=500, justify='left').pack(anchor='w', pady=2)
           
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")

    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        window.geometry(f"{width}x{height}+{x}+{y}")

# ======================== GPA CALCULATOR APPLICATION ========================
class GPACalculator(BaseApp):
    def __init__(self, root, main_window):
        super().__init__(main_window)
        self.root = root
        self.root.title("GPA Calculator")
        self.root.configure(bg="lightyellow")
        self.center_window(root, 800, 700)
       
        self.courses = []
        self.current_file = None
        self.auto_save_file = "gpa_autosave.json"
        
        # Multiple grading systems
        self.grading_systems = {
            "SimpleABC": {
                "A": 4.0,
                "B": 3.0,
                "C": 2.0,
                "F": 0.0
            },
            "FineGrained": {
                "A+": 4.0,
                "A": 4.0,
                "A-": 3.7,
                "B+": 3.3,
                "B": 3.0,
                "B-": 2.7,
                "C+": 2.3,
                "C": 2.0,
                "F": 0.0
            },
            "Percentage": {
                "90-100 (A+)": 4.0,
                "80-89 (A)": 4.0,
                "75-79 (A-)": 3.7,
                "70-74 (B+)": 3.3,
                "65-69 (B)": 3.0,
                "60-64 (B-)": 2.7,
                "55-59 (C+)": 2.3,
                "50-54 (C)": 2.0,
                "0-49 (F)": 0.0
            }
        }
       
        """
        Default grading system
        Setup auto-save on window close
        """
        self.current_system = "FineGrained"
        self.setup_ui()
        self.load_auto_save()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
       
    def setup_ui(self):
        main_frame = tk.Frame(self.root, bg="lightyellow")
        main_frame.pack(fill="both")

        header_frame = tk.Frame(main_frame, bg="powderblue", height=15)
        header_frame.pack(fill="x", pady=(0, 10))

        back_btn = tk.Button(
            header_frame,
            text="← Back To Menu",
            command=lambda: self.back_to_main_menu(self.root),
            bg="lightpink",
            fg="black",
            font=("Courier New", 10),
            pady=1,
        )
        back_btn.pack(side="left", padx=(10,5), pady=3)

        title = tk.Label(
            header_frame,
            text="🎓 GPA CALCULATOR",
            font=("Helvetica", 20, "bold"),
            bg="powderblue",
            fg="black",
            relief="solid",bd=1,
            padx=60,pady=10
        )
        title.pack(anchor="center", expand=True, padx=(0,70),pady=10)
       
        # File operations frame
        file_frame = tk.Frame(main_frame, bg="lightyellow")
        file_frame.pack(fill='x', pady=(5, 0))
       
        save_btn = tk.Button(file_frame, text="💾 Save", command=self.save_file,
                            bg='lightgreen', fg='black', font=("Courier New", 11, "normal"),
                            relief='solid', bd=1, cursor='hand2', padx=10, pady=3,
                            activebackground='#38a169')
        save_btn.pack(side='left', padx=(20, 0))
       
        load_btn = tk.Button(file_frame, text="📁 Load", command=self.load_file,
                            bg='paleturquoise', fg='black', font=("Courier New", 11, "normal"),
                            relief='solid', bd=1, cursor='hand2', padx=10, pady=3,
                            activebackground='#3182ce')
        load_btn.pack(side='left', padx=0)
       
        self.file_status = tk.Label(file_frame, text="No file loaded",
                                   font=("Courier New", 8), bg="khaki1", fg="#000000")
        self.file_status.pack(side='right',padx=20)
       
        system_frame = tk.Frame(main_frame,  bg="lightyellow",pady=5)
        system_frame.pack(fill='x', padx=20,pady=5)
       
        tk.Label(system_frame, text="Grading System:",
                font=("Courier New", 10, "bold"), bg="salmon", fg='black',padx=5).pack(side='left')
       
        self.system_var = tk.StringVar(value=self.current_system)
        system_combo = ttk.Combobox(system_frame, textvariable=self.system_var,
                                   values=list(self.grading_systems.keys()),
                                   state='readonly', font=("Arial", 9), width=12)
        system_combo.pack(side='left', padx=(5, 0))
        system_combo.bind('<<ComboboxSelected>>', self.on_system_change)
       
        content_frame = tk.Frame(main_frame,bg="lightyellow")
        content_frame.pack(fill='both', expand=True, padx=20,pady=(0, 20))
       
        input_card = tk.Frame(content_frame, bg='antiquewhite1', relief='solid', bd=1)
        input_card.pack(side='left', fill='both', expand=True, padx=(0, 10))
       
        border_frame = tk.Frame(input_card, bg='#e2e8f0', height=2)
        border_frame.pack(fill='x', side='bottom')
       
        card_title = tk.Label(input_card, text="Add New Course",
                             font=("Helvetica", 12, "bold"),
                             bg="#fcd2b2", fg="#000000")
        card_title.pack(pady=15)
       
        fields_frame = tk.Frame(input_card, bg='antiquewhite1')
        fields_frame.pack(fill='both', expand=True, padx=20, pady=(0, 20))
       
        tk.Label(fields_frame, text="Course Name",
                font=("Courier New", 10, "bold"), bg='antiquewhite1', fg="#000000").pack(anchor='w',pady=3)
        
        self.course_entry = tk.Entry(fields_frame, font=("Courier New", 11),
                                    relief='solid', bd=1, bg="white", fg="#1a1c1e",
                                    insertbackground="#000000")
        self.course_entry.pack(fill='x',pady=3,ipady=4)
       
        tk.Label(fields_frame, text="Grade",
                font=("Courier New", 10, "bold"), bg='antiquewhite1', fg="#000000").pack(anchor='w',pady=3)
        self.grade_var = tk.StringVar()
       
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Modern.TCombobox',
                       fieldbackground="#ffffff",
                       background="#ffffff",
                       foreground="#FFFFFF",
                       bordercolor="#000000",
                       arrowcolor="#212121")
       
        self.grade_combo = ttk.Combobox(fields_frame, textvariable=self.grade_var,
                                       values=list(self.grading_systems[self.current_system].keys()),
                                       state='readonly', font=("Courier New", 11),
                                       style='Modern.TCombobox')
        self.grade_combo.pack(fill='x', pady=3, ipady=4)
       
        tk.Label(fields_frame, text="Credit Hours (2.0 - 4.0)",
                font=("Courier New", 10, "bold"), bg='antiquewhite1', fg="#000000").pack(anchor='w',pady=3)
        self.credits_entry = tk.Entry(fields_frame, font=("Courier New", 11),
                                     relief='solid', bd=1, bg='#f7fafc', fg="#1A1717",
                                     insertbackground="#000000")
        self.credits_entry.pack(fill='x',pady=3, ipady=4)
       
        add_btn = tk.Button(fields_frame, text="➕ ADD COURSE", command=self.add_course,
                           bg='lightgreen', fg='black', font=("Courier New", 11, "normal"),
                           relief='ridge', bd=1, pady=10, cursor='hand2',
                           activebackground="springgreen3", activeforeground='black')
        add_btn.pack(fill='x', pady=(10, 0))
       
        list_card = tk.Frame(content_frame, bg='antiquewhite1', relief='solid', bd=1)
        list_card.pack(side='right', fill='both', expand=True, padx=(10, 0))
       
        border_frame2 = tk.Frame(list_card, bg='#e2e8f0', height=2)
        border_frame2.pack(fill='x', side='bottom')
       
        list_header = tk.Frame(list_card, bg='antiquewhite1')
        list_header.pack(fill='x', padx=15, pady=15)
       
        self.list_title = tk.Label(list_header, text="My Courses (0)",
                                  font=("Helvetica", 12, "bold"),
                                  bg="#fcd2b2", fg="#000000")
        self.list_title.pack(side='left')
       
        btn_frame = tk.Frame(list_header, bg='antiquewhite1')
        btn_frame.pack(side='right')
       
        remove_btn = tk.Button(btn_frame, text="🗑️Remove", command=self.remove_course,
                              bg='lightcoral', fg='black', font=("Courier New", 9, "normal"),
                              relief='groove', bd=1, cursor='hand2', padx=4, pady=2,
                              activebackground='#e53e3e')
        remove_btn.pack(side='left', padx=(0, 5))
       
        clear_btn = tk.Button(btn_frame, text="🗑️Clear", command=self.clear_all,
                             bg='palegreen', fg='black', font=("Courier New", 9, "normal"),
                             relief='groove', bd=1, cursor='hand2', padx=5, pady=2,
                             activebackground='#dd6b20')
        clear_btn.pack(side='left')
       
        list_frame = tk.Frame(list_card, bg='white')
        list_frame.pack(fill='both', expand=True, padx=10, pady=(0, 20))
       
        self.course_listbox = tk.Listbox(list_frame, font=("Courier", 12),
                                        bg='#f7fafc', fg="#000000",
                                        relief='solid', bd=1, selectbackground="powderblue",
                                        selectforeground='black', highlightthickness=0)
        scrollbar = tk.Scrollbar(list_frame, orient='vertical', command=self.course_listbox.yview,
                               bg='#f7fafc', troughcolor='white', activebackground="#b9b6c1")
        self.course_listbox.configure(yscrollcommand=scrollbar.set)
       
        self.course_listbox.pack(side='left', fill='both',expand=True)
        scrollbar.pack(side='right', fill='y')
       
        result_card = tk.Frame(main_frame, bg='antiquewhite1', relief='solid', bd=1)
        result_card.pack(fill='x',padx=20)
       
        border_frame3 = tk.Frame(result_card, bg='#e2e8f0', height=2)
        border_frame3.pack(fill='x', side='top')
       
        result_inner = tk.Frame(result_card, bg='antiquewhite1')
        result_inner.pack(pady=20)
       
        self.gpa_label = tk.Label(result_inner, text="0.00",
                                 font=("Helvetica", 28, "bold"), bg='lightsalmon2', fg="#000000",padx=40)
        self.gpa_label.pack(pady=5)
       
        gpa_text = tk.Label(result_inner, text="GPA",
                           font=("Courier New", 11, "bold"), bg='antiquewhite1', fg="#353434")
        gpa_text.pack(pady=2)
       
        self.credits_label = tk.Label(result_inner, text="Credit Hours Earned: 0.0",
                                     font=("Courier New", 11,"bold"), bg='antiquewhite1', fg="#353434")
        self.credits_label.pack(pady=(5, 0))
   
    # Check if course name already exists
    def is_course_name_duplicate(self, course_name):      
        course_name_lower = course_name.lower().strip()
        for course in self.courses:
            if course['name'].lower().strip() == course_name_lower:
                return True
        return False
    
    # JSON FILE FUNCTIONS
    def save_file(self):
        if not self.courses:
            messagebox.showwarning("Warning", "No courses to save!")
            return
       
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            title="Save GPA Data"
        )
       
        if filename:
            try:
                data = {
                    "grading_system": self.current_system,
                    "courses": self.courses,
                    "total_gpa": self.calculate_gpa(),
                    "total_credits": sum(course['credits'] for course in self.courses)
                }
               
                with open(filename, 'w') as f:
                    json.dump(data, f, indent=2)
               
                self.current_file = filename
                self.update_file_status()
                messagebox.showinfo("Success", f"Data saved to {os.path.basename(filename)}")
               
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save file: {str(e)}")
   
    def load_file(self):
        filename = filedialog.askopenfilename(
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            title="Load GPA Data"
        )
       
        if filename:
            try:
                with open(filename, 'r') as f:
                    data = json.load(f)
               
                if not isinstance(data, dict) or 'courses' not in data:
                    messagebox.showerror("Error", "Invalid file format!")
                    return
               
                self.courses.clear()
                self.course_listbox.delete(0, tk.END)
               
                if 'grading_system' in data and data['grading_system'] in self.grading_systems:
                    self.current_system = data['grading_system']
                    self.system_var.set(self.current_system)
                    self.grade_combo['values'] = list(self.grading_systems[self.current_system].keys())
               
                for course in data['courses']:
                    if all(key in course for key in ['name', 'grade', 'credits', 'points']):
                        self.courses.append(course)
                        display_text = f"{course['name'][:15]:<15} {course['grade']:>4} {course['credits']:>5.1f} {course['points']:>4.1f}"
                        self.course_listbox.insert(tk.END, display_text)
               
                self.current_file = filename
                self.update_file_status()
                self.update_display()
               
                messagebox.showinfo("Success",
                    f"Loaded {len(self.courses)} courses from {os.path.basename(filename)}")
               
            except json.JSONDecodeError:
                messagebox.showerror("Error", "Invalid JSON file!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load file: {str(e)}")

    # Get grade distribution for the course list
    def get_grade_distribution(self):       
        distribution = {}
        for course in self.courses:
            grade = course['grade']
            if grade in distribution:
                distribution[grade] += 1
            else:
                distribution[grade] = 1
        return distribution
    
    # Auto-save current data
    def auto_save(self):
        if self.courses:
            try:
                data = {
                    "grading_system": self.current_system,
                    "courses": self.courses,
                    "is_auto_save": True
                }
               
                with open(self.auto_save_file, 'w') as f:
                    json.dump(data, f, indent=2)
                   
            except Exception:
                pass
   
    def load_auto_save(self):
        if os.path.exists(self.auto_save_file):
            try:
                with open(self.auto_save_file, 'r') as f:
                    data = json.load(f)
               
                if data.get('is_auto_save') and data.get('courses'):
                    if 'grading_system' in data:
                        self.current_system = data['grading_system']
                        self.system_var.set(self.current_system)
                        self.grade_combo['values'] = list(self.grading_systems[self.current_system].keys())
                   
                    for course in data['courses']:
                        self.courses.append(course)
                        display_text = f"{course['name'][:20]:<20} {course['grade']:>4}(grade) {course['credits']:>5.1f}(credit hours) {course['points']:>4.1f}(gpa)"
                        self.course_listbox.insert(tk.END, display_text)
                   
                    self.update_display()
                    self.file_status.config(text="✔ Auto-save loaded", fg="#000000")
                   
            except Exception:
                pass
   
    def update_file_status(self):
        if self.current_file:
            filename = os.path.basename(self.current_file)
            self.file_status.config(text=f"File: {filename}", fg="#000000")
        else:
            self.file_status.config(text="✘ No file loaded", fg="#000000")
   
    def on_closing(self):
        self.auto_save()
        self.root.destroy()
        self.main_window.deiconify()
    
    # Calculate current GPA
    def calculate_gpa(self):        
        if not self.courses:
            return 0.0
       
        total_points = sum(course['points'] * course['credits'] for course in self.courses)
        total_credits = sum(course['credits'] for course in self.courses)
        return total_points / total_credits
    
    # Handle grading system change
    def on_system_change(self, event=None):
        old_system = self.current_system
        new_system = self.system_var.get()
       
        if self.courses:
            result = messagebox.askyesno(
                "Change Grading System",
                f"Changing from {old_system} to {new_system} will clear all courses.\nDo you want to continue?"
            )
            if not result:
                self.system_var.set(old_system)
                return
           
            self.courses.clear()
            self.course_listbox.delete(0, tk.END)
       
        self.current_system = new_system
        self.grade_combo['values'] = list(self.grading_systems[self.current_system].keys())
        self.grade_var.set("")
        self.update_display()
   
    def add_course(self):
        course_name = self.course_entry.get().strip()
        grade = self.grade_var.get()
        credits_text = self.credits_entry.get().strip()
       
        if not course_name or not grade or not credits_text:
            messagebox.showerror("Error", "Please fill all fields")
            return
        
        # Check for duplicate course name
        if self.is_course_name_duplicate(course_name):
            result = messagebox.askyesno(
                "Duplicate Course",
                f"Course '{course_name}' already exists!\n\nDo you want to add it anyway? "
                f"This might be useful for repeated courses or different semesters."
            )
            if not result:
                return
        
        # Credit Hours validation
        try:
            credits = float(credits_text)
            if credits < 2.0 or credits > 4.0:
                messagebox.showerror("Error", "Credit Hours must be between 2.0 and 4.0")
                return
        except ValueError:
            messagebox.showerror("Error", "Credit Hours must be a number")
            return
       
        grade_points = self.grading_systems[self.current_system][grade]
       
        course = {
            'name': course_name,
            'grade': grade,
            'credits': credits,
            'points': grade_points
        }
        self.courses.append(course)
       
        # Update display with enhanced formatting
        display_text = f"{course_name[:15]:<15} {grade:>4} {credits:>5.1f} {grade_points:>4.1f}"
        self.course_listbox.insert(tk.END, display_text)
       
        self.course_entry.delete(0, tk.END)
        self.grade_var.set("")
        self.credits_entry.delete(0, tk.END)
       
        self.update_display()
        self.auto_save()
   
    def remove_course(self):
        selected = self.course_listbox.curselection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a course to remove")
            return
       
        index = selected[0]
        course_name = self.courses[index]['name']
       
        # Confirm deletion
        result = messagebox.askyesno("Confirm Removal", f"Remove '{course_name}' from your courses?")
        if result:
            self.courses.pop(index)
            self.course_listbox.delete(index)
            self.update_display()
            self.auto_save()
   
    def clear_all(self):
        if self.courses:
            if messagebox.askyesno("Confirm", "Clear all courses?"):
                self.courses.clear()
                self.course_listbox.delete(0, tk.END)
                self.update_display()
                self.auto_save()
   
    def update_display(self):
        self.list_title.config(text=f"My Courses ({len(self.courses)})")
       
        if not self.courses:
            self.gpa_label.config(text="0.00")
            self.credits_label.config(text="Credit Hours Earned: 0.0")
            return
       
        total_points = sum(course['points'] * course['credits'] for course in self.courses)
        total_credits = sum(course['credits'] for course in self.courses)
       
        gpa = total_points / total_credits
       
        """
        Color code GPA with colors
        Green for >=3.5, Yellow for 3.0-3.49, Black for 2.0-2.99, Red for <2.0
        """
        if gpa >= 3.5:
            color = "#a5fbb7"
        elif gpa >= 3.0:
            color = "#e9fca5"
        elif gpa >= 2.0:
            color = "#000000"
        else:
            color = "#f56565"
       
        self.gpa_label.config(text=f"{gpa:.2f}", fg=color)
        self.credits_label.config(text=f"Credit Hours Earned: {total_credits:.1f}")


# ======================== MAIN EXECUTION ========================
if __name__ == "__main__":
    app = StudyAppSuite()
    app.run()