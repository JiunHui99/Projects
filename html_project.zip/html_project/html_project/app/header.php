<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title>BagToHome</title>
        <link rel="stylesheet" href="/css/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/91JmVM2hMDcnK10nMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referer" />
        <script src="js/app.js"></script>
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wdth@87.5&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">  
    <script>
        function toggleMenu() {
            var menu = document.getElementById("admin-menu");
            menu.style.display = (menu.style.display === "block") ? "none" : "block";
        }
    </script>
</head>
<header>
        <div class="logo">
        <a href="/../index.php"><img src="/image/icon.png"alt="" width="60px";></a>
        <a href="/../index.php">Bag<span>TO</span>Home</a>
        </div>

            <ul class="navmenu">
                <a href="/../index.php">Home</a> 
                <a href="/product/trending.php">Trending</a> 
                <a href="/product/newin.php">New Arrival</a> 
                <a href="/product/products.php">All Product</a>
            </ul>

            <div class="nav-icon">
            <form action="/user/search.php" method="GET" style="display: flex; align-items: center;">
                <input type="text" name="query" placeholder="Search..." style="outline:none;">
                <a href="javascript:void(0);" onclick="this.closest('form').submit();">
                <i class='bx bx-search'></i></a>
            </form>
                <a href="/user/profile.php"><i class='bx bx-user'></i></a>
                <a href="/user/cart.php"><i class='bx bx-cart'></i></a>
                <a href="/admin/admin_dashboard.php"><i class='bx bxs-user-rectangle'></i></a>
            </div>
</header>