
<title>Handle Bag</title>
<?php include '../header.php'; ?>

<?php 
 require '../db.php';

$stmt = $pdo->query("SELECT * FROM products Where cat_id = 'CA003'");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
   // Get sorting parameters,default = price or name
   $sortOrderPrice = isset($_GET['sort_price']) ? $_GET['sort_price'] : '';
   $sortOrderName = isset($_GET['sort_name']) ? $_GET['sort_name'] : '';

   if ($sortOrderPrice) {
       usort($products, function($a, $b) use ($sortOrderPrice) {
           return $sortOrderPrice === 'ASC' ? $a['price'] <=> $b['price'] : $b['price'] <=> $a['price'];
       });
   } elseif ($sortOrderName) {
       usort($products, function($a, $b) use ($sortOrderName) {
           return $sortOrderName === 'ASC' ? strcmp($a['product_name'], $b['product_name']) : strcmp($b['product_name'], $a['product_name']);
       });
   }
?>
<section class="handleBag-page">

<h2>Handle Bag</h2>
 <?php include '../webinfo/filter.php'; ?>

<section class="handleBag-product">
<?php foreach($products as $row): ?>
        <div class="handleBag-list">
        <a href="../product/product_detail.php?id=<?= htmlspecialchars($row["product_id"]) ?>">
                <img src="../image/<?= htmlspecialchars($row["image"]) ?>">
            </a>
            <h1><?= htmlspecialchars($row["product_name"]) ?></h1>
            <p><?= htmlspecialchars($row["description"]) ?></p>
            <p>RM: <strong><?= number_format($row["price"], 2) ?></strong></p>
            <p>Stock: <strong><?= htmlspecialchars($row["stock"]) ?></strong></p>
            <p>Sales: <strong><?= htmlspecialchars($row["sales"]) ?></strong></p>
            <form action="../user/add_to_cart.php" method="POST">
                <input type="hidden" name="product_id" value="<?= htmlspecialchars($row["product_id"]) ?>">
                <input type="number" name="quantity" value="1" min="1" max="<?= htmlspecialchars($row["stock"]) ?>" style="width: 60px;">
                <button type="submit" class="add-to-cart">Add to Cart</button>
            </form>
        </div>
    <?php endforeach; ?>
</section>

<a href="/../index.php" class="back-btn">Back to Home</a>

</section>

<?php include '../webinfo/footer.php'; ?>

<style>
.handleBag-page {
    border: 1px solid #000000;
    border-radius: 10px;
    margin:30px auto;
    padding: 10px 20px;
    max-width: 90%;
}
.handleBag-page h2{
    text-align: center;
    margin: 20px;
}
.handleBag-product {
    background-color: rgba(255, 243, 243, 0.78);
    border: 1px solid #000000;
    border-radius: 10px;
    margin:30px auto;
    padding: 40px 40px;
    max-width: 90%;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 5fr));
    gap: 1rem;
}
.handleBag-list{
    text-align: center;
    padding:20px 10px;
} 
.handleBag-list:hover{
    transform: scale(1.05);
}
.handleBag-list img{
    border:1px solid rgb(136, 136, 136);
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
    width: 100%; 
    height: 46vh;
}
.handleBag-list h1{
    color:rgb(0, 0, 0);
    margin: 10px;
    font-size: 20px;
}
.handleBag-list strong{
    color: rgba(102, 7, 175, 0.65);
    font-size: 15px;
}
.add-to-cart{
    padding: 5px 10px;
    background-color: floralwhite;
    border: 1px solid #333;
    border-radius: 5px;
    text-transform: capitalize;
}
.add-to-cart:hover{
    background-color: papayawhip;
    transform: scale(1.05);
}
.back-btn{
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
</style>