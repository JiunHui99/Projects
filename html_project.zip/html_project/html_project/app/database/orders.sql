-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2025 at 10:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bag_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(100) NOT NULL,
  `product_id` int(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Completed','Cancelled','Processing','Shipped','Delivered') DEFAULT 'Pending',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `total_amount`, `status`, `order_date`, `created_at`) VALUES
(5, 133, 0, 59.00, 'Pending', '2025-03-13 14:53:55', '2025-03-13 14:53:55'),
(6, 133, 0, 69.00, 'Shipped', '2025-03-13 15:01:35', '2025-03-13 15:01:35'),
(7, 133, 0, 78.00, 'Pending', '2025-03-14 16:23:46', '2025-03-14 16:23:46'),
(8, 140, 0, 139.00, 'Pending', '2025-03-30 17:07:52', '2025-03-30 17:07:52'),
(9, 140, 0, 139.00, 'Pending', '2025-03-30 17:08:16', '2025-03-30 17:08:16'),
(10, 140, 0, 59.00, 'Pending', '2025-03-30 17:58:10', '2025-03-30 17:58:10'),
(11, 140, 0, 159.00, 'Pending', '2025-03-30 17:58:57', '2025-03-30 17:58:57'),
(12, 140, 0, 567.00, 'Pending', '2025-03-31 08:11:05', '2025-03-31 08:11:05'),
(13, 141, 0, 657.00, 'Pending', '2025-04-21 17:53:35', '2025-04-21 17:53:35'),
(14, 140, 0, 458.00, 'Pending', '2025-04-22 05:19:55', '2025-04-22 05:19:55'),
(15, 140, 0, 458.00, 'Pending', '2025-04-22 05:19:56', '2025-04-22 05:19:56'),
(16, 140, 0, 458.00, 'Pending', '2025-04-22 05:21:00', '2025-04-22 05:21:00'),
(17, 140, 0, 498.00, 'Pending', '2025-04-22 07:04:23', '2025-04-22 07:04:23'),
(18, 140, 0, 199.00, 'Pending', '2025-04-22 07:10:39', '2025-04-22 07:10:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
