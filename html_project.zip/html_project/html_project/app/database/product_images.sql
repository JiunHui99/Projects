-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2025 at 10:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bag_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `product_image_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`product_image_id`, `product_id`, `image_url`) VALUES
(1, 1001, 'Backpack/Balida1.jpg'),
(2, 1001, 'Backpack/Balida2.jpg'),
(3, 1001, 'Backpack/Balida3.jpg'),
(4, 1002, 'Backpack/Buffy1.webp'),
(5, 1002, 'Backpack/Buffy2.webp'),
(6, 1002, 'Backpack/Buffy3.webp'),
(7, 1003, 'Backpack/Hazel1.webp'),
(8, 1003, 'Backpack/Hazel2.webp'),
(9, 1003, 'Backpack/Hazel3.webp'),
(10, 1004, 'Backpack/Siro1.jpg'),
(11, 1004, 'Backpack/Siro2.webp'),
(12, 1004, 'Backpack/Siro3.jpg'),
(13, 1005, 'CrossBody/Alva1.webp'),
(14, 1005, 'CrossBody/Alva2.webp'),
(15, 1005, 'CrossBody/Alva3.jpg'),
(16, 1006, 'CrossBody/Brennan1.webp'),
(17, 1006, 'CrossBody/Brennan2.webp'),
(18, 1006, 'CrossBody/Brennan3.webp'),
(19, 1007, 'CrossBody/Pan1.webp'),
(20, 1007, 'CrossBody/Pan2.webp'),
(21, 1007, 'CrossBody/Pan3.webp'),
(22, 1008, 'CrossBody/Satin1.webp'),
(23, 1008, 'CrossBody/Satin2.webp'),
(24, 1008, 'CrossBody/Satin3.webp'),
(25, 1009, 'CrossBody/Soni1.webp'),
(26, 1009, 'CrossBody/Soni2.webp'),
(27, 1009, 'CrossBody/Soni3.webp'),
(28, 1010, 'HandleBag/Clara1.webp'),
(29, 1010, 'HandleBag/Clara2.webp'),
(30, 1010, 'HandleBag/Clara3.webp'),
(31, 1011, 'HandleBag/Enola1.webp'),
(32, 1011, 'HandleBag/Enola2.webp'),
(33, 1011, 'HandleBag/Enola3.webp'),
(34, 1012, 'HandleBag/Nano1.png'),
(35, 1012, 'HandleBag/Nano2.png'),
(36, 1012, 'HandleBag/Nano3.png'),
(37, 1013, 'ShoulderBag/Cargo1.jpg'),
(38, 1013, 'ShoulderBag/Cargo2.png'),
(39, 1013, 'ShoulderBag/Cargo3.png'),
(40, 1014, 'ShoulderBag/Meridian1.webp'),
(41, 1014, 'ShoulderBag/Meridian2.webp'),
(42, 1014, 'ShoulderBag/Meridian3.avif'),
(43, 1015, 'ShoulderBag/Mini1.png'),
(44, 1015, 'ShoulderBag/Mini2.avif'),
(45, 1015, 'ShoulderBag/Mini3.avif'),
(46, 1016, 'ShoulderBag/Nancy1.webp'),
(47, 1016, 'ShoulderBag/Nancy2.jpg'),
(48, 1016, 'ShoulderBag/Nancy3.jpg'),
(49, 1017, 'ShoulderBag/Petra1.jpg'),
(50, 1017, 'ShoulderBag/Petra2.jpg'),
(51, 1017, 'ShoulderBag/Petra3.jpg'),
(52, 1018, 'ToteBag/Casi1.webp'),
(53, 1018, 'ToteBag/Casi2.webp'),
(54, 1018, 'ToteBag/Casi3.webp'),
(55, 1019, 'ToteBag/Colla1.webp'),
(56, 1019, 'ToteBag/Colla2.webp'),
(57, 1019, 'ToteBag/Colla3.webp'),
(58, 1020, 'ToteBag/Sabine1.jpg'),
(59, 1020, 'ToteBag/Sabine2.jpg'),
(60, 1020, 'ToteBag/Sabine3.jpg'),
(61, 1021, 'ToteBag/Young1.webp'),
(62, 1021, 'ToteBag/Young2.webp'),
(63, 1021, 'ToteBag/Young3.jpg'),
(64, 1022, 'CrossBody/Caca1.png'),
(65, 1022, 'CrossBody/Caca2.png'),
(66, 1022, 'CrossBody/Caca3.png'),
(67, 1023, 'HandleBag/Krystal1.webp'),
(68, 1023, 'HandleBag/Krystal2.webp'),
(69, 1023, 'HandleBag/Krystal2.webp'),
(70, 1024, 'ShoulderBag/Boulogne1.png'),
(71, 1024, 'ShoulderBag/Boulogne2.png'),
(72, 1024, 'ShoulderBag/Boulogne3.png'),
(73, 1025, 'ShoulderBag/Coco1.webp'),
(74, 1025, 'ShoulderBag/Coco2.webp'),
(75, 1025, 'ShoulderBag/Coco3.webp'),
(76, 1026, 'ToteBag/Ong1.png'),
(77, 1026, 'ToteBag/Ong2.png'),
(78, 1026, 'ToteBag/Ong3.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`product_image_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `product_image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
