-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2025 at 06:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bag_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(100) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expiry` datetime(2) DEFAULT NULL,
  `profile_photo` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `email`, `password`, `reset_token`, `reset_token_expiry`, `profile_photo`, `role`, `created_at`, `address`) VALUES
(133, 'jiun hui', 'ngjiunhui@gmail.com', '$2y$10$4f9RyoA/d3oqGjc0byTk0.uKxMbK18ZfM/1NBKz.6RcRwJF..s1Xy', '5b05c943a8d159a6893c36f20d118c2cf775e7b014aebde34ab338394985f0e8', '2025-03-17 16:02:31.00', 'uploads/1743337183_mmexport1710945721550.jpg', 'user', '2025-03-14 10:04:17', ''),
(141, 'zyAdmin', 'zy1234@gmail.com', '$2y$10$sFiEfL6u/91OLmcJwvU5I.8.gtQ.O0lNjA6FLNIRpaJ.g9OhCeb02', '6ece2cec5e242d1a9a4636689d81b66e8ab85ea69455e43ff6c138faeade1648', '2025-04-22 08:35:24.00', '../uploads/1745418462_team1.jpg', 'admin', '2025-03-30 17:12:38', '123,jalan mewar,taman 123,kuala lumpur'),
(146, 'zy123', 'zy123@gmail.com', '$2y$10$8bsiUAzWdQb/TXor1NdH.OfL2eimcmgqceWbYN8g7TE03Fz6wDD5i', NULL, NULL, '../uploads/1745420388_footer.jpg', 'user', '2025-04-23 14:54:00', '23,Home Sweet Home 520,Sunshine Town,52099,Happy World');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
