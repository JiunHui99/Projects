-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2025 at 06:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bag_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `carts_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `product_id` int(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(10) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`carts_id`, `user_id`, `product_id`, `price`, `quantity`) VALUES
(24, 141, 1017, 0.00, 1),
(25, 141, 1020, 0.00, 1),
(26, 141, 1024, 0.00, 3),
(27, 141, 1016, 0.00, 1),
(34, 146, 1026, 0.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` varchar(20) NOT NULL,
  `cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
('CA001', 'Backpack'),
('CA002', 'CrossBody'),
('CA003', 'Handle Bag'),
('CA004', 'Shoulder Bag'),
('CA005', 'Tote Bag');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(100) NOT NULL,
  `product_id` int(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Completed','Cancelled','Processing','Shipped','Delivered') DEFAULT 'Pending',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `total_amount`, `status`, `order_date`, `created_at`) VALUES
(5, 133, 0, 59.00, 'Pending', '2025-03-13 14:53:55', '2025-03-13 14:53:55'),
(6, 133, 0, 69.00, 'Shipped', '2025-03-13 15:01:35', '2025-03-13 15:01:35'),
(7, 133, 0, 78.00, 'Pending', '2025-03-14 16:23:46', '2025-03-14 16:23:46'),
(13, 141, 0, 657.00, 'Pending', '2025-04-21 17:53:35', '2025-04-21 17:53:35'),
(19, 146, 0, 598.00, 'Processing', '2025-04-23 15:00:59', '2025-04-23 15:00:59'),
(20, 146, 0, 998.00, 'Pending', '2025-04-23 15:43:14', '2025-04-23 15:43:14'),
(21, 146, 0, 308.00, 'Pending', '2025-04-23 15:58:35', '2025-04-23 15:58:35');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(8, 6, 0, 1, 69.00),
(9, 7, 0, 2, 39.00),
(17, 13, 0, 1, 299.00),
(18, 13, 0, 1, 299.00),
(19, 13, 0, 1, 59.00),
(25, 19, 1020, 2, 299.00),
(26, 20, 1005, 1, 299.00),
(27, 20, 1024, 1, 699.00),
(28, 21, 1009, 1, 169.00),
(29, 21, 1021, 1, 139.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` double(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `sales` int(100) NOT NULL,
  `cat_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `description`, `price`, `image`, `stock`, `date`, `sales`, `cat_id`) VALUES
(1001, 'Balida', 'Women Black Backpack', 59.00, 'Backpack/Balida1.jpg', 10, '2025-03-15 07:15:52.000000', 15, 'CA001'),
(1002, 'Buffy', 'Women Black Backpack', 199.00, 'Backpack/Buffy1.WEBP', 10, '2025-03-15 07:16:49.000000', 13, 'CA001'),
(1003, 'Hazel', 'Women Black Backpack', 139.00, 'Backpack/Hazel1.webp', 10, '2025-03-21 07:18:04.000000', 16, 'CA001'),
(1004, 'Siro', 'Unisex Black Backpack', 169.00, 'Backpack/Siro1.jpg', 10, '2025-03-21 07:18:04.000000', 25, 'CA001'),
(1005, 'Alva', 'Women Black Cross Body Bag', 299.00, 'CrossBody/Alva1.webp', 7, '2025-03-21 07:18:04.000000', 23, 'CA002'),
(1006, 'Brennan', 'Women White Cross Body Bag', 199.00, 'CrossBody/Brennan1.webp', 9, '2025-03-21 07:18:04.000000', 21, 'CA002'),
(1007, 'Pan', 'Women Black Cross Body Bag', 139.00, 'CrossBody/Pan1.webp', 10, '2025-03-15 07:18:04.000000', 17, 'CA002'),
(1008, 'Satin', 'Women Black Cross Body Bag', 169.00, 'CrossBody/Satin1.webp', 10, '2025-03-21 07:18:04.000000', 16, 'CA002'),
(1009, 'Soni', 'Women White Cross Body Bag', 169.00, 'CrossBody/Soni1.webp', 9, '2025-03-15 07:18:04.000000', 11, 'CA002'),
(1010, 'Clara', 'Women Black Handle Bag', 199.00, 'HandleBag/Clara1.webp', 10, '2025-03-15 07:18:04.000000', 15, 'CA003'),
(1011, 'Enola', 'Women Black Handle Bag', 199.00, 'HandleBag/Enola1.webp', 10, '2025-03-21 07:18:04.000000', 19, 'CA003'),
(1012, 'Nano', 'Women Brown Handle Bag', 299.00, 'HandleBag/Nano1.png', 10, '2025-03-21 07:18:04.000000', 16, 'CA003'),
(1013, 'Cargo', 'Women Black Shoulder Bag', 199.00, 'ShoulderBag/Cargo1.jpg', 9, '2025-03-21 07:18:04.000000', 28, 'CA004'),
(1014, 'Meridian', 'Women Brown Shoulder Bag', 159.00, 'ShoulderBag/Meridian1.webp', 10, '2025-03-15 07:18:04.000000', 16, 'CA004'),
(1015, 'Mini', 'Women Black Shoulder Bag', 159.00, 'ShoulderBag/Mini1.png', 8, '2025-03-15 07:18:04.000000', 18, 'CA004'),
(1016, 'Nancy', 'Women Black Shoulder Bag', 299.00, 'ShoulderBag/Nancy1.webp', 10, '2025-03-21 07:18:04.000000', 30, 'CA004'),
(1017, 'Petra', 'Women Blue Denim Shoulder Bag', 299.00, 'ShoulderBag/Petra1.jpg', 8, '2025-03-21 07:18:04.000000', 35, 'CA004'),
(1018, 'Casi', 'Women Black Tote Bag', 159.00, 'ToteBag/Casi1.webp', 10, '2025-03-21 07:18:04.000000', 19, 'CA005'),
(1019, 'Colla', 'Women White Tote Bag', 199.00, 'ToteBag/Colla1.webp', 9, '2025-03-15 07:18:04.000000', 13, 'CA005'),
(1020, 'Sabine', 'Women Brown Small Tote Bag', 299.00, 'ToteBag/Sabine1.jpg', 8, '2025-03-21 07:18:04.000000', 18, 'CA005'),
(1021, 'Young', 'Women Orange Tote Bag', 139.00, 'ToteBag/Young1.webp', 9, '2025-03-15 07:18:04.000000', 12, 'CA005'),
(1022, 'Caca', 'Women Brown CrossBody Bag', 399.00, 'CrossBody/Caca1.png', 10, '2025-04-15 15:10:42.000000', 20, 'CA002'),
(1023, 'Krystal', 'Women Black Handle Bag', 299.00, 'HandleBag/Krystal1.webp', 10, '2025-04-15 15:10:42.000000', 30, 'CA003'),
(1024, 'Boulogne', 'Women White Shoulder Bag', 699.00, 'ShoulderBag/Boulogne1.png', 9, '2025-04-16 15:16:52.000000', 20, 'CA003'),
(1025, 'Coco', 'Women Brown Shoulder Bag', 299.00, 'ShoulderBag/Coco1.webp', 10, '2025-04-16 15:16:52.000000', 15, 'CA003'),
(1026, 'Ong', 'Women White Tote Bag', 399.00, '/ToteBag/Ong1.png', 10, '2025-04-16 15:19:52.000000', 20, 'CA005');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `product_image_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`product_image_id`, `product_id`, `image_url`) VALUES
(1, 1001, 'Backpack/Balida1.jpg'),
(2, 1001, 'Backpack/Balida2.jpg'),
(3, 1001, 'Backpack/Balida3.jpg'),
(4, 1002, 'Backpack/Buffy1.webp'),
(5, 1002, 'Backpack/Buffy2.webp'),
(6, 1002, 'Backpack/Buffy3.webp'),
(7, 1003, 'Backpack/Hazel1.webp'),
(8, 1003, 'Backpack/Hazel2.webp'),
(9, 1003, 'Backpack/Hazel3.webp'),
(10, 1004, 'Backpack/Siro1.jpg'),
(11, 1004, 'Backpack/Siro2.webp'),
(12, 1004, 'Backpack/Siro3.jpg'),
(13, 1005, 'CrossBody/Alva1.webp'),
(14, 1005, 'CrossBody/Alva2.webp'),
(15, 1005, 'CrossBody/Alva3.jpg'),
(16, 1006, 'CrossBody/Brennan1.webp'),
(17, 1006, 'CrossBody/Brennan2.webp'),
(18, 1006, 'CrossBody/Brennan3.webp'),
(19, 1007, 'CrossBody/Pan1.webp'),
(20, 1007, 'CrossBody/Pan2.webp'),
(21, 1007, 'CrossBody/Pan3.webp'),
(22, 1008, 'CrossBody/Satin1.webp'),
(23, 1008, 'CrossBody/Satin2.webp'),
(24, 1008, 'CrossBody/Satin3.webp'),
(25, 1009, 'CrossBody/Soni1.webp'),
(26, 1009, 'CrossBody/Soni2.webp'),
(27, 1009, 'CrossBody/Soni3.webp'),
(28, 1010, 'HandleBag/Clara1.webp'),
(29, 1010, 'HandleBag/Clara2.webp'),
(30, 1010, 'HandleBag/Clara3.webp'),
(31, 1011, 'HandleBag/Enola1.webp'),
(32, 1011, 'HandleBag/Enola2.webp'),
(33, 1011, 'HandleBag/Enola3.webp'),
(34, 1012, 'HandleBag/Nano1.png'),
(35, 1012, 'HandleBag/Nano2.png'),
(36, 1012, 'HandleBag/Nano3.png'),
(37, 1013, 'ShoulderBag/Cargo1.jpg'),
(38, 1013, 'ShoulderBag/Cargo2.png'),
(39, 1013, 'ShoulderBag/Cargo3.png'),
(40, 1014, 'ShoulderBag/Meridian1.webp'),
(41, 1014, 'ShoulderBag/Meridian2.webp'),
(42, 1014, 'ShoulderBag/Meridian3.avif'),
(43, 1015, 'ShoulderBag/Mini1.png'),
(44, 1015, 'ShoulderBag/Mini2.avif'),
(45, 1015, 'ShoulderBag/Mini3.avif'),
(46, 1016, 'ShoulderBag/Nancy1.webp'),
(47, 1016, 'ShoulderBag/Nancy2.jpg'),
(48, 1016, 'ShoulderBag/Nancy3.jpg'),
(49, 1017, 'ShoulderBag/Petra1.jpg'),
(50, 1017, 'ShoulderBag/Petra2.jpg'),
(51, 1017, 'ShoulderBag/Petra3.jpg'),
(52, 1018, 'ToteBag/Casi1.webp'),
(53, 1018, 'ToteBag/Casi2.webp'),
(54, 1018, 'ToteBag/Casi3.webp'),
(55, 1019, 'ToteBag/Colla1.webp'),
(56, 1019, 'ToteBag/Colla2.webp'),
(57, 1019, 'ToteBag/Colla3.webp'),
(58, 1020, 'ToteBag/Sabine1.jpg'),
(59, 1020, 'ToteBag/Sabine2.jpg'),
(60, 1020, 'ToteBag/Sabine3.jpg'),
(61, 1021, 'ToteBag/Young1.webp'),
(62, 1021, 'ToteBag/Young2.webp'),
(63, 1021, 'ToteBag/Young3.jpg'),
(64, 1022, 'CrossBody/Caca1.png'),
(65, 1022, 'CrossBody/Caca2.png'),
(66, 1022, 'CrossBody/Caca3.png'),
(67, 1023, 'HandleBag/Krystal1.webp'),
(68, 1023, 'HandleBag/Krystal2.webp'),
(69, 1023, 'HandleBag/Krystal2.webp'),
(70, 1024, 'ShoulderBag/Boulogne1.png'),
(71, 1024, 'ShoulderBag/Boulogne2.png'),
(72, 1024, 'ShoulderBag/Boulogne3.png'),
(73, 1025, 'ShoulderBag/Coco1.webp'),
(74, 1025, 'ShoulderBag/Coco2.webp'),
(75, 1025, 'ShoulderBag/Coco3.webp'),
(76, 1026, 'ToteBag/Ong1.png'),
(77, 1026, 'ToteBag/Ong2.png'),
(78, 1026, 'ToteBag/Ong3.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(100) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expiry` datetime(2) DEFAULT NULL,
  `profile_photo` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `email`, `password`, `reset_token`, `reset_token_expiry`, `profile_photo`, `role`, `created_at`, `address`) VALUES
(133, 'jiun hui', 'ngjiunhui@gmail.com', '$2y$10$4f9RyoA/d3oqGjc0byTk0.uKxMbK18ZfM/1NBKz.6RcRwJF..s1Xy', '5b05c943a8d159a6893c36f20d118c2cf775e7b014aebde34ab338394985f0e8', '2025-03-17 16:02:31.00', 'uploads/1743337183_mmexport1710945721550.jpg', 'user', '2025-03-14 10:04:17', ''),
(141, 'zyAdmin', 'zy1234@gmail.com', '$2y$10$sFiEfL6u/91OLmcJwvU5I.8.gtQ.O0lNjA6FLNIRpaJ.g9OhCeb02', '6ece2cec5e242d1a9a4636689d81b66e8ab85ea69455e43ff6c138faeade1648', '2025-04-22 08:35:24.00', '../uploads/1745418462_team1.jpg', 'admin', '2025-03-30 17:12:38', '123,jalan mewar,taman 123,kuala lumpur'),
(146, 'zy123', 'zy123@gmail.com', '$2y$10$8bsiUAzWdQb/TXor1NdH.OfL2eimcmgqceWbYN8g7TE03Fz6wDD5i', NULL, NULL, '../uploads/1745420388_footer.jpg', 'user', '2025-04-23 14:54:00', '23,Home Sweet Home 520,Sunshine Town,52099,Happy World');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`carts_id`),
  ADD UNIQUE KEY `user_id_2` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_id` (`product_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`product_image_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `carts_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1028;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `product_image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `carts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `category` (`cat_id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
