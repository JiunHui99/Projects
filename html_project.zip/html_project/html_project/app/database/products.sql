-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2025 at 10:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bag_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` double(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `sales` int(100) NOT NULL,
  `cat_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `description`, `price`, `image`, `stock`, `date`, `sales`, `cat_id`) VALUES
(1001, 'Balida', 'Women Black Backpack', 59.00, 'Backpack/Balida1.jpg', 9, '2025-03-15 07:15:52.000000', 15, 'CA001'),
(1002, 'Buffy', 'Women Black Backpack', 199.00, 'Backpack/Buffy1.WEBP', 10, '2025-03-15 07:16:49.000000', 13, 'CA001'),
(1003, 'Hazel', 'Women Black Backpack', 139.00, 'Backpack/Hazel1.webp', 10, '2025-03-21 07:18:04.000000', 16, 'CA001'),
(1004, 'Siro', 'Unisex Black Backpack', 169.00, 'Backpack/Siro1.jpg', 10, '2025-03-21 07:18:04.000000', 25, 'CA001'),
(1005, 'Alva', 'Women Black Cross Body Bag', 299.00, 'CrossBody/Alva1.webp', 8, '2025-03-21 07:18:04.000000', 23, 'CA002'),
(1006, 'Brennan', 'Women White Cross Body Bag', 199.00, 'CrossBody/Brennan1.webp', 9, '2025-03-21 07:18:04.000000', 21, 'CA002'),
(1007, 'Pan', 'Women Black Cross Body Bag', 139.00, 'CrossBody/Pan1.webp', 10, '2025-03-15 07:18:04.000000', 17, 'CA002'),
(1008, 'Satin', 'Women Black Cross Body Bag', 169.00, 'CrossBody/Satin1.webp', 10, '2025-03-21 07:18:04.000000', 16, 'CA002'),
(1009, 'Soni', 'Women White Cross Body Bag', 169.00, 'CrossBody/Soni1.webp', 10, '2025-03-15 07:18:04.000000', 11, 'CA002'),
(1010, 'Clara', 'Women Black Handle Bag', 199.00, 'HandleBag/Clara1.webp', 10, '2025-03-15 07:18:04.000000', 15, 'CA003'),
(1011, 'Enola', 'Women Black Handle Bag', 199.00, 'HandleBag/Enola1.webp', 10, '2025-03-21 07:18:04.000000', 19, 'CA003'),
(1012, 'Nano', 'Women Brown Handle Bag', 299.00, 'HandleBag/Nano1.png', 10, '2025-03-21 07:18:04.000000', 16, 'CA003'),
(1013, 'Cargo', 'Women Black Shoulder Bag', 199.00, 'ShoulderBag/Cargo1.jpg', 9, '2025-03-21 07:18:04.000000', 28, 'CA004'),
(1014, 'Meridian', 'Women Brown Shoulder Bag', 159.00, 'ShoulderBag/Meridian1.webp', 10, '2025-03-15 07:18:04.000000', 16, 'CA004'),
(1015, 'Mini', 'Women Black Shoulder Bag', 159.00, 'ShoulderBag/Mini1.png', 8, '2025-03-15 07:18:04.000000', 18, 'CA004'),
(1016, 'Nancy', 'Women Black Shoulder Bag', 299.00, 'ShoulderBag/Nancy1.webp', 10, '2025-03-21 07:18:04.000000', 30, 'CA004'),
(1017, 'Petra', 'Women Blue Denim Shoulder Bag', 299.00, 'ShoulderBag/Petra1.jpg', 8, '2025-03-21 07:18:04.000000', 35, 'CA004'),
(1018, 'Casi', 'Women Black Tote Bag', 159.00, 'ToteBag/Casi1.webp', 10, '2025-03-21 07:18:04.000000', 19, 'CA005'),
(1019, 'Colla', 'Women White Tote Bag', 199.00, 'ToteBag/Colla1.webp', 9, '2025-03-15 07:18:04.000000', 13, 'CA005'),
(1020, 'Sabine', 'Women Brown Small Tote Bag', 299.00, 'ToteBag/Sabine1.jpg', 10, '2025-03-21 07:18:04.000000', 18, 'CA005'),
(1021, 'Young', 'Women Orange Tote Bag', 139.00, 'ToteBag/Young1.webp', 10, '2025-03-15 07:18:04.000000', 12, 'CA005'),
(1022, 'Caca', 'Women Brown CrossBody Bag', 399.00, 'CrossBody/Caca1.png', 10, '2025-04-15 15:10:42.000000', 20, 'CA002'),
(1023, 'Krystal', 'Women Black Handle Bag', 299.00, 'HandleBag/Krystal1.webp', 10, '2025-04-15 15:10:42.000000', 30, 'CA003'),
(1024, 'Boulogne', 'Women White Shoulder Bag', 699.00, 'ShoulderBag/Boulogne1.png', 10, '2025-04-16 15:16:52.000000', 20, 'CA003'),
(1025, 'Coco', 'Women Brown Shoulder Bag', 299.00, 'ShoulderBag/Coco1.webp', 10, '2025-04-16 15:16:52.000000', 15, 'CA003'),
(1026, 'Ong', 'Women White Tote Bag', 399.00, '/ToteBag/Ong1.png', 10, '2025-04-16 15:19:52.000000', 20, 'CA005');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_id` (`product_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `category` (`cat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
