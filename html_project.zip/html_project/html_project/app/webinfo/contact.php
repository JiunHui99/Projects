<?php include '../header.php'; ?>
<?php
    $shop_name = "Bag Shop";
    $address = "3245 Grant Street, Longview, TX, United Kingdom 765378";
    $phone = "012-4567893";
    $email = "bagtohome@gmail.com";
?>

    <title>Contact Us - <?= $shop_name ?></title>
    <style>
        .container {
            width: 60%;
            margin: 120px auto;
            padding: 20px;
            border: 1px solid #000000;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background:rgb(255, 242, 242);
        }
    </style>

<!-- Contact Us Section -->
<div class="container">
<section class="contact-us">
    <div class="center-text">
        <h2>Contact Us</h2>
    </div>
    <p class="contact-description">
        📍 Address: <?= $address ?> <br>
        📞 Phone: <?= $phone ?> <br>
        📧 Email: <a href="mailto:<?= $email ?>"><?= $email ?></a>
    </p>
</div>    
</section>

<a href="/../index.php" class="back-btn">Back to Home</a>

<?php include'footer.php';?>

<style>
    .back-btn{
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
</style>