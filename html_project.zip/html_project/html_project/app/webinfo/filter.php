<section class="filter">
<form method="get" action="">
    <div class="filter-group">
        <select name="sort_name" id="name-filter" onchange="this.form.submit()">
            <option value="">Select Name Sorting</option>
            <option value="ASC" <?= isset($_GET['sort_name']) && $_GET['sort_name'] == 'ASC' ? 'selected' : '' ?>>Name A-Z</option>
            <option value="DESC" <?= isset($_GET['sort_name']) && $_GET['sort_name'] == 'DESC' ? 'selected' : '' ?>>Name Z-A</option>
        </select>
    </div>

    <div class="filter-group">
        <select name="sort_price" id="price-filter" onchange="this.form.submit()">
            <option value="">Select Price Sorting</option>
            <option value="ASC" <?= isset($_GET['sort_price']) && $_GET['sort_price'] == 'ASC' ? 'selected' : '' ?>>Price Low To High</option>
            <option value="DESC" <?= isset($_GET['sort_price']) && $_GET['sort_price'] == 'DESC' ? 'selected' : '' ?>>Price High To Low</option>
        </select>
    </div>
</form>
</section>

<style>

.filter{
    margin: 10px auto;
    padding:10px 10px;
    text-align: center;
}
.filter-group {
    margin: 5px auto;
}
.filter-group select{
    width: 30%;
    margin: 5px auto;
    padding: 10px;
    border-radius: 5px;
    background-color: aliceblue;
}
.filter-group:hover{
    transform: scale(1.05);
}
.filter-group::after {
    content: '\1F50D'; 
    font-size: 20px;
    margin-right: 5px;
    cursor: pointer;
}
</style>