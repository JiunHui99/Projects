<!-- About Us Section -->
<section class="about-us" id="about">
    <div class="center-text">
        <h2>About Us</h2>
    </div>
    <p class="about-description">
        At Bag To Home, we offer a stylish and durable collection of bags for every occasion—whether you need a chic handbag, a spacious travel bag, or a sturdy backpack, we've got you covered!
    </p>
</section>

<!-- Contact Section -->
<section class="contact">
    <div class="contact-info">
        <div class="first-info">
            <img src="../image/BAGTOHOME.png" alt="">
            <p>3245 Grant Street Longview, <br> TX United Kingdom 765378</p>
            <p>012-4567893</p>
            <p>bagtohome@gmail.com</p>

            <div class="social-icon">
                <a href="#"><i class='bx bxl-facebook'></i></a>
                <a href="#"><i class='bx bxl-twitter'></i></a>
                <a href="#"><i class='bx bxl-instagram'></i></a>
                <a href="#"><i class='bx bxl-youtube'></i></a>
                <a href="#"><i class='bx bxl-linkedin'></i></a>
            </div>
        </div>
        <div class="second-info">
            <h4>Support</h4>
            <a href="../webinfo/contact.php"><p>Contact us</p></a>
            <p>About page</p>
            <p>Size Guide</p>
            <p>Shopping & Returns</p>
            <p>Privacy</p>
            <p>FAQs</p>
        </div>
    </div>
</section>

<div class="end-text">
    <p>Copyright &copy; 2025. All Rights Reserved. Design By BAGTOHOME.</p>
</div>

<style>
.about-us {
    text-align: center;
    padding: 50px 20px;
    background-color: #fbdee3;
    border-top:1px solid #000000;
    border-bottom:1px solid #000000;
}
.about-us h2 {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 15px;
}
.about-description {
    font-size: 1.1rem;
    max-width: 800px;
    margin: 0 auto;
    line-height: 1.6;
}

.contact{
    background-color:#fbdee3 ;
    padding: 50px;
    text-align: center;
}
.contact-info{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, auto));
    gap: 3rem;
}
.first-info img{
    width: 200px;
    height: auto;
}
.contact-info h4{
    color: #24282c;
    font-size: 20px;
    text-transform: uppercase;
    margin-bottom: 10px;
}
.contact-info p{
    color: #3b3a3a;
    font-size: 18px;
    font-weight: 400;
    text-transform: capitalize;
    line-height: 1.5;
    margin-bottom: 10px;
    cursor: pointer;
    transition: all .42s;
}
.contact-info p:hover{
    color: #EE1C47;
}

.social-icon i{
    color: #565656;
    margin-right: 10px;
    font-size: 20px;
    transition:  all .42s;
}
.social-icon i:hover{
    transform: scale(1.3);
}

.end-text{
    background-color:#ffffff;
    text-align: center;
    padding: 20px;
    border-top:1px solid #000000;
    border-bottom:1px solid #000000;
}
.end-text p{
    color: #111;
    text-transform: capitalize;
}
</style>