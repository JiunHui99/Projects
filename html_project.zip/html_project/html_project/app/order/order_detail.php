<title>Order Details</title>
<?php include '../header.php';?>
<?php
session_start();
require '../db.php'; 

//get id
if (!isset($_GET['id']) || empty($_GET['id'])) {  
    die("Invalid order ID.");
}
$order_id = $_GET['id']; 

//get order details
$stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die("Order not found.");
}

// get order item
$stmt = $pdo->prepare("SELECT oi.quantity, oi.price, p.product_name 
                       FROM order_items oi 
                       JOIN products p ON oi.product_id = p.product_id 
                       WHERE oi.order_id = ?");
$stmt->execute([$order_id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="order-detail-header">
    <h2>Order Detail</h2>
</div>

<section class="order-detail">
<table>
    <tr>
        <th>Order ID</th>
        <th>Total Amount</th>
        <th>Status</th>
        <th>Date</th>
    </tr>
    <tr>
        <td><?= htmlspecialchars($order['order_id']) ?></td>
        <td>RM<?= htmlspecialchars($order['total_amount']) ?></td>
        <td><span><?= htmlspecialchars($order['status']) ?></span></td>
        <td><?= htmlspecialchars($order['created_at']) ?></td>
    </tr>
</table>

<table>
    <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Price</th>
    </tr>
    <?php foreach ($items as $item): ?>
        <tr>
            <td><?= htmlspecialchars($item['product_name']) ?></td>
            <td><?= htmlspecialchars($item['quantity']) ?></td>
            <td>RM <?= number_format($item['price'] * $item['quantity'], 2) ?></td>
        </tr>
    <?php endforeach; ?>
</table>

</section>

<div  class="back-btn">
<a href="/order/order_history.php">Back to Order History</a>
</div>

<?php include '../webinfo/footer.php'; ?>

<style>
.order-detail-header h2 {
    border: 1px solid #333;
    border-radius: 5px;
    background-color: floralwhite;
    width:20%;
    margin: 20px auto;
    padding: 10px;
    text-align: center;
}
.order-detail {
    width: 60%;
    margin: 30px auto;
    padding: 10px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color:rgb(255, 241, 241) ;
}
.order-detail table {
    width: 70%;
    margin: 30px auto;
    border-collapse: collapse;
    border: 1px solid #333;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
.order-detail th, td {
    padding: 12px;
    border: 1px solid #333;
    text-align: center;
}
.order-detail th {
    background:rgb(255, 234, 185);
    padding: 10px;
    font-size: 18px;
}
.order-detail td{
    background-color: white;
    text-align: center;
    padding: 5px;
}
.order-detail td span{
    color: red;
}
.back-btn a{
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px;
    margin-left: 62%;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn a:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
</style>