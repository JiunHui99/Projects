<title>Order Success</title>
<?php include'../header.php';?>

<?php
session_start();
include '../db.php'; 

if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit;
}

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

if ($order_id == 0) {
    header("Location: ../index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    header("Location: ../index.php");
    exit;
}
?>

<section class="order-success-container">
    <h2>Order Confirmed</h2>
    <p>Your order has been placed <span class="success-text">successfully</span>.</p>
    <p>Order ID: <strong>#<?= $order['order_id'] ?></strong></p>
    <p>Total Amount: <strong>RM<?= number_format($order['total_amount'], 2) ?></strong></p>
    <p>Status: <strong><?= htmlspecialchars($order['status']) ?></strong></p>

    <a href="/order/order_history.php" class="view-orders-btn">View Orders</a>
</section>

<?php include '../webinfo/footer.php'; ?>

<style>
.order-success-container {
    max-width: 500px;     
    margin: 150px auto;   
    padding: 20px;
    background:rgb(255, 241, 241);
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    border: 1px solid #333;
    border-radius: 5px;
    text-align: center; 
}

.order-success-container h1 {
    font-size: 24px;
    font-weight: bold;
    margin: 10px;
}
.order-success-container p {
    font-size: 18px;
    margin: 10px;
}
.view-orders-btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: azure;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
}
.view-orders-btn:hover {
    background-color: rgba(149, 248, 247, 0.81); 
}
.success-text {
    color: green;
    font-weight: bold;
}
</style>