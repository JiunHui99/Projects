
<title>Order History</title>
<?php include '../header.php';?>

<?php
session_start();
require '../db.php';

//user login verification
if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// check user order
$stmt = $pdo->prepare("SELECT order_id, total_amount, status, created_at FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="order-history-header">
    <h2>Order History</h2>
</div>
<section class="order-history">
<table border="1">
    <tr>
        <th>Order ID</th>
        <th>Total Amount</th>
        <th>Status</th>
        <th>Date</th>
        <th>Action</th>
    </tr>
    <?php foreach ($orders as $order): ?>
        <tr>
            <td><?= htmlspecialchars($order['order_id']) ?></td>
            <td>RM<?= htmlspecialchars($order['total_amount']) ?></td>
            <td><?= htmlspecialchars($order['status']) ?></td>
            <td><?= htmlspecialchars($order['created_at']) ?></td>
            <td><a href="/order/order_detail.php?id=<?= $order['order_id'] ?>">View Details</a></td>
        </tr>
    <?php endforeach; ?>
</table>

<div class="back-btn">
<a href="../user/profile.php">Back to Profile</a>
<a href="/../index.php">Back to Home</a>
</div>
</section>

<?php include '../webinfo/footer.php'; ?>

<style>
.order-history-header h2{
    border: 1px solid #333;
    border-radius: 5px;
    background-color: floralwhite;
    width:20%;
    margin: 20px auto;
    padding: 10px;
    text-align: center;
}
.order-history{
    width: 80%;
    margin: 30px auto;
    padding: 10px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color:rgb(255, 241, 241) ;
}
.order-history table {
    width: 85%;
    margin: 30px auto;
    border-collapse: collapse;
    border: 1px solid #333;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
.order-history th {
    background:rgb(255, 234, 185);
    padding: 10px;
    font-size: 18px;
}
.order-history td{
    background-color: white;
    text-align: center;
    padding: 5px;
}
.order-history  a{
    width: 60%;
    margin: 10px auto;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(111, 255, 253, 0.38);
    font-size: 16px;
    color: black;
    padding: 6px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
}
.order-history a:hover {
    background-color:rgb(64, 251, 248);
}
.back-btn a{
    background-color: rgba(199, 225, 249, 0.78);
    width: 300px;
    height: 60px;
    margin: 20px;
    margin-left: 70%;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn a:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
</style>