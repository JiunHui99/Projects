

window.addEventListener ("scroll", function(){
    header.classList.toggle ("sticky", this.window.scrollY > 0);
})

let menu = document.querySelector('#menu-icon');
let navmenu = document.querySelector('.navmenu');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navmenu.classList.toggle('open');
}

document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function(event) {
        event.preventDefault();

        let productId = this.getAttribute('data-id');
        let quantity = prompt("Enter quantity:", "1");

        if (quantity !== null && quantity > 0) {
            fetch('add_to_cart.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `product_id=${productId}&quantity=${quantity}`
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.status === 'success') {
                    document.querySelector("#cart-count").textContent++;  
                }
            })
            .catch(error => console.error("Error:", error));
        }
    });
});

document.getElementById("cart-btn").addEventListener("click", function() {
    window.location.href = "cart.php"; 
});
