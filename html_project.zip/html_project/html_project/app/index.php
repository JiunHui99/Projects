<!DOCTYPE html>
<html lang="en">

<?php include'header.php';?>
         
    <section class="main-home" style="background-image: url(image/banner-1.png);" >
        <div class="main-text">

            <h5>Summer Collection</h5>
            <h1>New Summer <br> Collection 2025</h1>
            <p>There's Nothing like Trend</p>
            <a href='product/newin.php' class="main-btn">Shop Now <i class='bx bx-right-arrow-alt'></i></a>

        </div>
    </section>

    <section class="cat-icon" >

        <a href="category/backpack.php"><img src="../image/Backpack.png"></a>
        <a href="category/crossbodybag.php"><img src="../image/Crossbody.png"></a>
        <a href="category/handlebag.php"><img src="../image/Handle.png"></a>
        <a href="category/shoulderbag.php"><img src="../image/Shoulder.png"></a>
        <a href="category/totebag.php"><img src="../image/Tote.png"></a>

        <a href="product/products.php">See <span>All Product</span><i class='bx bx-chevron-right'></i></a>
    </section>

    <section class="main-home" style="background-image: url(../image/banner-3.jpg);" >
    <div class="main2-text">

        <h5>New Year New LOOK!</h5>
        <h1>New Arival<br> Last Month</h1>
        <p>--------------------------</p>
            <!-- Shop Now button to #trending -->
        <a href='product/newin.php' class="main-btn">Shop Now <i class='bx bx-right-arrow-alt'></i></a>

</div>
        </section>

    <!-- Client Reviews Section -->
<section class="class-reviews">
    <?php
    $reviews = [
        ["image" => "../image/team1.jpg", "text" => "[BAGTOHOME] offers a seamless shopping experience with a great selection of high-quality bags, easy navigation, secure checkout, and excellent customer service.", "name" => "Marisa Tam", "title" => "CEO of Addle"]
    ];
    ?>
    <div class="reviews">
        <h3>Client Reviews</h3>
        <?php foreach ($reviews as $review): ?>
            <img src="<?= $review['image'] ?>" alt="">
            <p><?= $review['text'] ?></p>
            <h2><?= $review['name'] ?></h2>
            <p><?= $review['title'] ?></p>
        <?php endforeach; ?>
    </div>
</section>
<section class="poster-list">
<!-- Update Section -->
    <div class="poster">
        <img src="../image/bl-1.jpg" alt="">
        <h5>20 JAN 2025</h5>
        <h4>Let's start bringing sales on this summer vacation.</h4>
        <h5>Continue Reading...</h5>
    </div>

    <div class="poster">
        <img src="image/bl-2.jpg" alt="">
        <h5>26 JAN 2025</h5>
        <h4>Let's start bringing in more sales and get our bags into more hands!</h4>
        <h5>Continue Reading...</h5>
    </div>

    <div class="poster">
        <img src="image/bl-3.webp" alt="">
        <h5>28 JAN 2025</h5>
        <h4>Let's showcase our stylish bags and increase sales today!</h4>
        <h5>Continue Reading...</h5>
    </div>
    </section>

<?php include 'webinfo/footer.php';?>

</html>