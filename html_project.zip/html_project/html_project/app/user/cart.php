<?php
session_start();
include '../db.php';

// verify user login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// update cart
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_cart'])) {
    $cart_id = $_POST['cart_id'];
    $new_quantity = intval($_POST['quantity']);

    // get stock
    $stmt = $pdo->prepare("SELECT stock FROM products WHERE product_id = (SELECT product_id FROM carts WHERE carts_id = ?)");
    $stmt->execute([$cart_id]);
    $stock = $stmt->fetchColumn();

    if ($new_quantity > $stock) {
        header("Location: /user/cart.php?error=Not enough stock available! Please enter again.");
        exit;
    } else {
        $stmt = $pdo->prepare("UPDATE carts SET quantity = ? WHERE carts_id = ? AND user_id = ?");
        $stmt->execute([$new_quantity, $cart_id, $user_id]);
        header("Location: /user/cart.php?success=Cart updated successfully!");
        exit;
    }
}

// remove cart item
if (isset($_GET['remove'])) {
    $cart_id = $_GET['remove'];
    $stmt = $pdo->prepare("DELETE FROM carts WHERE carts_id = ? AND user_id = ?");
    $stmt->execute([$cart_id, $user_id]);
    header("Location: /user/cart.php?success=Item removed from cart.");
    exit;
}

// get cart item
$searchTerm = isset($_GET['search']) ? '%' . $_GET['search'] . '%' : '%';
$stmt = $pdo->prepare("SELECT c.*, p.product_name, p.image, p.price, p.stock 
                       FROM carts c 
                       JOIN products p ON c.product_id = p.product_id 
                       WHERE c.user_id = ? AND p.product_name LIKE ?");
$stmt->execute([$user_id, $searchTerm]);
$cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// count total price
$total = 0;
foreach ($cartItems as $item) {
    $total += $item['price'] * $item['quantity'];
}

//get user information
$stmt = $pdo->prepare("SELECT user_name, email, profile_photo, role , address  FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

//get random products
$stmt = $pdo->prepare("SELECT product_id, product_name, price, image FROM products ORDER BY RAND() LIMIT 3");
$stmt->execute();
$recommend_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<title>My Cart</title>
<?php include '../header.php'; ?>

<h1>Shipping Information</h1>

<section class="shipping-information">

    <div class="info">
        <p><strong>Name : </strong><?= htmlspecialchars($user['user_name']) ?></p>
        <p><strong>Email : </strong><?= htmlspecialchars($user['email']) ?></p>
        <p><strong>Address : </strong><?= htmlspecialchars($user['address']) ?></p>
    </div>

    <div class="editInfo">
        <a href="/user/profile.php/">Edit Info</a>
    </div>
</section>

<div class="search-box">
    <form method="get" action="cart.php">
        <input type="text" name="search" placeholder="Search in cart..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        <button type="submit">Search</button>
    </form>
</div>

<h1>Shopping Cart</h1>

<section class="cart-container">
    <?php if (isset($_GET['success'])): ?>
        <p class="success-message"><?= htmlspecialchars($_GET['success']) ?></p>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
        <p class="error-message"><?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>
    
    <?php if (!empty($cartItems)): ?>
        <!-- Create a single checkout form but place it outside the table -->
        <form method="post" action="checkout.php" id="checkout-form">
            <table>
                <tr>
                    <th>Select</th>
                    <th>Image</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($cartItems as $item): ?>
                    <tr>
                        <td>
                            <!-- Place checkboxes inside the single checkout form -->
                            <input type="checkbox" name="selected_items[]" value="<?= $item['carts_id'] ?>">
                        </td>
                        <td><img src="../image/<?= htmlspecialchars($item['image']) ?>"></td>
                        <td><?= htmlspecialchars($item['product_name']) ?></td>
                        <td>RM <?= number_format($item['price'], 2) ?></td>
                        <td>
                            <!-- Keep quantity update form separate -->
                            <form method="post" action="cart.php">
                                <input type="hidden" name="cart_id" value="<?= $item['carts_id'] ?>">
                                <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>">
                                <button type="submit" name="update_cart" class="update-btn">Update</button>
                            </form>
                        </td>
                        <td>RM <?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                        <td>
                            <a href="../user/cart.php?remove=<?= $item['carts_id'] ?>" class="remove-btn" onclick="return confirm('Remove this item?')">Remove</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <h3>Total: RM<?= number_format($total, 2) ?></h3>
            <button type="submit" class="checkout-btn">Proceed to Checkout</button>
        </form>

    <?php else: ?>
        <?php if (isset($_GET['search']) && trim($_GET['search']) !== ''): ?>
            <p class="empty-cart">No matching products found in your cart.</p>
        <?php else: ?>
            <p class="empty-cart">Your cart is empty.</p>
        <?php endif; ?>
    <?php endif; ?>
</section>

<?php include '../product/recommend_products.php'; ?>
<?php include '../webinfo/footer.php'; ?>

<style>
    h1 {
        border: 1px solid #333;
        border-radius: 5px;
        background-color: floralwhite;
        width: 20%;
        margin: 20px auto;
        padding: 10px;
        text-align: center;
    }

    .shipping-information {
        width: 90%;
        height: auto;
        background: rgb(255, 241, 241);
        border: 1px solid #888;
        border-radius: 10px;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        padding: 10px;
        margin: 20px auto;
    }

    .info {
        background-color: white;
        padding: 15px;
        margin: 20px;
    }

    .info p {
        border: 1px solid #888;
        border-radius: 5px;
        margin: 10px;
        padding: 10px;
        font-size: 16px;
        color: rgba(141, 46, 219, 0.8);
        background-color: aliceblue;
    }

    .info strong {
        font-size: 18px;
        color: black;
    }

    .editInfo a {
        max-width: 250px;
        margin: 10px;
        margin-left: 90%;
        background-color: rgb(190, 255, 205);
        color: black;
        padding: 10px 15px;
        border: 1px solid #333;
        border-radius: 5px;
        display: inline-block;
    }

    .editInfo a:hover {
        background-color: rgb(68, 255, 109);
        transform: scale(1.03);
    }

    .cart-container {
        width: 90%;
        height: auto;
        background: rgb(255, 241, 241);
        margin: 30px auto;
        padding: 20px;
        border: 1px solid #888;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    .cart-container img {
        width: 50%;
        margin: 10px auto;
        height: 25vh;
        border: 1px solid #333;
        border-radius: 5px;
    }

    .cart-container table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    .cart-container th,
    td {
        border: 1px solid #333;
        padding: 10px;
        text-align: center;
    }

    .cart-container th {
        background: rgba(255, 243, 214, 0.96);
        font-size: 20px;
    }

    .cart-container td {
        background-color: white;
        font-size: 18px;
    }

    .cart-container h3 {
        margin: 10px;
    }

    .success-message {
        color: green;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .error-message {
        color: red;
        font-weight: bold;
    }

    .update-btn {
        background-color: rgb(190, 255, 205);
        color: black;
        padding: 5px 10px;
        border: 1px solid #333;
        border-radius: 5px;
        cursor: pointer;
    }

    .update-btn:hover {
        background-color: rgb(68, 255, 109);
        transform: scale(1.03);
    }

    .remove-btn {
        background-color: rgb(255, 173, 181);
        color: black;
        padding: 5px 10px;
        border: 1px solid #333;
        border-radius: 5px;
        display: inline-block;
    }

    .remove-btn:hover {
        background-color: rgb(255, 39, 60);
        transform: scale(1.03);
    }

    .checkout-btn {
        max-width: 250px;
        margin: 10px;
        background-color: rgb(174, 255, 254);
        color: black;
        padding: 10px 15px;
        border: 1px solid #333;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
        display: inline-block;
        text-transform: capitalize;
        font-size: 18px;
        font-weight: 500;
    }

    .checkout-btn:hover {
        background-color: rgb(64, 251, 248);
        transform: scale(1.03);
    }

    .empty-cart {
        font-size: 18px;
        color: #888;
    }

    .search-box form {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 60%;
        margin: 10px auto;
    }

    .search-box input {
        width: 500px;
        margin: 10px;
        padding: 10px;
        font-size: 16px;
        border: 1px solid #333;
    }

    .search-box button {
        padding: 8px 15px;
        font-size: 16px;
        border: 1px solid #333;
        border-radius: 5px;
        background-color: rgba(74, 164, 248, 0.78);
        color: black;
        cursor: pointer;
    }

    .search-box button:hover {
        background-color: rgba(143, 219, 240, 0.78);
        transform: scale(1.1);
    }
</style>