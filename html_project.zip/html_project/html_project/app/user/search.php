<title>Search</title>
<?php include'../header.php';?>

<?php
require '../db.php'; 
session_start();

// Get search query from URL
$search = isset($_GET['query']) ? trim($_GET['query']) : '';

if ($search) {
    // Fetch products matching the search query
    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_name LIKE :search OR description LIKE :search ");
    $stmt->execute(['search' => "%$search%"]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $products = [];
}
?>

<section class="search">
<h2>Results for "<span><?= htmlspecialchars($search) ?></span>"</h2>
    <?php if (!empty($products)): ?>
        <div class="search-products">
        <?php foreach($products as $row): ?>
        <div class="search-pro-list">
            <a href="../product/product_detail.php?id=<?= htmlspecialchars($row["product_id"]) ?>">
                <img src="../image/<?= htmlspecialchars($row["image"]) ?>">
            </a>
            <h1><?= htmlspecialchars($row["product_name"]) ?></h1>
            <p><?= htmlspecialchars($row["description"]) ?></p>
            <p>RM: <strong><?= number_format($row["price"], 2) ?></strong></p>
            <form action="../user/add_to_cart.php" method="POST">
                <input type="hidden" name="product_id" value="<?= htmlspecialchars($row["product_id"]) ?>">
                <input type="number" name="quantity" value="1" min="1" max="<?= htmlspecialchars($row["stock"]) ?>">
                <button type="submit" class="add-to-cart">Add to Cart</button>
            </form>
        </div>
    <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="no-results">No products found for "<strong><?= htmlspecialchars($search) ?></strong>". Try searching again.</p>
    <?php endif; ?>
</section>

<?php include '../product/recommend_products.php';?>
<?php include '../webinfo/footer.php'; ?>

<style>
.search{
    border:1px solid #000000;
    width: 70%;
    height: auto;
    margin: 40px auto;
    padding: 20px;
    align-items: center;
    background-color: rgba(255, 243, 243, 0.78);
}
.search h2{
    text-align: center;
    font-size: 23px;
    font-weight: bold;
    margin: 10px auto;
}
.search span{
    color:red;
}
.search-products{
    background-color: white;
    border: 1px solid #000000;
    border-radius: 10px;
    margin:20px auto;
    padding: 10px 40px;
    max-width: 90%;
    display: flex;
    justify-content: center;
    align-items: center;
}
.search-pro-list{
    text-align: center;
    padding:20px 10px;
}
.search-pro-list:hover{
    transform: scale(1.05);
}
.search-pro-list img{
    border:1px solid rgb(136, 136, 136);
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
    width: 100%; 
    height: 30vh; 
}
.search-pro-list h1{
    color:rgb(0, 0, 0);
    margin: 10px;
    font-size: 20px;
}
.search-pro-list strong{
    color: rgba(102, 7, 175, 0.65);
    font-size: 15px;
}
.search-pro-list p{
    margin: 5px;
}
.add-to-cart{
    padding: 5px 10px;
    background-color: floralwhite;
    border: 1px solid #333;
    border-radius: 5px;
}
.add-to-cart:hover{
    background-color: papayawhip;
    transform: scale(1.05);
}
.no-results {
    text-align: center;
    font-size: 18px;
    color: #888;
}
</style>
