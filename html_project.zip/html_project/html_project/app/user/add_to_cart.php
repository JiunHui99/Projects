<?php
session_start();
include '../db.php';

// login verify
if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit;
}

$user_id = $_SESSION['user_id']; 
$product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

// ensure available stock
if ($product_id <= 0 || $quantity <= 0) {
    header("Location: ../product/products.php?error=Invalid product selection.");
    exit;
}

//get stock
$stmt = $pdo->prepare("SELECT stock FROM products WHERE product_id = ?");
$stmt->execute([$product_id]);
$stock = $stmt->fetchColumn();

if ($stock === false) {
    header("Location: ../product/products.php?error=Product not found.");
    exit;
}

// check exist product
$stmt = $pdo->prepare("SELECT carts_id, quantity FROM carts WHERE user_id = ? AND product_id = ?");
$stmt->execute([$user_id, $product_id]);
$cartItem = $stmt->fetch(PDO::FETCH_ASSOC);

if ($cartItem) {
    //calculate new quantity
    $new_quantity = $cartItem['quantity'] + $quantity;
    if ($new_quantity > $stock) {
        header("Location: ../product/products.php?error=Not enough stock.");
        exit;
    }

 

   // for succesfull update
   header("Location: ../user/cart.php?success=Item quantity updated.");
   exit;
} else {
   // add item to cart
   if ($quantity > $stock) {
       header("Location: ../product/products.php?error=Not enough stock.");
       exit;
   }

   $stmt = $pdo->prepare("INSERT INTO carts (user_id, product_id, quantity) VALUES (?, ?, ?)");
   if ($stmt->execute([$user_id, $product_id, $quantity])) {
       // success msg
       header("Location: ../user/cart.php?success=Item added to cart.");
       exit;
   } else {
       header("Location: ../product/products.php?error=Failed to add item.");
       exit;
   }
}
?>