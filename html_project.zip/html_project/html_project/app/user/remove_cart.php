<?php
session_start();

if (isset($_GET['remove']) && isset($_SESSION['cart'][$_GET['remove']])) {
    unset($_SESSION['cart'][$_GET['remove']]);
}

header("Location: ../user/cart.php");
exit();
?>