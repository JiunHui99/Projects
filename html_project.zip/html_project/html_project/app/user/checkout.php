
<title>Checkout</title>
<?php include '../header.php'; ?>

<?php
session_start();
include '../db.php';

// login verify
if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$cartItems = [];
$total = 0;

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['checkout'])) {
    header("Location: ../user/create_order.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['selected_items'])) {
    $selectedItems = $_POST['selected_items'];

    if (empty($selectedItems)) {
        header("Location: ../user/cart.php?error=Please select items to checkout.");
        exit;
    }

    $placeholders = implode(',', array_fill(0, count($selectedItems), '?'));
    $query = "SELECT c.*, p.product_name, p.image, p.price, p.stock 
              FROM carts c 
              JOIN products p ON c.product_id = p.product_id 
              WHERE c.carts_id IN ($placeholders) AND c.user_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([...$selectedItems, $user_id]);
    $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($cartItems)) {
        header("Location: ../user/cart.php?error=Invalid items selected!");
        exit;
    }

    foreach ($cartItems as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    $_SESSION['checkout_items'] = $selectedItems;

} else {
    header("Location: ../user/cart.php?error=Access denied or no items selected.");
    exit;
}
?>

<section class="checkout-container">
    <h2>Checkout</h2>

    <div class="checkout-table">
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
        </tr>
        <?php foreach ($cartItems as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['product_name']) ?></td>
                <td><?= $item['quantity'] ?></td>
                <td>RM<?= number_format($item['price'], 2) ?></td>
                <td>RM<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h3>Total: RM<?= number_format($total, 2) ?></h3>

    <form method="post">
        <button type="submit" name="checkout" class="checkout-btn">Confirm Order</button>
    </form>
    </div>

    
<a href="/user/cart.php" class="back-btn">Back to Cart</a>

</section>

<?php include '../product/recommend_products.php';?>
<?php include'../webinfo/footer.php';?>

<style>
.checkout-container {
    max-width: 80%;
    margin: 120px auto;
    padding: 20px;
    background: #ffffff;
    border: 1px solid #333;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    text-align: center;
}
.checkout-container h2 {
    margin-bottom: 20px;
}
.checkout-table table{
    width: 100%;
    margin: 30px auto;
    border-collapse: collapse;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    padding: 12px;
    text-align: center;
}
th,td{
    padding: 12px;
    border: 1px solid #333;
    text-align: center;
}
th {
    background:rgb(255, 241, 241);
    padding: 10px;
    font-size: 18px;
}
td{
    text-align: center;
    padding: 10px;
}
.checkout-container h3{
    margin: 10px;
}
.checkout-btn {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    background:rgb(177, 254, 195);
    color: black;
    border: 1px solid #333;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s ease;
}
.checkout-btn:hover {
    background:rgb(42, 255, 88);
}
.back-btn{
    max-width: 250px;
    margin: 10px;
    background-color: rgb(174, 255, 254);
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
    display: inline-block;
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgb(64, 251, 248);
}
</style>