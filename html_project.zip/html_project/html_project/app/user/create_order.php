<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /user/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if there is a selected item
if (!isset($_SESSION['checkout_items']) || empty($_SESSION['checkout_items'])) {
    header("Location: /user/cart.php?error=No items selected for checkout.");
    exit;
}

$selectedItems = $_SESSION['checkout_items'];

// Get the selected shopping cart item details
$placeholders = implode(',', array_fill(0, count($selectedItems), '?'));
$sql = "SELECT c.carts_id, c.product_id, c.quantity, p.price, p.stock 
        FROM carts c 
        JOIN products p ON c.product_id = p.product_id 
        WHERE c.carts_id IN ($placeholders) AND c.user_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([...$selectedItems, $user_id]);
$cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($cartItems)) {
    header("Location: /user/cart.php?error=Invalid or empty items.");
    exit;
}

// calculate total & check stock
$total = 0;
foreach ($cartItems as $item) {
    if ($item['quantity'] > $item['stock']) {
        header("Location: /user/cart.php?error=Insufficient stock for some items.");
        exit;
    }
    $total += $item['price'] * $item['quantity'];
}

// insert order
$stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount, status, order_date) VALUES (?, ?, 'Pending', NOW())");
$stmt->execute([$user_id, $total]);
$order_id = $pdo->lastInsertId();

// insert order item
$stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
foreach ($cartItems as $item) {
    $stmt->execute([$order_id, $item['product_id'], $item['quantity'], $item['price']]);
}

// renew stock
$stmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE product_id = ?");
foreach ($cartItems as $item) {
    $stmt->execute([$item['quantity'], $item['product_id']]);
}

// delete the item when already buy
$deleteStmt = $pdo->prepare("DELETE FROM carts WHERE carts_id = ? AND user_id = ?");
foreach ($cartItems as $item) {
    $deleteStmt->execute([$item['carts_id'], $user_id]);
}

// clear session
unset($_SESSION['checkout_items']);

// jump to succeessfull page
header("Location: ../order/order_success.php?order_id=$order_id");
exit;
?>