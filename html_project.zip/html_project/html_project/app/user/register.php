<title>Register</title>
<?php include '../header.php'; ?>

<?php
session_start();
require '../db.php';

// Handle registration
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() > 0) {
        $error = "Email already registered!";
    } else {
        // Always register as a normal user
        $role = "user";

        $stmt = $pdo->prepare("INSERT INTO users (user_name, email, password, role) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$name, $email, $password, $role])) {
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['user_name'] = $name;
            $_SESSION['user_role'] = $role;

            header("Location: /../index.php");
            exit;
        } else {
            $error = "Registration failed. Please try again!";
        }
    }
}
?>

<div class="register-container">
    <h2>Register</h2>

    <?php if (isset($error)) : ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form action="/user/register.php" method="POST">
        <label>Name</label>
        <input type="text" name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button type="submit">Register</button>
    </form>

    <p>Already have an account? <a href="/user/login.php">Login here</a></p>
</div>

<style>
.register-container {
    background-color: rgba(255, 245, 245, 0.86);
    padding: 30px;
    margin: 50px auto;
    border: 1px solid #000;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    width: 380px;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.register-container h2{
    border: 1px solid #333;
    background-color: floralwhite;
    width:70%;
    margin: 15px auto;
    padding: 10px;
    text-align: center;
    font-size: 25px;
    font-weight: bold;
    text-align: center;
}

.register-container label{
    font-size: 20px;
}

.register-container input {
    width: 100%;
    padding: 10px;
    margin: 20px auto;
    border: 1px solid #000;
    border-radius: 5px;
}

.register-container button {
    display: flex;
    justify-content: center;
    align-items: center;
    width:50%;
    margin:10px auto;
    padding: 10px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color:rgba(193, 255, 162, 0.78);
    cursor: pointer;
    font-size: 18px;
}

.register-container button:hover {
    background-color: rgba(97, 255, 168, 0.78);
    transform: scale(1.1);
}

.register-container p{
    font-size: 16px;
}

.register-container a{
    font-size: 18px;
}

.error {
    color: red;
    font-size: 14px;
}
</style>