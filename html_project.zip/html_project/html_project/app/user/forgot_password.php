
<title>Forgot Password</title>
<?php include '../header.php';?>

<?php
session_start();
require '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);

    // check exist user
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // generate one token
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour')); //expried after 1 hours

        // update database
        $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE email = ?");
        $stmt->execute([$token, $expiry, $email]);

        // send email
        $reset_link = "http://yourwebsite.com/reset_password.php?token=$token";
        $subject = "Password Reset Request";
        $message = "Click the following link to reset your password: $reset_link\nThis link expires in 1 hour.";
        
        mail($email, $subject, $message, "From: no-reply@yourwebsite.com");

        $_SESSION['success'] = "A password reset link has been sent to your email.";
    } else {
        $_SESSION['error'] = "Email not found!";
    }

    header("Location: /user/forgot_password.php");
    exit;
}
?>

<div class="forgot-password-container">
    <h2>Forgot Password</h2>
    
    <?php if (isset($_SESSION['success'])): ?>
        <p class="success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <p class="error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>

    <form method="post">
        <label>Email:</label>
        <input type="email" name="email" required>
        <button type="submit">Send Reset Link</button>
    </form>
</div>

<style>
.forgot-password-container {
    background: white;
    padding: 40px;
    margin: 50px auto;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    width: 350px;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.forgot-password-container input, button {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    display: inline-block;
    color: #111;
    font-size: 16px;
    font-weight: 500;
    border: 2px solid #111;
    padding: 12px 25px;
    transition: all .42s ease;
    }
.forgot-password-container button:hover {
    background-color: #000;
    color: #fff;
}
.error {
    color: red;
    font-size: 14px;
}
</style>
