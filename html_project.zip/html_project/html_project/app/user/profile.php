<title>Profile</title>
<?php include'../header.php';?>

<?php
session_start();
require '../db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /user/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details including role
$stmt = $pdo->prepare("SELECT user_name, email, profile_photo, role , address  FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $updateStmt = $pdo->prepare("UPDATE users SET user_name = ?, email = ? , address = ? WHERE user_id = ?");
    $updateStmt->execute([$user_name, $email, $address, $user_id]);

    $_SESSION['success'] = "Profile updated successfully!";
    header("Location: /user/profile.php");
    exit;
}

// Handle Password Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    // Verify current password
    $passStmt = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
    $passStmt->execute([$user_id]);
    $stored_password = $passStmt->fetchColumn();

    if (password_verify($current_password, $stored_password)) {
        $updatePassStmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
        $updatePassStmt->execute([$new_password, $user_id]);

        $_SESSION['success'] = "Password updated successfully!";
    } else {
        $_SESSION['error'] = "Current password is incorrect!";
    }
    header("Location: /user/profile.php");
    exit;
}

// Handle Profile Photo Upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['upload_photo'])) {
    $target_dir = "../uploads/";

    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $file_name = time() . "_" . basename($_FILES["profile_photo"]["name"]); // avoid same name
    $target_file = $target_dir . $file_name;
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    //set photo types
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

    if (!in_array($file_type, $allowed_types)) {
        $_SESSION['error'] = "Only JPG, JPEG, PNG & GIF files are allowed.";
    } elseif ($_FILES["profile_photo"]["size"] > 5000000) {
        $_SESSION['error'] = "File is too large. Max size is 5MB.";
    } elseif (move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $target_file)) {
        // update profile_photo
        $updatePhotoStmt = $pdo->prepare("UPDATE users SET profile_photo = ? WHERE user_id = ?");
        $updatePhotoStmt->execute([$target_file, $user_id]);

        $_SESSION['success'] = "Profile photo updated!";
    } else {
        $_SESSION['error'] = "Error uploading file!";
    }

    header("Location: ../user/profile.php");
    exit;
}
?>

<section class="profile-container">
<div class="profile-section">
    <h2>My Profile</h2>
        <img src="<?= htmlspecialchars($user['profile_photo'] ?: '../image/default-profile.jpg') ?>" alt="Profile Photo">

    <?php if (isset($_SESSION['success'])): ?>
        <p class="success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <p class="error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>

    <form method="post">
        <label>Name:</label>
        <input type="text" name="user_name" value="<?= htmlspecialchars($user['user_name']) ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

        <label>Address:</label>
        <input type="address" name="address" value="<?=htmlspecialchars($user['address'])?>"required>

        <button type="submit" name="update_profile">Update Profile</button>
    </form>

    <div class="profile-photo">
    <h3>Update Profile Photo</h3>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="profile_photo" accept="image/*" required>
        <button type="submit" name="upload_photo">Upload Photo</button>
    </form>
    </div>
</div>

<div class="password-section">
    <h2>Change Password</h2>
    <form method="post">
        <label>Current Password:</label>
        <input type="password" name="current_password" required>

        <label>New Password:</label>
        <input type="password" name="new_password" required>

        <button type="submit" name="update_password">Update Password</button>
    </form>
</div>

<div  class="logout-btn">
    <a href="/user/logout.php">Logout</a>
</div>

<div class="back-btn">
    <a href="/../index.php">Back To Home</a>
</div>

</section>

<div>
    <a href="/../order/order_history.php" class="history-btn">View Order History</a>
</div>


<?php include'../webinfo/footer.php';?>

<style>
.profile-container {
    flex-wrap: wrap;
    max-width: 80%;
    margin: 30px auto;
    padding: 60px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color: floralwhite;
    align-items: center;
}
.profile-section {
    width: 90%;
    margin: 5px auto;
    padding: 30px;
    text-align: center;
    border: 1px solid #333;
    border-radius: 5px;
    background-color: rgba(255, 243, 243, 0.78);
}
.profile-section h2{
    margin-bottom:20px;
}
.profile-section img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    object-fit: cover;
    margin-bottom: 15px;
}
.profile-section form {
    margin-bottom: 30px; 
}
.profile-section label{
    margin: 10px;
}
.profile-section input {
    width: 90%;
    padding: 10px;
    margin: 8px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color: white;
}
.profile-section button {
    width: 100%;
    padding: 12px;
    margin-top: 15px;
    background-color:rgb(145, 255, 169);
    border:1px solid dimgray;
    color: black;
    border-radius: 5px;
    cursor: pointer;
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.profile-section button:hover {
    background-color:rgb(0, 221, 52);
    transform: scale(1.03);
}

.password-section{
    width: 90%;
    margin: 30px auto;
    margin-bottom: 50px;
    padding: 30px;
    text-align: center;
    border: 1px solid #333;
    border-radius: 5px;
    background-color: white;
}
.password-section h2{
    margin-bottom:20px;
}
.password-section form{
    margin-bottom: 30px; 
}
.password-section label{
    display: flex;
    margin: 10px;
}
.password-section input {
    width: 90%;
    padding: 10px;
    margin: 8px ;
    border: 1px solid #333;
    border-radius: 5px;
}
.password-section button {
    width: 100%;
    padding: 12px;
    margin-top: 15px;
    background-color:rgb(145, 255, 169);
    border:1px solid #333;
    color: black;
    border-radius: 5px;
    cursor: pointer;
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.password-section button:hover {
    background-color:rgb(0, 221, 52);
    transform: scale(1.03);
}
.logout-btn{
    background-color: rgba(249, 112, 112, 0.91);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 10px auto;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.logout-btn a{
    color: black;
}
.logout-btn:hover {
    background-color: lightcoral;
    transform: scale(1.1);
    color: black;
}
.back-btn a{
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn a:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
.history-btn {
    background-color: rgba(74, 164, 248, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 10px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.history-btn:hover {
    background-color: aquamarine;
    transform: scale(1.1);
}
</style>