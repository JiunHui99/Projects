
<?php
require '../db.php';

$stmt = $pdo->prepare("SELECT product_id, product_name, price, image FROM products ORDER BY RAND() LIMIT 3");
$stmt->execute();
$recommend_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<section class="recommend-products">
    <h2>You May Also Like</h2>
    <div class="re-product-list">
        <?php foreach ($recommend_products as $item): ?>
            <div class="re-product-card">
                <a href="/product/product_detail.php?id=<?= $item['product_id'] ?>">
                <img src="../image/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['product_name']) ?>">
                <h3><?= htmlspecialchars($item['product_name']) ?></h3>
                <p>RM <?= number_format($item['price'], 2) ?></p>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="more">
        <a href="/product/products.php">Some More >> </a>
    </div>
</section>

<style>

.recommend-products{
    width:80%;
    border-radius: 5px;
    border: 1px solid #888;
    margin: 30px auto;
    padding: 20px;
}
.recommend-products h2{
    border: 1px solid #333;
    border-radius: 5px;
    background-color: floralwhite;
    width:300px;
    margin: 5px auto;
    padding: 10px;
    text-align: center;
}
.re-product-list {
    display: flex;
    justify-content: center;
    align-items: center;
    border: 1px solid #888;
    border-radius: 5px;
    background:rgb(255, 241, 241);
    width: 80%;
    margin: 20px auto;
    padding: 10px;
}
.re-product-card {
    width:250px;
    height:auto;
    margin:20px;
    padding:20px;
    border: 1px solid #888;
    border-radius: 10px;
    background-color: white;
    transition: transform 0.3s;
}
.re-product-card:hover {
    transform: scale(1.05);
}
.re-product-card img {
    width:100%;
    height:25vh;
}
.re-product-card h3{
    color: #333;
}
.re-product-card p {
    font-size: 18px;
    color: #555;
}
.more{
    width: 20%;
    margin: 10px;
    margin-left:70%;
    padding: 10px;
    border: 1px solid #555;
    border-radius: 5px;
    background-color: floralwhite;
    display: flex;
    justify-content: center;
    align-items: center;
}
.more a{
    text-align: center;
    font-size: 20px;
    color: #333;
}
.more:hover{
    transform: scale(1.05);
}
</style>