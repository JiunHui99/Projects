
<title>Product Details</title>
<?php include'../header.php';?>

<?php
session_start();
require '../db.php'; 

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Product not found!");
}

$product_id = intval($_GET['id']);


$stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Product not found!");
}

$stmt = $pdo->prepare("SELECT image_url FROM product_images WHERE product_id = ?");
$stmt->execute([$product_id]);
$images = $stmt->fetchAll(PDO::FETCH_ASSOC);

//verify user role
$user = null;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC); // fetch just one row
}

?>
<div class="pro-detail-header">
<p><strong><?=htmlspecialchars($product['product_name'])?></strong></p>
</div>

<section class="product-detail">
    <?php foreach ($images as $image): ?>
        <img src="../image/<?= htmlspecialchars($image['image_url']) ?>" alt="Product Image" class="product-detail-img">
     <?php endforeach; ?>
</section>

<section class="product-info">
    <p><?= htmlspecialchars($product['description']) ?></p>
    <p><strong>Price:</strong> RM <?= number_format($product['price'], 2) ?></p>
    <p><strong>Stock:</strong> <?= htmlspecialchars($product['stock']) ?></p>

    <form action="../user/add_to_cart.php" method="post">
        <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">
        <input type="hidden" name="quantity" value="1">
        <button type="submit" class="add-to-cart">Add to Cart</button>
    </form>
</section>

<?php include '../product/recommend_products.php';?>

<a href="/../index.php" class="back-btn">Back to Home</a>

<div class="bck-admin-btn">
    <?php if ($user && $user['role'] === 'admin'): ?>
        <a href="../admin/admin_dashboard.php">Back To Admin Dashboard</a>
    <?php endif; ?>
</div>

<?php include'../webinfo/footer.php';?>

<style>

.pro-detail-header{
    width: 20%;
    border: 1px solid #333;
    border-radius: 5px;
    background-color:floralwhite;
    text-align: center;
    font-size: 25px;
    margin: 20px auto;
    padding: 5px;
    color: rgb(0, 0, 0);
}
.pro-detail-header strong{
    color: rgb(0, 0, 0);
}
.product-detail{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    width: 80%;
    margin: 30px auto;
    padding: 30px;
    background-color: rgba(255, 243, 243, 0.78);;
    border:1px solid rgb(136, 136, 136);
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
}
.product-detail img{
    border:1px solid black;
    border-radius: 2px;
    width: 100%;
    margin: 0px auto;
    height: 60vh;
}
.product-info{
    font-size: 20px;
    padding: 20px;
    width: 80%;
    margin: 10px auto;
}
.product-item {
    width: 200px;
    text-align: center;
}
.product-item img {
    width: 100%;
    height: auto;
}

.add-to-cart {
    display: inline-block;
    color: #111;
    font-size: 16px;
    font-weight: 500;
    text-transform: capitalize;
    margin: 10px auto;
    padding: 12px 25px;
    background-color: floralwhite;
    border: 1px solid #333;
    border-radius: 5px;
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.add-to-cart:hover{
    background-color: papayawhip;
    transform: scale(1.05);
}
.back-btn{
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
.bck-admin-btn a{
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.bck-admin-btn a:hover{
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
.bck-admin-btn a{
    color: #111;
}
</style>
