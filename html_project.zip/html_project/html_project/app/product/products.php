<title>All Products</title>
<?php
include '../header.php';
?>

<section class="all-banner">
    <div class="products-header">
        <h2>All of Our <span>Products</span></h2>
        <p>Scroll down for more  <i class='bx bx-chevrons-down'></i></p>
    </div>
</section>

<?php include '../webinfo/filter.php'; ?>

<section class="all-products">
<?php
    require '../db.php';
    // Get sorting parameters,default = price or name
    $sortOrderPrice = isset($_GET['sort_price']) ? $_GET['sort_price'] : '';
    $sortOrderName = isset($_GET['sort_name']) ? $_GET['sort_name'] : '';

    $stmt = $pdo->prepare("SELECT * FROM products ORDER BY RAND()");
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($sortOrderPrice) {
        usort($products, function($a, $b) use ($sortOrderPrice) {
            return $sortOrderPrice === 'ASC' ? $a['price'] <=> $b['price'] : $b['price'] <=> $a['price'];
        });
    } elseif ($sortOrderName) {
        usort($products, function($a, $b) use ($sortOrderName) {
            return $sortOrderName === 'ASC' ? strcmp($a['product_name'], $b['product_name']) : strcmp($b['product_name'], $a['product_name']);
        });
    }
    ?>
    <?php foreach($products as $row): ?>
        <div class="all-pro-list">
            <a href="../product/product_detail.php?id=<?= htmlspecialchars($row["product_id"]) ?>">
                <img src="../image/<?= htmlspecialchars($row["image"]) ?>">
            </a>
            <h1><?= htmlspecialchars($row["product_name"]) ?></h1>
            <p><?= htmlspecialchars($row["description"]) ?></p>
            <p>RM: <strong><?= number_format($row["price"], 2) ?></strong></p>
            <p>Stock: <strong><?= htmlspecialchars($row["stock"]) ?></strong></p>
            <p>Sales: <strong><?= htmlspecialchars($row["sales"]) ?></strong></p>
            <form action="../user/add_to_cart.php" method="POST">
                <input type="hidden" name="product_id" value="<?= htmlspecialchars($row["product_id"]) ?>">
                <input type="number" name="quantity" value="1" min="1" max="<?= htmlspecialchars($row["stock"]) ?>" style="width: 60px;">
                <button type="submit" class="add-to-cart">Add to Cart</button>
            </form>
        </div>
    <?php endforeach; ?>
</section>

<a href="/../index.php" class="back-btn">Back to Home</a>

<?php include '../webinfo/footer.php'; ?>

<style>

.all-banner{
    width: 100%;
    height: 100vh;
    background-image: url(../image/banner-6.png);
    border-bottom:1px solid #000000;
    background-position: center;
    background-size: cover;
    display: grid;
    grid-template-columns: repeat(1, 1fr);
    align-items: center;
}
.products-header h2{
    color: #000;
    font-size: 55px;
    text-transform: capitalize;
    line-height: 1.1;
    font-weight: 600;
    margin: 6px 0 10px;
}
.products-header span{
    color: #ff0000;
}
.products-header p{
    color: #333c56;
    font-size: 25px;
    font-style: italic;
    margin-bottom: 20px;
}
.all-products {
    background-color: rgba(255, 243, 243, 0.78);
    border: 1px solid #000000;
    border-radius: 10px;
    margin:30px auto;
    padding: 40px 40px;
    max-width: 90%;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 5fr));
    gap: 1rem;
}
.all-pro-list{
    text-align: center;
    padding:20px 10px;
}
.all-pro-list:hover{
    transform: scale(1.05);
}
.all-pro-list img{
    border:1px solid rgb(136, 136, 136);
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
    width: 100%; 
    height: 46vh; 
}
.all-pro-list h1{
    color:rgb(0, 0, 0);
    margin: 10px;
    font-size: 20px;
}
.all-pro-list strong{
    color: rgba(102, 7, 175, 0.65);
    font-size: 15px;
}
.add-to-cart{
    padding: 5px 10px;
    background-color: floralwhite;
    border: 1px solid #333;
    border-radius: 5px;
    text-transform: capitalize;
}
.add-to-cart:hover{
    background-color: papayawhip;
    transform: scale(1.05);
}
.back-btn{
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px;
    margin-left:79%;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
</style>