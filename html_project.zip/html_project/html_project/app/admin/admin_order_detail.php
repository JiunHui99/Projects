<?php
session_start();
require '../db.php';

// admin verify
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

// get order id
if (!isset($_GET['id'])) {
    die("Order ID is required.");
}

$order_id = $_GET['id'];

// get order details
$stmt = $pdo->prepare("SELECT orders.*, users.user_name, users.email 
                       FROM orders 
                       JOIN users ON orders.user_id = users.user_id 
                       WHERE orders.order_id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die("Order not found.");
}

// get order item
$stmt = $pdo->prepare("SELECT order_items.*, products.product_name 
                       FROM order_items 
                       JOIN products ON order_items.product_id = products.product_id 
                       WHERE order_items.order_id = ?");
$stmt->execute([$order_id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// update order status
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['status'];
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    $stmt->execute([$new_status, $order_id]);
    $_SESSION['success_message'] = "Order Updated successfully!";
    header("Location: /admin/admin_order_detail.php?id=" . $order_id);
    exit();
}
?>
<?php
$success_message = '';
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>


<title>Order Detail</title>
<?php include'../header.php';?>


<div class="order-detail-header">
    <h2>Order Detail</h2>
</div>

<?php if (!empty($success_message)): ?>
    <div class="success-message"><?= htmlspecialchars($success_message) ?></div>
<?php endif; ?>

<section class="order-detail">

    <div class="cust-info">
    <p><strong>Order ID : </strong> <?= htmlspecialchars($order['order_id']) ?></p>
    <p><strong>Customer : </strong> <?= htmlspecialchars($order['user_name']) ?>  (<?= htmlspecialchars($order['email']) ?>)</p>
    <p><strong>Total Price : </strong> RM <?= number_format($order['total_amount'], 2) ?></p>
    <p><strong>Status : </strong> <?= htmlspecialchars($order['status']) ?></p>
    <p><strong>Order Date : </strong> <?= htmlspecialchars($order['created_at']) ?></p>

    <h3>Items</h3>

    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th>Subtotal</th>
        </tr>
        <?php foreach ($items as $item): ?>
        <tr>
            <td><?= htmlspecialchars($item['product_name']) ?></td>
            <td><?= htmlspecialchars($item['quantity']) ?></td>
            <td>RM <?= number_format($item['price'], 2) ?></td>
            <td>RM <?= number_format($item['quantity'] * $item['price'], 2) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h3>Update Status</h3>
    <form method="post">
        <select name="status">
            <option value="Pending" <?= $order['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
            <option value="Processing" <?= $order['status'] == 'Processing' ? 'selected' : '' ?>>Processing</option>
            <option value="Shipped" <?= $order['status'] == 'Shipped' ? 'selected' : '' ?>>Shipped</option>
            <option value="Delivered" <?= $order['status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
            <option value="Cancelled" <?= $order['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
        </select>
        <button type="submit">Update</button>
    </form>
    </div>
    <div class="back-container">
        <a href="admin_order_list.php" class="back-btn">Back to Order List</a>
    </div>
</section>

<?php include '../webinfo/footer.php'; ?>

<style>
.order-detail-header{
    width: 20%;
    border: 1px solid #333;
    border-radius: 5px;
    background-color:floralwhite;
    text-align: center;
    font-size: 20px;
    margin: 20px auto;
    padding: 5px;
    color: rgb(0, 0, 0);
}
.order-detail {
    width:60%;
    margin: 40px auto;
    padding: 30px;
    background-color: rgba(255, 232, 232, 0.65);;
    border:1px solid rgb(136, 136, 136);
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
}
.order-detail h2 {
    text-align: center;
    font-size: 28px;
    color: #333;
}
.cust-info{
    border:1px solid rgb(136, 136, 136);
    border-radius: 5px;
    background-color: white;
    padding: 20px;
}
.cust-info p {
    width: 100%;
    border:1px solid rgb(136, 136, 136);
    border-radius: 5px;
    font-size: 20px;
    margin:10px auto;
    padding: 10px;
    background-color: aliceblue;
    color: rgba(141, 46, 219, 0.8);
}
.cust-info strong{
    font-size: 22px;
    color: #000;
}
.cust-info h3{
    text-align: center;
    background-color: rgb(228, 216, 253);
    border: 1px solid #000;
    border-radius: 5px;
    margin: 20px auto;
    width: 250px;
    padding: 10px;
}
.cust-info table {
    width: 90%;
    margin: 30px auto;
    border-collapse: collapse;
    border: 1px solid #333;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: white;
}
.cust-info th, td {
    border:1px solid rgb(118, 118, 118);
}
.cust-info th {
    background-color: aliceblue;
    padding: 10px;
    font-size: 18px;
}
.cust-info td {
    text-align: center;
    padding: 10px;
}
.cust-info form{
    display: flex;
    justify-content: center;
    align-items: center;
}
.cust-info select, button {
    padding: 10px;
    font-size: 16px;
    margin: 10px;
}
.cust-info select{
    border-radius: 5px;
    background-color: rgba(255, 236, 236, 0.65);
    color: black;
}
.cust-info select:hover{
    background-color: white;
    transform: scale(1.03);
}
.cust-info button {
    padding: 12px;
    background-color:rgb(154, 254, 176);
    border:1px solid dimgray;
    color: black;
    border-radius: 5px;
    cursor: pointer;
}
.cust-info button:hover {
    background-color:rgb(0, 221, 52);
    transform: scale(1.03);
}
.back-btn {
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
.back-container {
    text-align: center; 
    margin-top: 20px; 
}
.success-message {
    background-color: #d4edda;
    color:rgb(0, 0, 0);
    border: 1px solid #333;
    padding: 10px;
    margin: 20px auto;
    width: 50%;
    border-radius: 5px;
    text-align: center;
    font-size: 16px;
    font-weight: 500;
}
</style>
