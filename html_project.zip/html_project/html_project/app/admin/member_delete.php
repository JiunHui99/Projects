<?php
session_start();
require '../db.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

$user_id = $_GET['id'] ?? null;
if (!$user_id) {
    die("User ID is missing.");
}

try {
    // Get all order IDs for the user
    $stmt = $pdo->prepare("SELECT order_id FROM orders WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $order_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (!empty($order_ids)) {
        // Delete all order items for these orders
        $inClause = implode(',', array_fill(0, count($order_ids), '?'));
        $stmt = $pdo->prepare("DELETE FROM order_items WHERE order_id IN ($inClause)");
        $stmt->execute($order_ids);

        // Delete orders
        $stmt = $pdo->prepare("DELETE FROM orders WHERE user_id = ?");
        $stmt->execute([$user_id]);
    }

    // Delete user
    $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    
    $_SESSION['success_message'] = "Member deleted successfully!";
    header("Location: ./admin_dashboard.php");
    exit();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

?>