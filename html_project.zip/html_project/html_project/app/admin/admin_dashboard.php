
<title>Admin Dashboard</title>
<?php include '../header.php'; ?>

<?php
session_start();
require '../db.php';

// admin verification
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../admin/admin_login.php?error=You Are Not An Admin!");
    exit();
}

$admin_name = $_SESSION['user_name'];


$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$sql = "SELECT product_id, product_name, price, stock, image FROM products";

if (!empty($search)) {
    $sql .= " WHERE product_id LIKE :search OR product_name LIKE :search";
}

$stmt = $pdo->prepare($sql);

if (!empty($search)) {
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
}

$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php
$success_message = '';
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>

<?php if (!empty($success_message)): ?>
    <div class="success-message"><?= htmlspecialchars($success_message) ?></div>
<?php endif; ?>

<section class="method-header">
    <h2>Admin Dashboard</h2>

    <div class="search-box">
        <form action="" method="GET">
            <input type="text" name="search" placeholder="Search by ID or Name" value="<?= htmlspecialchars($search) ?>">
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="add-product">
        <a href="/admin/product_add.php">+ Add Product</a>
    </div>
</section>

<section class="admin-page">

<section class="admin-sidebar">

    <h1>Welcome, <span><?= htmlspecialchars($admin_name) ?></span></h1> 

    <div class="admin-menu">
        <a href="../user/logout.php" style="background-color: rgba(255, 147, 147, 0.91);">Logout</a>     
        <a href="/admin/member_list.php" style="background-color: rgba(255, 207, 125, 0.77);">Member List</a>
        <a href="/admin/admin_order_list.php" style="background-color: rgb(254, 255, 205);">Order List</a>
    </div>

 </section>

<section class="dashboard">
    <h2>Product List</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Images</th>
            <th>Name</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Action</th>
        </tr>
        <?php foreach ($products as $product): ?>
        <tr>
            <td><?= htmlspecialchars($product['product_id'])?></td>
            <td>
                <div class="image-container">
                    <?php if (!empty($product['image'])): ?>
                        <img src="../image/<?= htmlspecialchars($product['image']) ?>" alt="Product Image">
                    <?php else: ?>
                        <span>No Image</span>
                    <?php endif; ?>
                </div>
            </td>

            <td><?= htmlspecialchars($product['product_name']) ?></td>
            <td>RM <?= number_format($product['price'], 2) ?></td>
            <td><?= $product['stock'] ?></td>
            <td>
            <a href="../product/product_detail.php?id=<?= $product['product_id'] ?>" style="color: blue;">View</a> |
                <a href="/admin/product_edit.php?product_id=<?= $product['product_id'] ?>" style="color: orange;">Edit</a> |
                <a href="/admin/product_delete.php?product_id=<?= $product['product_id'] ?>" onclick="return confirm('Are you sure?');" style="color: red;">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</section>
</section>

<?php include '../webinfo/footer.php'; ?>

 <style>
.method-header{
    padding:20px;
}
.method-header h2{
    border: 1px solid #333;
    border-radius: 5px;
    background-color: rgba(254, 241, 214, 0.78);
    width:20%;
    margin: 15px auto;
    padding: 10px;
    text-align: center;
    font-size: 25px;
    font-weight: bold;
}
.search-box form{
    display: flex;
    justify-content: center;
    align-items: center;
    width:60%;
    margin:10px auto;
}
.search-box input{
    width: 500px;
    margin: 10px;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #333;
}
.search-box button{
    padding: 8px 15px;
    font-size: 16px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color: rgba(74, 164, 248, 0.78);
    color: black;
    cursor: pointer;
}
.search-box button:hover{
    background-color:rgba(143, 219, 240, 0.78);
    transform: scale(1.1);
}
.add-product{
    display: flex;
    justify-content: center;
    align-items: center;
    width:10%;
    margin:10px auto;
    padding: 10px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color:rgba(193, 255, 162, 0.78);
    cursor: pointer;
}
.add-product a{
    color: black;
    font-size: 18px;
}
.add-product:hover{
    background-color: rgba(97, 255, 168, 0.78);
    transform: scale(1.1);
}
.admin-page{
    display: flex;
    max-width: auto;
    margin:0px 100px;
    margin-bottom: 40px;
    padding: 0px 0px;
    height: 100vh;
    border: 1px solid #333;
    border-radius: 15px;
}
.admin-sidebar{
    border-right: 1px solid rgb(92, 93, 93);
    box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
    width: 250px;
    height:100%; 
    padding:20px;
}
.admin-sidebar h1{
    border: 1px solid #333;
    border-radius: 5px;
    background-color: floralwhite;
    width:auto;
    margin: 15px auto;
    padding: 10px;
    text-align: center;
    font-size: 25px;
    font-weight: bold;
    text-align: center;
    margin:10px;
}
.admin-sidebar span{
    color:rgba(52, 52, 192, 0.82);
}
.admin-menu a {
    display: flex;
    justify-content: center; 
    align-items: center;
    width: 100%;
    padding: 10px;
    margin: 20px auto;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
    color: black;
}
.admin-menu a:hover {
    background-color: #f0f0f0;
}     
.dashboard{
    flex-grow: 1;
    padding: 20px;
    background-color:white;
    overflow-y: auto;
}
.dashboard h2{
    border: 1px solid #333;
    border-radius: 5px;
    background-color: floralwhite;
    width:300px;
    margin: 15px auto;
    padding: 10px;
    text-align: center;
}
.dashboard table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px 0px;
}
.dashboard table, th, td {
    border: 1px solid rgb(92, 93, 93);
    padding: 10px 10px;
    text-align: center;
}
.dashboard th {
    font-size: 18px;
    background-color: pink;
    color: #333;
}
.dashboard td{
    background-color: white;
}
.image-container {
    display: flex;
    justify-content: center;
    background-color:  rgba(252, 235, 235, 0.78);
}
.image-container img{
    border: 1px solid rgb(92, 93, 93);
    border-radius: 5px;
    width: 220px;
    height: 30vh;
    margin: 10px;
}
.success-message {
    background-color: #d4edda;
    color:rgb(0, 0, 0);
    border: 1px solid #333;
    padding: 10px;
    margin: 20px auto;
    width: 50%;
    border-radius: 5px;
    text-align: center;
    font-size: 16px;
    font-weight: 500;
}
</style>