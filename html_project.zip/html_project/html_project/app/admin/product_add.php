<?php include'../header.php';?>
<?php
session_start();
require '../db.php';

// admin verify
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = trim($_POST['product_name']);
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $description = trim($_POST['description']);
    $category = $_POST['cat_id'];

    if (empty($product_name) || empty($price) || empty($stock) || empty($description)|| empty($category)) {
        $errors[] = "All fields are required.";
    }

    if (empty($errors)) {
        $pdo->beginTransaction();
        try {
            $imageFilename = "";
            if (!empty($_FILES['images']['name'][0])) {
                    $upload_dir = "../image/";
                    $filename = uniqid() . "_" . basename($_FILES['images']['name'][0]);
                    $destination = $upload_dir . $filename;
                    move_uploaded_file($_FILES['images']['tmp_name'][0], $destination);
                    $imageFilename = $filename;
            }
                
            $stmt = $pdo->prepare("INSERT INTO products (product_name, price, stock, description, cat_id, image) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$product_name, $price, $stock, $description, $category, $imageFilename]);

            $product_id = $pdo->lastInsertId();

            if ($imageFilename) {
                $stmt = $pdo->prepare("INSERT INTO product_images (product_id, image_url) VALUES (?, ?)");
                $stmt->execute([$product_id, $imageFilename]);
            }

            $pdo->commit();
            
            $_SESSION['success_message'] = "Product added successfully!";
            header("Location: /admin/admin_dashboard.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}
?>

<div class="add-product-container">
    <h2>Add Product</h2>

    <?php if (!empty($errors)): ?>
        <div style="color: red;">
            <?php foreach ($errors as $error): ?>
                <p><?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form action="" method="post" enctype="multipart/form-data">
        <label>Name:</label>
        <input type="text" name="product_name" required><br>

        <label>Price:</label>
        <input type="number" name="price" step="0.01" required><br>

        <label>Stock:</label>
        <input type="number" name="stock" required><br>

        <label>Description:</label>
        <textarea name="description" id="description" rows="3" cols="50" required></textarea><br>
            
        <label>Category:</label>
        <input type="text" name="cat_id" required><br>

        <label>Images:</label>
        <input type="file" name="images[]" multiple><br>

        <button type="submit">Add Product</button>
    </form>

</div>

<a href="/admin/admin_dashboard.php" class="back-btn">Back to Dashboard</a>

<?php include '../webinfo/footer.php'; ?>

<style>
.add-product-container {
    width: 40%;
    margin: 60px auto;
    padding: 20px;
    background-color: rgba(255, 235, 235, 0.86);
    border: 1px solid #333;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}
.add-product-container h2{
    border: 1px solid #333;
    border-radius: 5px;
    background-color: floralwhite;
    width:300px;
    margin: 5px auto;
    padding: 10px;
    text-align: center;
}
form{
    width: 80%;
    margin: 10px auto;
    padding: 10px 15px;
    text-align: center;
}
form label{
    border: 1px solid #333;
    border-radius: 5px;
    background-color: azure;
    width:20%;
    margin: 5px auto;
    padding: 5px 15px;
    display: flex;
    justify-content: center;
    align-items: center;
}
textarea{
    margin: 10px;
    text-align: center;
}
input[type="text"], input[type="number"], input[type="file"] {
    width: 100%;
    padding: 10px;
    margin: 20px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color: white;
    font-size: 15px;
}
button {
    width: 250px;
    margin: 10px;
    background-color:rgb(190, 255, 205);
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
}
button:hover {
    background-color:rgb(68, 255, 109);
    transform: scale(1.03);
}
.back-btn {
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
</style>