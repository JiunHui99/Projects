<?php
session_start();
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT user_id, user_name, password, role FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if ($user['role'] !== 'admin') {
            $error = "Access denied. This login is for admins only.";
        } elseif (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_name'] = $user['user_name'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['admin_logged_in'] = true;

            header("Location: ../admin/admin_dashboard.php");
            exit;
        } else {
            $error = "Invalid email or password!";
        }
    } else {
        $error = "Invalid email or password!";
    }
}
?>

<title>Admin Login</title>
<?php include '../header.php'; ?>

<div class="login-container">
    <h2>Admin Login</h2>

    <?php if (isset($error)) : ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST" action="admin_login.php">
        <label>Email</label>
        <input type="email" name="email" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>

    <p>Don't have an account? <a href="../admin/admin_register.php">Register here</a></p>
    <p><a href="../user/forgot_password.php">Forgot your password?</a></p>
</div>

<style>
.login-container {
    background-color: rgba(255, 245, 245, 0.86);
    padding: 40px;
    margin: 50px auto;
    border: 1px solid #000;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    width: 380px;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
.login-container h2{
    border: 1px solid #333;
    background-color: floralwhite;
    width:70%;
    margin: 15px auto;
    padding: 10px;
    text-align: center;
    font-size: 25px;
    font-weight: bold;
    text-align: center;
}
.login-container label{
    font-size: 20px;
}
.login-container input {
    width: 100%;
    padding: 10px;
    margin: 20px auto;
    border: 1px solid #000;
    border-radius: 5px;
}

.login-container button {
    display: flex;
    justify-content: center;
    align-items: center;
    width:50%;
    margin:10px auto;
    padding: 10px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color:rgba(193, 255, 162, 0.78);
    cursor: pointer;
    font-size: 18px;
}

.login-container button:hover {
    background-color: rgba(97, 255, 168, 0.78);
    transform: scale(1.1);
}
.login-container p{
    font-size: 16px;
}
.login-container a{
    font-size: 18px;
}
.error {
    color: red;
    font-size: 14px;
}
</style>