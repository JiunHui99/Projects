
<title>Edit Product</title>
<?php include '../header.php';?>

<?php
session_start();
require '../db.php';

$product_id = $_GET['product_id'] ?? null;
if (!$product_id) {
    die("Product ID is missing.");
}

// get product database
$stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
$stmt->execute([$product_id]);
$products = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$products) {
    die("Product not found.");
}

// get product image
$stmt = $pdo->prepare("SELECT image_url FROM product_images WHERE product_id = ?");
$stmt->execute([$product_id]);
$images = $stmt->fetchAll(PDO::FETCH_ASSOC);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = trim($_POST['product_name']);
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    if (empty($product_name) || empty($price) || empty($stock)) {
        $errors[] = "All fields are required.";
    }

    if (empty($errors)) {
        try {
            // update product
            $stmt = $pdo->prepare("UPDATE products SET product_name = ?, price = ?, stock = ? WHERE product_id = ?");
            $stmt->execute([$product_name, $price, $stock, $product_id]);

            // uploads new image
            if (!empty($_FILES['images']['tmp_name'][0])) {
                $upload_dir = "../image/";
                foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                    $filename = uniqid() . "_" . basename($_FILES['images']['product_name'][$key]);
                    $destination = $upload_dir . $filename;
                    move_uploaded_file($tmp_name, $destination);

                    // insert new image
                    $stmt = $pdo->prepare("INSERT INTO product_images (product_id, image_url) VALUES (?, ?)");
                    $stmt->execute([$product_id, $filename]);
                }
            }
            
            $_SESSION['success_message'] = "Product updated successfully!";
            header("Location: /admin/admin_dashboard.php");
            exit();
        } catch (Exception $e) {
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}
?>

<section class="pro-edit-container">
    <h2>Edit Product</h2>

    <?php if (!empty($errors)): ?>
        <div style="color: red;">
            <?php foreach ($errors as $error): ?>
                <p><?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form action="" method="post" enctype="multipart/form-data">
        <label>Name:</label>
        <input type="text" name="product_name" value="<?= htmlspecialchars($products['product_name']) ?>" required><br>

        <label>Price:</label>
        <input type="number" name="price" step="0.01" value="<?= $products['price'] ?>" required><br>

        <label>Stock:</label>
        <input type="number" name="stock" value="<?= $products['stock'] ?>" required><br>

        <label>Existing Images:</label><br>
        <div class="existing-images">
        <?php foreach ($images as $img): ?>
            <img src="/image/<?= htmlspecialchars($img['image_url']) ?>">
        <?php endforeach; ?><br>
        </div>

        <label>New Images:</label>
        <input type="file" name="images[]" multiple><br>

        <button type="submit">Update Product</button>
    </form>

</section>

<a href="/admin/admin_dashboard.php" class="back-btn">Back to Dashboard</a>

<?php include '../webinfo/footer.php'; ?>

<style>
.pro-edit-container {
    width: 40%;
    margin: 60px auto;
    padding: 30px;
    background-color: rgba(255, 235, 235, 0.86);
    border: 1px solid #333;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
.pro-edit-container h2 {
    border: 1px solid #333;
    border-radius: 5px;
    background-color: floralwhite;
    width:300px;
    margin: 5px auto;
    padding: 10px;
    text-align: center;
}
form{
    width: 80%;
    margin: 10px auto;
    padding: 10px;
    text-align: center;
}
form label{
    border: 1px solid #333;
    border-radius: 5px;
    background-color: azure;
    margin: 10px;
    padding: 5px 15px;
}
input[type="text"], input[type="number"], input[type="file"] {
    width: 100%;
    padding: 10px;
    margin: 20px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color: white;
    font-size: 15px;
}
.existing-images {
    background-color: white;
    border-radius: 16px;
    margin: 20px;
    padding: 5px;
    gap: 10px;
    text-align: center;
}
.existing-images img {
    width: 150px;
    height: 100px;
    border-radius: 4px;
    border: 1px solid #ddd;
}
button {
    width: 250px;
    margin: 10px;
    background-color:rgb(190, 255, 205);
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
}
button:hover {
    background-color:rgb(68, 255, 109);
    transform: scale(1.03);
}
.back-btn {
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
</style>
