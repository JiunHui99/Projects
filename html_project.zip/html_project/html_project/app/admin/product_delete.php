<?php
session_start();
require '../db.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

$product_id = $_GET['product_id'] ?? null;
if (!$product_id) {
    die("Product ID is missing.");
}

try {
    // delete product image
    $stmt = $pdo->prepare("DELETE FROM product_images WHERE product_id = ?");
    $stmt->execute([$product_id]);

    // delete product
    $stmt = $pdo->prepare("DELETE FROM products WHERE product_id = ?");
    $stmt->execute([$product_id]);

    $_SESSION['success_message'] = "Product deleted successfully!";
    header("Location: /admin/admin_dashboard.php");
    exit();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>