
<?php
require '../db.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$sql = "SELECT user_id, user_name, email, role FROM users WHERE role = 'user'";

if (!empty($search)) {
    $sql .= " AND (user_name LIKE :search OR email LIKE :search)";
}

$stmt = $pdo->prepare($sql);

if (!empty($search)) {
    $stmt->bindValue(':search', "%$search%");
}
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include '../header.php'; ?>
<title>Member List</title>

<div class="member-list-container">
    <h2>Member List</h2>

    <form method="GET" class="search-box">
        <input type="text" name="search" placeholder="Search by name or email" value="<?= htmlspecialchars($search) ?>">
        <button type="submit">Search</button>
    </form>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Action</th>
        </tr>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['user_id'] ?></td>
                <td><?= htmlspecialchars($user['user_name']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['role']) ?></td>
                <td><a href="/admin/member_detail.php?id=<?= $user['user_id'] ?>">View</a></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <a href="/admin/admin_dashboard.php" class="back-btn">Back to Dashboard</a>

</div>

<?php include'../webinfo/footer.php';?>

<style>

.member-list-container {
    display: flex;
    flex-direction: column; 
    align-items: center;
    justify-content: center;
    margin: 120px auto;
}
.member-list-container h2{
    margin: 10px;
}
table {
    width: 60%;
    border-collapse: collapse;
    margin-top: 20px 0px;
}
th, td {
    border: 1px solid rgb(92, 93, 93);
    padding: 10px 10px;
    text-align: center;
}
th{
    background-color: pink;
    color: #333;
}
td a{
    background-color: floralwhite;
    padding: 3px 10px;
    margin: 10px auto;
    border: 1px solid rgb(92, 93, 93);
    border-radius: 5px;
    color: blueviolet;
    text-align: center;
}
td a:hover{
    background-color:rgba(249, 148, 148, 0.41);
    transform: scale(1.1);
}
.search-box {
    margin-bottom: 20px;
}
.search-box input {
    padding: 8px;
    border: 1px solid #333;
    border-radius: 5px;
    font-size: 14px;
}
.search-box button {
    background-color: rgba(199, 249, 229, 0.78);
    padding: 5px 10px;
    margin: 10px auto;
    border: 1px solid rgb(92, 93, 93);
    border-radius: 5px;
    color: black;
    text-align: center;
}
.search-box button:hover {
    background-color:rgb(81, 255, 203);
    transform: scale(1.1);
}
.back-btn {
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}

</style>