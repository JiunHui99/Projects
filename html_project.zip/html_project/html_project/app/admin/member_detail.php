
<title>Member Details</title>
<?php include'../header.php';?>

<?php
require '../db.php';

if (!isset($_GET['id'])) {
    die("User ID is required!");
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found!");
}
?>

<section class="member-detail-container">
    <h2>Member Detail</h2>

    <img src="<?= htmlspecialchars($user['profile_photo'] ?: '../image/default-profile.jpg') ?>" alt="Profile Photo">
    <p><strong>ID:</strong> <?= $user['user_id'] ?></p>
    <p><strong>Name:</strong> <?= htmlspecialchars($user['user_name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
    <p><strong>Address:</strong> <?= htmlspecialchars($user['address']) ?></p>
    <p><strong>Role:</strong> <?= htmlspecialchars($user['role']) ?></p>
    <p><strong>Created At:</strong> <?= $user['created_at'] ?></p>

    <div class="btn-wrapper">
    <a href="/admin/member_list.php" class="back-button">Back to List</a>
    <a href="/admin/member_delete.php?id=<?= $user['user_id'] ?>" onclick="return confirm('Are you sure?');" class="delete-btn">Delete User</a>
    </div>
    
</section>

<?php include'../webinfo/footer.php';?>

<style>
.member-detail-container {
    max-width: 60%;
    margin: 70px auto;
    background:rgb(255, 241, 241);
    padding: 20px;
    border: 1px solid rgb(122, 122, 122);
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
}
.member-detail-container h2 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
}
.member-detail-container img{
    width: 150px;
    height: 150px;
    border: 1px solid rgb(122, 122, 122);
    border-radius: 50%;
    margin: 15px 30px;
}
.member-detail-container p {
    font-size: 18px;
    margin: 8px 0;
    padding: 8px;
    background:rgb(255, 255, 255);
    border: 1px solid rgb(122, 122, 122);
    border-radius: 5px;
}
strong {
    color: #007bff;
}
.btn-wrapper{
    display:flex;
    padding: 10px;
    gap: 50px;
}
.back-button {
    background-color: rgba(199, 225, 249, 0.78);
    width: 300px;
    height: 60px;
    display:flex;
    justify-content: center;
    align-items: center;
    margin: 10px auto;
    color: black;
    padding: 5px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}

.back-button:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
.delete-btn{
    background-color: rgba(250, 134, 134, 0.91);
    width: 300px;
    height: 60px;
    display:flex;
    justify-content: center;
    align-items: center;
    margin: 10px auto;
    color: black;
    padding: 5px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.delete-btn:hover{
    background-color: lightcoral;
    transform: scale(1.1);
    color: black;
}
</style>