<?php
session_start();
require '../db.php';

// admin verify
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

// get all order list
$stmt = $pdo->query("SELECT orders.order_id, users.user_name, orders.total_amount, orders.status, orders.created_at 
                      FROM orders 
                      JOIN users ON orders.user_id = users.user_id 
                      ORDER BY orders.created_at DESC");
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<title>Order List</title>
<?php include'../header.php';?>


<div class="order-list-header">
        <h2>Order List</h2>
</div>

<section class="order-list">
    <table border="1">
        <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Total Price</th>
            <th>Status</th>
            <th>Order Date</th>
            <th>Action</th>
        </tr>
        <?php foreach ($orders as $order): ?>
        <tr>
            <td><?= htmlspecialchars($order['order_id']) ?></td>
            <td><?= htmlspecialchars($order['user_name']) ?></td>
            <td>RM <?= number_format($order['total_amount'], 2) ?></td>
            <td><?= htmlspecialchars($order['status']) ?></td>
            <td><?= htmlspecialchars($order['created_at']) ?></td>
            <td><a href="admin_order_detail.php?id=<?= $order['order_id'] ?>">View</a></td>
        </tr>
        <?php endforeach; ?>
    </table>

        <a href="/admin/admin_dashboard.php" class="back-btn">Back to Dashboard</a>

</section>

<?php include '../webinfo/footer.php'; ?>

<style>
.order-list-header{
    width: 20%;
    border: 1px solid #333;
    border-radius: 5px;
    background-color:floralwhite;
    text-align: center;
    font-size: 20px;
    margin: 20px auto;
    padding: 5px;
    color: rgb(0, 0, 0);
}
.order-list{
    width:90%;
    margin: 40px auto;
    padding: 30px;
    background-color: rgba(255, 245, 245, 0.86);
    border:1px solid rgb(136, 136, 136);
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(54, 53, 53, 0.1);
}
.order-list table {
    width: 90%;
    margin: 30px auto;
    border-collapse: collapse;
    border: 1px solid #333;
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
.order-list th , td{
    border:1px solid rgb(118, 118, 118);
}
.order-list th {
    background-color: rgba(254, 238, 206, 0.88);
    padding: 10px;
    font-size: 18px;
}
.order-list td{
    text-align: center;
    padding: 8px;
    font-size: 18px;
}
tr:nth-child(even) {
    background-color: rgba(214, 231, 249, 0.78);
}
tr:hover {
    background-color:rgba(255, 213, 213, 0.88);
}
.order-list tr a {
    display: inline-block;
    color: rebeccapurple;
    font-size: 18px;
    font-weight: 500;
    text-transform: capitalize;
    margin: 10px auto;
    padding: 6px 25px;
    background-color: floralwhite;
    border: 1px solid #333;
    border-radius: 5px;
}
.order-list tr a:hover {
    background-color: rgb(211, 248, 255);
    color: black;
    transform: scale(1.1);
}
.back-btn {
    background-color: rgba(199, 225, 249, 0.78);
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 60px;
    margin: 20px auto;
    color: black;
    padding: 10px 15px;
    border: 1px solid #333;
    border-radius: 5px;
    box-shadow: 0 0 50px rgba(139, 137, 137, 0.1);
    text-transform: capitalize;
    font-size: 18px;
    font-weight: 500;
}
.back-btn:hover {
    background-color:rgba(143, 189, 240, 0.78);
    transform: scale(1.1);
}
</style>