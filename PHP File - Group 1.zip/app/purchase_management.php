<?php
session_start();
include_once 'sidebar.php';
include_once 'config/database.php';
include_once '_base.php';

// Use the existing database connection from database.php
global $pdo;

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Generate the next stock order ID for display
$next_stock_order_id = getNextStockOrderId($pdo);

// Fetch all products
$products_query = "SELECT p.product_id, p.product_name, p.product_price, p.stock_quantity, 
                          c.cat_name, s.supplier_id, s.supplier_name
                   FROM products p
                   JOIN category c ON p.cat_id = c.cat_id
                   JOIN suppliers s ON p.supplier_id = s.supplier_id
                   ORDER BY p.product_name";
$products_stmt = $pdo->query($products_query);
$products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all suppliers
$suppliers_query = "SELECT supplier_id, supplier_name, supplier_contact, supplier_address 
                    FROM suppliers ORDER BY supplier_name";
$suppliers_stmt = $pdo->query($suppliers_query);
$suppliers = $suppliers_stmt->fetchAll(PDO::FETCH_ASSOC);

// Generate next stock order ID
function getNextStockOrderId($pdo) {
    $query = "SELECT stock_order_id FROM stock_order 
              ORDER BY CAST(SUBSTRING(stock_order_id, 3) AS UNSIGNED) DESC LIMIT 1";
    $stmt = $pdo->query($query);
    $last_order = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($last_order) {
        $last_number = intval(substr($last_order['stock_order_id'], 2));
        $next_number = $last_number + 1;
    } else {
        $next_number = 1;
    }

    return 'SO' . str_pad($next_number, 4, '0', STR_PAD_LEFT);
}

// Process purchase order submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit') {
    $supplier_id = $_POST['supplier_id'] ?? '';
    $items = $_POST['items'] ?? [];
    
    // Validate items - check for non-empty product_id and valid quantity
    $valid_items = array_filter($items, function($item) {
        return !empty($item['product_id']) && 
               isset($item['qty']) && 
               is_numeric($item['qty']) && 
               $item['qty'] > 0;
    });
    
    if (empty($supplier_id)) {
        $_SESSION['error_message'] = 'Please select a supplier!';
    } elseif (empty($valid_items)) {
        $_SESSION['error_message'] = 'Please add at least one product with a valid quantity to the order!';
    } else {
        try {
            $pdo->beginTransaction();
            
            $date_ordered = date('Y-m-d H:i:s');
            $date_received = date('Y-m-d H:i:s', strtotime("+7 days"));
            
            // Insert stock orders
            foreach ($valid_items as $item) {
                $stock_order_id = getNextStockOrderId($pdo);
                
                // Verify product belongs to selected supplier
                $verify_query = "SELECT supplier_id FROM products WHERE product_id = :product_id";
                $verify_stmt = $pdo->prepare($verify_query);
                $verify_stmt->execute([':product_id' => $item['product_id']]);
                $product_supplier = $verify_stmt->fetchColumn();
                
                if ($product_supplier != $supplier_id) {
                    throw new Exception("Product " . $item['product_id'] . " does not belong to the selected supplier!");
                }
                
                // Insert stock order
                $insert_query = "INSERT INTO stock_order (stock_order_id, supplier_id, product_id, quantity, date_ordered, date_received) 
                                VALUES (:stock_order_id, :supplier_id, :product_id, :quantity, :date_ordered, :date_received)";
                $insert_stmt = $pdo->prepare($insert_query);
                $insert_stmt->execute([
                    ':stock_order_id' => $stock_order_id,
                    ':supplier_id' => $supplier_id,
                    ':product_id' => $item['product_id'],
                    ':quantity' => $item['qty'],
                    ':date_ordered' => $date_ordered,
                    ':date_received' => $date_received
                ]);
                
                // Update stock quantity immediately
                $update_stock = "UPDATE products SET stock_quantity = stock_quantity + :quantity 
                                WHERE product_id = :product_id";
                $stock_stmt = $pdo->prepare($update_stock);
                $stock_stmt->execute([
                    ':quantity' => $item['qty'],
                    ':product_id' => $item['product_id']
                ]);
            }
            
            $pdo->commit();
            $_SESSION['success_message'] = 'Purchase Order Submitted Successfully!';
            header("Location: purchase_management.php");
            exit();
            
        } catch(Exception $e) {
            $pdo->rollBack();
            $_SESSION['error_message'] = $e->getMessage();
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Management</title>
    <style>
        .main-content {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            text-align: center;
            margin:30px;
            margin-left: auto;
            margin-right: auto;
            max-width: 700px;
            }
        .header h1 {
            margin: 0;
            font-size: 26px;
            color: #333;
            letter-spacing: 1px;
        }

        .section {
            background: white;
            padding: 20px;
            border-radius: 6px;
            margin-bottom: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 16px;
            font-weight: 600;
            color: white;
            background: #52c41a;
            padding: 10px 15px;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 15px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 6px;
            color: #333;
        }

        .form-group input,
        .form-group select {
            padding: 8px 10px;
            border: 1px solid #d9d9d9;
            border-radius: 4px;
            font-size: 13px;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #40a9ff;
        }

        .form-group input[readonly] {
            background-color: #f5f5f5;
            color: #666;
        }

        .supplier-info {
            background: #f0f7ff;
            padding: 12px;
            border-radius: 4px;
            margin-top: 10px;
            font-size: 13px;
            display: none;
        }

        .supplier-info.show {
            display: block;
        }

        .supplier-info p {
            margin: 4px 0;
            color: #333;
        }

        .table-wrapper {
            overflow: visible;
            position: relative;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            font-size: 13px;
        }

        th {
            background: #fafafa;
            padding: 10px;
            text-align: left;
            font-size: 13px;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #e8e8e8;
        }

        td {
            padding: 8px 10px;
            border-bottom: 1px solid #f0f0f0;
            position: relative;
        }

        td input {
            width: 100%;
            padding: 6px 8px;
            border: 1px solid #d9d9d9;
            border-radius: 4px;
            font-size: 13px;
        }

        .autocomplete {
            position: relative;
            width: 100%;
        }

        .autocomplete-items {
            position: absolute;
            border: 1px solid #d9d9d9;
            border-top: none;
            z-index: 1000;
            top: 100%;
            left: 0;
            right: 0;
            max-height: 250px;
            overflow-y: auto;
            background: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            margin-top: 2px;
        }

        .autocomplete-items div {
            padding: 10px;
            cursor: pointer;
            border-bottom: 1px solid #f0f0f0;
            font-size: 13px;
            background: white;
        }

        .autocomplete-items div:hover {
            background-color: #e6f7ff;
        }

        .stock-warning {
            color: #ff4d4f;
            font-size: 11px;
            font-weight: 600;
        }

        .btn-add {
            background: #52c41a;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            margin: 10px 0;
        }

        .btn-add:hover {
            background: #389e0d;
        }

        .btn-remove {
            background: #ff4d4f;
            color: white;
            border: none;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
        }

        .btn-remove:hover {
            background: #cf1322;
        }

        .total-section {
            background: #fafafa;
            padding: 15px 0;
            border-radius: 4px;
            margin-top: 20px;
            border: 1px solid #e8e8e8;
        }

        .button-group {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            border: none;
        }

        .btn-primary {
            background: #1890ff;
            color: white;
        }

        .btn-primary:hover {
            background: #096dd9;
        }

        .btn-secondary {
            background: white;
            color: #333;
            border: 1px solid #d9d9d9;
        }

        .btn-secondary:hover {
            color: #40a9ff;
            border-color: #40a9ff;
        }

        .success-message {
            background: #f6ffed;
            border: 1px solid #b7eb8f;
            color: #389e0d;
            padding: 12px 16px;
            margin-bottom: 15px;
            border-radius: 4px;
            font-weight: 600;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="header">
            <h1 style="text-align: center;">Purchase Management</h1>
        </div>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="success-message">
                ✅ <?= htmlspecialchars($_SESSION['success_message']) ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <form method="POST" action="" id="purchase-form">
            <div class="section">
                <div class="section-title">Purchase Information</div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Supplier *</label>
                        <select name="supplier_id" id="supplier_id" required>
                            <option value="">Select Supplier</option>
                            <?php foreach ($suppliers as $supplier): ?>
                                <option value="<?= htmlspecialchars($supplier['supplier_id']) ?>"
                                        data-contact="<?= htmlspecialchars($supplier['supplier_contact']) ?>"
                                        data-address="<?= htmlspecialchars($supplier['supplier_address']) ?>">
                                    <?= htmlspecialchars($supplier['supplier_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Supplier ID</label>
                        <input type="text" id="supplier_id_display" value="" readonly>
                    </div>

                    <div class="form-group">
                        <label>Stock Order #</label>
                        <input type="text" value="<?= $next_stock_order_id ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label>Order Date</label>
                        <input type="date" value="<?= date('Y-m-d') ?>" readonly>
                    </div>
                </div>

                <div class="supplier-info" id="supplier-info">
                    <p><strong>Contact:</strong> <span id="supplier-contact"></span></p>
                    <p><strong>Address:</strong> <span id="supplier-address"></span></p>
                </div>
            </div>

            <div class="section">
                <div class="section-title">Products to Purchase</div>
                
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">#</th>
                                <th>Product</th>
                                <th style="width: 120px; text-align: center;">Current Stock</th>
                                <th style="width: 110px; text-align: center;">Unit Price (RM)</th>
                                <th style="width: 100px; text-align: center;">Purchase Qty</th>
                                <th style="width: 120px; text-align: center;">Subtotal (RM)</th>
                                <th style="width: 80px; text-align: center;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="items-body">
                            <tr data-row="0">
                                <td style="text-align: center;">1</td>
                                <td>
                                    <div class="autocomplete">
                                        <input type="text" class="product-search" placeholder="Type to search..." autocomplete="off">
                                        <input type="hidden" name="items[0][product_id]" class="product-id">
                                    </div>
                                </td>
                                <td style="text-align: center;"><input type="number" class="current-stock" value="0" readonly style="text-align: center;"></td>
                                <td style="text-align: center;"><input type="number" step="0.01" class="unit-price" value="0.00" readonly style="text-align: center;"></td>
                                <td style="text-align: center;"><input type="number" name="items[0][qty]" class="qty" value="" min="1" style="text-align: center;" placeholder="0"></td>
                                <td style="text-align: center;"><input type="number" step="0.01" class="subtotal" value="0.00" readonly style="text-align: center;"></td>
                                <td style="text-align: center;"><button type="button" class="btn-remove" onclick="removeRow(this)" style="display:none;">Remove</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <button type="button" class="btn-add" onclick="addItem()">+ Add Product</button>

                <div class="total-section">
                    <table style="width: 100%; border: none;">
                        <tr>
                            <td style="border: none; text-align: right; padding: 10px 20px;">
                                <span style="font-size: 14px; color: #666;">Subtotal</span>
                            </td>
                            <td style="border: none; text-align: right; padding: 10px 20px; width: 150px;">
                                <strong id="subtotal-display" style="font-size: 14px; color: #333;">RM 0.00</strong>
                            </td>
                        </tr>
                        <tr>
                            <td style="border: none; text-align: right; padding: 10px 20px;">
                                <span style="font-size: 14px; color: #666;">Tax</span>
                            </td>
                            <td style="border: none; text-align: right; padding: 10px 20px;">
                                <strong id="tax-display" style="font-size: 14px; color: #333;">RM 0.00</strong>
                            </td>
                        </tr>
                        <tr style="border-top: 2px solid #e8e8e8;">
                            <td style="border: none; text-align: right; padding: 15px 20px;">
                                <span style="font-size: 16px; color: #333; font-weight: 700;">Total</span>
                            </td>
                            <td style="border: none; text-align: right; padding: 15px 20px;">
                                <strong id="grand-total-display" style="font-size: 16px; color: #333; font-weight: 700;">RM 0.00</strong>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="button-group">
                <button type="submit" name="action" value="submit" class="btn btn-primary">Submit Purchase Order</button>
                <button type="button" class="btn btn-secondary" onclick="window.location.reload()">Cancel</button>
            </div>
        </form>
    </div>

    <script>
const allProducts = <?= json_encode($products) ?>;
let itemCount = 1;
let selectedSupplierId = '';

// Form validation before submission
document.getElementById('purchase-form').addEventListener('submit', function(e) {
    if (!selectedSupplierId) {
        e.preventDefault();
        alert('Please select a supplier!');
        return false;
    }
    
    // Check if at least one product has been selected with valid quantity
    let hasValidProduct = false;
    document.querySelectorAll('#items-body tr').forEach(row => {
        const productId = row.querySelector('.product-id').value;
        const qty = parseInt(row.querySelector('.qty').value) || 0;
        
        if (productId && qty > 0) {
            hasValidProduct = true;
        }
    });
    
    if (!hasValidProduct) {
        e.preventDefault();
        alert('Please add at least one product with a valid quantity to the order!');
        return false;
    }
    
    return true;
});

// Calculate totals
function calculateTotals() {
    let subtotal = 0;
    
    document.querySelectorAll('#items-body tr').forEach(row => {
        const unitPrice = parseFloat(row.querySelector('.unit-price').value) || 0;
        const qty = parseInt(row.querySelector('.qty').value) || 0;
        const rowSubtotal = unitPrice * qty;
        
        row.querySelector('.subtotal').value = rowSubtotal.toFixed(2);
        subtotal += rowSubtotal;
    });
    
    const tax = 0; // Set to 0% or change as needed
    const grandTotal = subtotal + tax;
    
    document.getElementById('subtotal-display').textContent = 'RM ' + subtotal.toFixed(2);
    document.getElementById('tax-display').textContent = 'RM ' + tax.toFixed(2);
    document.getElementById('grand-total-display').textContent = 'RM ' + grandTotal.toFixed(2);
}

// Supplier selection handler
document.getElementById('supplier_id').addEventListener('change', function() {
    selectedSupplierId = this.value;
    const selectedOption = this.options[this.selectedIndex];
    const supplierInfo = document.getElementById('supplier-info');
    const supplierIdDisplay = document.getElementById('supplier_id_display');
    
    if (selectedSupplierId) {
        supplierIdDisplay.value = selectedSupplierId;
        document.getElementById('supplier-contact').textContent = selectedOption.dataset.contact;
        document.getElementById('supplier-address').textContent = selectedOption.dataset.address;
        supplierInfo.classList.add('show');
        
        // Clear all product selections
        document.querySelectorAll('.product-search').forEach(input => {
            input.value = '';
        });
        document.querySelectorAll('.product-id').forEach(input => {
            input.value = '';
        });
        document.querySelectorAll('.current-stock').forEach(input => {
            input.value = '0';
        });
        document.querySelectorAll('.unit-price').forEach(input => {
            input.value = '0.00';
        });
        document.querySelectorAll('.qty').forEach(input => {
            input.value = '';
        });
        document.querySelectorAll('.subtotal').forEach(input => {
            input.value = '0.00';
        });
        calculateTotals();
    } else {
        supplierIdDisplay.value = '';
        supplierInfo.classList.remove('show');
    }
});

function addItem() {
    if (!selectedSupplierId) {
        alert('Please select a supplier first!');
        return;
    }
    
    const tbody = document.getElementById('items-body');
    const row = document.createElement('tr');
    row.setAttribute('data-row', itemCount);
    
    row.innerHTML = `
        <td style="text-align: center;">${itemCount + 1}</td>
        <td>
            <div class="autocomplete">
                <input type="text" class="product-search" placeholder="Type to search..." autocomplete="off">
                <input type="hidden" name="items[${itemCount}][product_id]" class="product-id">
            </div>
        </td>
        <td style="text-align: center;"><input type="number" class="current-stock" value="0" readonly style="text-align: center;"></td>
        <td style="text-align: center;"><input type="number" step="0.01" class="unit-price" value="0.00" readonly style="text-align: center;"></td>
        <td style="text-align: center;"><input type="number" name="items[${itemCount}][qty]" class="qty" value="" min="1" style="text-align: center;" placeholder="0"></td>
        <td style="text-align: center;"><input type="number" step="0.01" class="subtotal" value="0.00" readonly style="text-align: center;"></td>
        <td style="text-align: center;"><button type="button" class="btn-remove" onclick="removeRow(this)">Remove</button></td>
    `;
    
    tbody.appendChild(row);
    itemCount++;
    
    const searchInput = row.querySelector('.product-search');
    const qtyInput = row.querySelector('.qty');
    
    setupAutocomplete(searchInput);
    qtyInput.addEventListener('input', calculateTotals);
    
    updateRemoveButtons();
    calculateTotals();
}

function removeRow(btn) {
    btn.closest('tr').remove();
    updateRowNumbers();
    updateRemoveButtons();
    calculateTotals();
}

function updateRowNumbers() {
    document.querySelectorAll('#items-body tr').forEach((row, index) => {
        row.querySelector('td:first-child').textContent = index + 1;
    });
}

function updateRemoveButtons() {
    const rows = document.querySelectorAll('#items-body tr');
    document.querySelectorAll('.btn-remove').forEach(btn => {
        btn.style.display = rows.length > 1 ? 'inline-block' : 'none';
    });
}

function setupAutocomplete(input) {
    input.addEventListener('input', function() {
        const val = this.value.toLowerCase().trim();
        closeAllLists();
        
        if (val.length < 1 || !selectedSupplierId) return;
        
        const row = this.closest('tr');
        const autocompleteDiv = document.createElement('div');
        autocompleteDiv.setAttribute('class', 'autocomplete-items');
        this.parentNode.appendChild(autocompleteDiv);
        
        const matches = allProducts.filter(product => 
            product.supplier_id === selectedSupplierId &&
            (product.product_name.toLowerCase().includes(val) ||
             product.product_id.toLowerCase().includes(val))
        );
        
        if (matches.length > 0) {
            matches.slice(0, 10).forEach(product => {
                const itemDiv = document.createElement('div');
                const stockWarning = product.stock_quantity <= 10 ? 
                    '<span class="stock-warning">⚠ Low Stock</span>' : '';
                
                itemDiv.innerHTML = `
                    <div style="font-weight: 600; color: #1890ff;">${product.product_name} ${stockWarning}</div>
                    <div style="font-size: 12px; color: #666; margin-top: 2px;">
                        ID: ${product.product_id} | Price: RM ${parseFloat(product.product_price).toFixed(2)} | 
                        Current Stock: ${product.stock_quantity}
                    </div>
                `;
                
                itemDiv.addEventListener('click', function() {
                    input.value = product.product_name;
                    row.querySelector('.product-id').value = product.product_id;
                    row.querySelector('.current-stock').value = product.stock_quantity;
                    row.querySelector('.unit-price').value = parseFloat(product.product_price).toFixed(2);
                    calculateTotals();
                    closeAllLists();
                });
                
                autocompleteDiv.appendChild(itemDiv);
            });
        } else {
            const noResultDiv = document.createElement('div');
            noResultDiv.innerHTML = '<div style="color: #999; padding: 10px;">No products found for this supplier</div>';
            autocompleteDiv.appendChild(noResultDiv);
        }
    });
}

function closeAllLists() {
    document.querySelectorAll('.autocomplete-items').forEach(el => el.remove());
}

document.addEventListener('click', e => {
    if (!e.target.classList.contains('product-search')) closeAllLists();
});

document.addEventListener('DOMContentLoaded', function() {
    setupAutocomplete(document.querySelector('.product-search'));
    
    // Add event listener to initial quantity input
    document.querySelector('.qty').addEventListener('input', calculateTotals);
    
    // Auto-hide success message after 5 seconds
    const successMessage = document.querySelector('.success-message');
    if (successMessage) {
        setTimeout(function() {
            successMessage.style.transition = 'opacity 0.5s ease';
            successMessage.style.opacity = '0';
            setTimeout(function() {
                successMessage.style.display = 'none';
            }, 500);
        }, 5000);
    }
});
    </script>
</body>
</html>