<?php
session_start();
require_once 'config/database.php';
include_once '_base.php';
include 'sidebar.php'; 

if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
    die("Access denied.");
}

if(!isset($_GET['id'])){
    die("Invalid request.");
}

$id = $_GET['id'];
$msg = '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();
if(!$user) die("User not found.");

$usernameError = '';
$passwordError = '';
$updateSuccess = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $newUsername = trim($_POST['username']);
    $newPassword = trim($_POST['password']);
    $newRole = $_POST['role'] ?? 'employee';

    if(empty($newUsername)){
        $usernameError = "Username cannot be empty.";
    } else {
        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ? AND user_id != ?");
        $stmt->execute([$newUsername, $id]);
        if($stmt->fetch()){
            $usernameError = "Username already exists!";
        }
    }

    if(empty($usernameError)){
        if(!empty($newPassword)){
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET username=?, password=?, role=? WHERE user_id=?");
            $stmt->execute([$newUsername, $hashedPassword, $newRole, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET username=?, role=? WHERE user_id=?");
            $stmt->execute([$newUsername, $newRole, $id]);
        }
        $updateSuccess = "User updated successfully.";

        $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id=?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit User - Inventory System</title>
<style>
.main-content { margin: 10px; font-family: "Segoe UI", Arial, sans-serif; }
.container { max-width: 400px; margin: 50px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #aaa; }
input, select { width: 100%; padding: 8px; margin: 15px 0; box-sizing: border-box; border-radius: 8px; font-size: 15px; }
.btn-update { display:inline-block; background-color: #b8f9adff; color: black; font-size: 15px; border:none; border-radius:4px; text-decoration:none; padding: 8px; margin-top:10px;}
.btn-update:hover{ background-color: #7ee183ff; transform: scale(1.1);}
.return-btn { background-color: #13688aa5; color: white; padding: 10px; border: none; border-radius: 4px; cursor: pointer;}
.return-btn:hover { background-color: #1565c0; transform: translateY(-2px);}
.error-msg { background: #fdecea; color: #b71c1c; border: 1px solid #f5c6cb; padding:5px;}
.success-msg { background: #e8f5e9; color: #1b5e20; border: 1px solid #c8e6c9; margin-left: auto; margin-right:auto; padding:5px;}
a.back { display:inline-block; margin-bottom:10px; color:#007bff; text-decoration:none; }
</style>
</head>
<body>
<div class="main-content">
    <a href="user_management.php">
        <button class="return-btn"><strong>←</strong></button>
    </a>

    <div class="container">
        <h2>Edit User</h2>

        <?php if($updateSuccess) echo "<div class='success-msg'>$updateSuccess</div>"; ?>

        <form method="POST">
            <label>Username</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>">
            <?php if($usernameError) echo "<div class='error-msg'>$usernameError</div>"; ?>

            <label>New Password (leave empty to keep current)</label>
            <input type="password" name="password">
            <?php if($passwordError) echo "<div class='error-msg'>$passwordError</div>"; ?>

            <label>Role</label>
            <select name="role">
                <option value="employee" <?php echo ($user['role']=='employee')?'selected':''; ?>>Employee</option>
                <option value="admin" <?php echo ($user['role']=='admin')?'selected':''; ?>>Admin</option>
            </select>

            <button class="btn-update" type="submit">Update</button>
        </form>
    </div>
</div>

<?php include_once '_foot.php'; ?>
</body>
</html>
