<?php
session_start();
require_once 'config/database.php';
include_once '_base.php';

if(!isset($_GET['id']) || trim($_GET['id']) === ''){
    die('Invalid supplier ID.');
}

$supplier_id = $_GET['id'];

$stmt = $pdo->prepare("SELECT supplier_id, supplier_name, supplier_contact, supplier_address FROM suppliers WHERE supplier_id = ?");
$stmt->execute([$supplier_id]);
$supplier = $stmt->fetch();
if(!$supplier){ die('Supplier not found.'); }

$nameError = $contactError = $addressError = '';
$updateSuccess = '';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $supplier_name = trim($_POST['supplier_name'] ?? '');
    $supplier_contact = trim($_POST['supplier_contact'] ?? '');
    $supplier_address = trim($_POST['supplier_address'] ?? '');

    // Validation
    if($supplier_name === ''){ 
        $nameError = 'Supplier name is required.'; 
    } elseif(!preg_match('/^[a-zA-Z\s]+$/', $supplier_name)){
        $nameError = 'Supplier name must contain only alphabets.';
    } else {
        $words = count(array_filter(explode(' ', $supplier_name)));
        if($words > 50){
            $nameError = "Supplier name must not exceed 50 words (current: $words).";
        }
    }

    if($supplier_contact === ''){
        $contactError = 'Contact is required.';
    } elseif(!preg_match('/^01\d-\d{7}$/', $supplier_contact)){
        $contactError = 'Contact must follow format "01x-xxxxxxx" (e.g., 012-3456789).';
    }

    if($supplier_address === ''){
        $addressError = 'Address is required.';
    } elseif(!preg_match('/^[a-zA-Z0-9\s,.\-\/]+$/', $supplier_address)){
        $addressError = 'Address can only contain letters, numbers, commas, periods, hyphens, and slashes.';
    } else {
        $words = count(array_filter(explode(' ', $supplier_address)));
        if($words > 100){
            $addressError = "Address must not exceed 100 words (current: $words).";
        }
    }

    if(!$nameError && !$contactError && !$addressError){
        $stmt = $pdo->prepare("UPDATE suppliers SET supplier_name = ?, supplier_contact = ?, supplier_address = ? WHERE supplier_id = ?");
        if($stmt->execute([$supplier_name, $supplier_contact, $supplier_address, $supplier_id])){
            $updateSuccess = 'Supplier updated successfully.';
            // Refresh data
            $stmt = $pdo->prepare("SELECT supplier_id, supplier_name, supplier_contact, supplier_address FROM suppliers WHERE supplier_id = ?");
            $stmt->execute([$supplier_id]);
            $supplier = $stmt->fetch();
        } else {
            $nameError = 'Failed to update supplier.';
        }
    }
}

include 'sidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Supplier - Inventory System</title>
<style>
.main-content {
    margin: 10px;
    font-family: "Segoe UI", Arial, sans-serif;
}
.container { max-width: 600px; margin: 50px auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px #aaa; }
.container h2{font-weight:700;}
input, textarea { width: 100%; padding: 8px; margin: 15px 0; box-sizing: border-box; border-radius: 8px; font-size: 15px;}
button { padding: 8px 12px; background: #007bff; color: #fff; border: none; cursor: pointer; margin-top: 10px; }
btn { padding: 8px 12px; background: #007bff; color: #fff; border: none; cursor: pointer; margin: 10px;display:inline-block }
.btn-update {
    display:inline-block; background-color: #b8f9adff; color: black; font-size: 15px; border-radius:4px; text-decoration:none; padding: 10px ;margin-top:10px;}
.btn-update:hover{
    background-color: #7ee183ff;
	transform: scale(1.1);
}.return-btn {
        background-color: #13688aa5;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
}
.return-btn:hover {
    background-color: #1565c0;
    transform: translateY(-2px);
}
.error-msg { color: red; font-size: 0.9em; margin: 2px 0; }
.success-msg { background: #e8f5e9;
    color: #1b5e20;
    border: 1px solid #c8e6c9; 
    margin-left: auto;
    margin-right:auto;}
.back { display:inline-block; margin-bottom:10px; color:#007bff; text-decoration:none; }
</style>
</head>
<body>
<div class="main-content">
    <a href="supplier_management.php">
        <button class="return-btn"><strong>←</strong></button>
    </a>
<div class="container">
  
    <h2>Edit Supplier</h2>

    <?php if($updateSuccess) echo "<div class='success-msg'>".htmlspecialchars($updateSuccess)."</div>"; ?>

    <form method="POST">
        <label>Supplier ID</label>
        <input type="text" value="<?php echo htmlspecialchars($supplier['supplier_id']); ?>" disabled>

        <label>Supplier Name</label>
        <input type="text" name="supplier_name" placeholder="Alphabets only, max 50 words" value="<?php echo htmlspecialchars($supplier['supplier_name']); ?>">
        <?php if($nameError) echo "<div class='error-msg'>".htmlspecialchars($nameError)."</div>"; ?>

        <label>Contact</label>
        <input type="text" name="supplier_contact" placeholder="e.g., 012-3456789" value="<?php echo htmlspecialchars($supplier['supplier_contact']); ?>">
        <?php if($contactError) echo "<div class='error-msg'>".htmlspecialchars($contactError)."</div>"; ?>

        <label>Address</label>
        <textarea name="supplier_address" rows="3" placeholder="Max 100 words"><?php echo htmlspecialchars($supplier['supplier_address']); ?></textarea>
        <?php if($addressError) echo "<div class='error-msg'>".htmlspecialchars($addressError)."</div>"; ?>

        <button class="btn btn-update" type="submit">Update Supplier</button>
    </form>
</div></div>
<?php 
include_once '_foot.php';
?>
</body>
</html>
