<?php
session_start();
require_once 'config/database.php';
include_once '_base.php';

// Redirect if not logged in or not admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
    header("Location: index.php");
    exit;
}

$username = $_SESSION['username'];
$loggedInId = $_SESSION['user_id'];

// Handle search
$searchQuery = '';
if(isset($_GET['search'])) {
    $searchQuery = trim($_GET['search']);
    $stmt = $pdo->prepare("
        SELECT user_id, username, role FROM users 
        WHERE user_id != ? AND username LIKE ? 
        ORDER BY role, username
    ");
    $stmt->execute([$loggedInId, "%{$searchQuery}%"]);
} else {
    $stmt = $pdo->prepare("
        SELECT user_id, username, role FROM users 
        WHERE user_id != ?
        ORDER BY role, username
    ");
    $stmt->execute([$loggedInId]);
}
$users = $stmt->fetchAll();

// Success message
$successMsg = '';
if(isset($_SESSION['success'])){
    $successMsg = $_SESSION['success'];
    unset($_SESSION['success']);
}
?>
<?php include 'sidebar.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Management</title>
<style>
.main-content {
    margin: 10px;
    font-family: "Segoe UI", Arial, sans-serif;
}
.return-btn {
        background-color: #13688aa5;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
}
.return-btn:hover {
    background-color: #1565c0;
    transform: translateY(-2px);
}
.container { max-width:900px; margin-left:auto;margin-right: auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 0 10px #aaa; }
h2 { text-align:center; margin-bottom:20px; }
.table-container{
    max-height: 25vh;
    overflow-y: auto;
}
table { width: 100%;border-collapse: collapse;margin-top: 5px;}
table th, table td {     
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;}
table th {    background-color: #FFE0B2;
    font-weight: 600; }
table tr:hover {
    background-color: #f5f5f5;
}
.btn {
    padding: 8px 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s;
}
.button-edit{ display:inline-block; background-color: #c8e6ffff; color: black; font-size: 15px; border-radius:4px; text-decoration:none; }
.button-edit:hover{ background-color: #64b3f8ff;}

.button-delete {background-color: #ff948dff; color: black; font-size: 15px; border-radius:4px; text-decoration:none; }
.button-delete:hover {background-color: #ff5043ff; }

.search-form { margin-bottom:15px; text-align:right; }
.search-form input[type="text"] { padding:5px; width:200px; }
.search-form button { padding:5px 10px; background-color: #f3d8ffff;border: 0px; border-radius: 8px; }
.search-form button:hover{ background-color: #e3b5f7ff}
.back-link { display:inline-block; margin-bottom:15px; color:#007bff; text-decoration:none; }
.back-link:hover { text-decoration:underline; }
.success-msg{ background: #e8f5e9;
    color: #1b5e20;
    border: 1px solid #c8e6c9; 
    padding:10px;
    margin:50px;
 }
form.add-admin input[type="text"], form.add-admin input[type="password"] { width: 200px; padding:5px; margin:0 5px 5px 0; }
form.add-admin button { padding:5px 10px; }

.add-admin-container{
    margin: 10px;
}
.add-admin-container h3{
    margin-top: 30px;
    font-size: 20px;
}
.add-admin button{
    background-color: #b8f9adff;
    color: black;
    font-size: 15px;
    border: 0px;
    border-radius: 8px;
    padding: 5px 10px;
}
.add-admin button:hover{
    background-color: #7ee183ff;
 
}

</style>
</head>
<body>
<div class="main-content">
    <a href="dashboard.php">
        <button class="return-btn"><strong>←</strong></button>
    </a>
<div class="container">
    <h2>User Management</h2>

    <?php if($successMsg): ?>
        <div class="success-msg"><?php echo htmlspecialchars($successMsg); ?></div>
    <?php endif; ?>

    <!-- Search form -->
    <form method="GET" class="search-form">
        <input type="text" name="search" placeholder="Search username..." value="<?php echo htmlspecialchars($searchQuery); ?>">
        <button type="submit">Search</button>
        <?php if($searchQuery): ?>
            <a href="user_management.php" style="margin-left:5px;">Clear</a>
        <?php endif; ?>
    </form>

    <!-- Users table -->
    <div class="table-container"><table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if(count($users) > 0): ?>
            <?php foreach($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['user_id']); ?></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo htmlspecialchars(ucfirst($user['role'])); ?></td>
                    <td>
                        <?php if($user['role'] !== 'customer'): ?>
                            <a href="edit_user.php?id=<?php echo urlencode($user['user_id']); ?>&role=<?php echo urlencode($user['role']); ?>" class="btn button-edit">Edit</a>
                            <a href="delete_user.php?id=<?php echo urlencode($user['user_id']); ?>&role=<?php echo urlencode($user['role']); ?>" class="btn button-delete" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                        <?php else: ?>
                            <span style="color: #999;">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="4">No users found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
    <!-- Add New Admin -->
    <div class="add-admin-container">
    <h3>Add New Admin</h3>
    <form method="post" action="add_user.php" class="add-admin">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <input type="hidden" name="role" value="admin">
        <button type="submit">Add Admin</button>
    </form>
    </div>
</div></div>
<?php 
include_once '_foot.php';
?>
</body>
</html>