<?php 
include_once 'config/database.php';
include_once '_base.php';

$error = '';
$success = '';

// update category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $new_cat_id = trim($_POST['cat_id']);
    $cat_name = trim($_POST['cat_name']);
    $old_cat_id = $_POST['old_cat_id'];
    
    // Validation
    if (empty($new_cat_id) || empty($cat_name)) {
        $error = "All fields are required!";
    } elseif (!preg_match('/^CA\d+$/', $new_cat_id)) {
        $error = "Category ID must start with 'CA' followed by numbers only (e.g., CA001, CA123). No punctuation allowed.";
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM category WHERE cat_id = ? AND cat_id != ?");
        $stmt->execute([$new_cat_id, $old_cat_id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $error = "Category ID '$new_cat_id' already exists. Please use a different ID.";
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE category SET cat_id = ?, cat_name = ? WHERE cat_id = ?");
                $stmt->execute([$new_cat_id, $cat_name, $old_cat_id]);
                
                header("Location: " . $_SERVER['PHP_SELF'] . "?success=update");
                exit();
            } catch (PDOException $e) {
                $error = "Error updating category: " . $e->getMessage();
            }
        }
    }
}

// add category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $cat_id = trim($_POST['cat_id']);
    $cat_name = trim($_POST['cat_name']);
    
    // Validation
    if (empty($cat_id) || empty($cat_name)) {
        $error = "All fields are required!";
    } elseif (!preg_match('/^CA\d+$/', $cat_id)) {
        $error = "Category ID must start with 'CA' followed by numbers only (e.g., CA001, CA123). No punctuation allowed.";
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM category WHERE cat_id = ?");
        $stmt->execute([$cat_id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $error = "Category ID '$cat_id' already exists. Please use a different ID.";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO category (cat_id, cat_name) VALUES (?, ?)");
                $stmt->execute([$cat_id, $cat_name]);
                
                header("Location: " . $_SERVER['PHP_SELF'] . "?success=add");
                exit();
            } catch (PDOException $e) {
                $error = "Error adding category: " . $e->getMessage();
            }
        }
    }
}

// delete category
if (isset($_GET['delete'])) {
    $cat_id = $_GET['delete'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM category WHERE cat_id = ?");
        $stmt->execute([$cat_id]);
        
        header("Location: " . $_SERVER['PHP_SELF'] . "?success=delete");
        exit();
    } catch (PDOException $e) {
        $error = "Error deleting category: " . $e->getMessage();
    }
}

// Check for success message
if (isset($_GET['success'])) {
    if ($_GET['success'] == 'add') {
        $success = "Category added successfully!";
    } elseif ($_GET['success'] == 'update') {
        $success = "Category updated successfully!";
    } elseif ($_GET['success'] == 'delete') {
        $success = "Category deleted successfully!";
    }
}

// get edit id
$edit_id = $_GET['edit'] ?? null;
?>

<body>

    <?php include 'sidebar.php'; ?>

<div class="main-content">

    <a href="product&inventory_management.php">
        <button class="return-btn"><strong>←</strong></button>
    </a>

    <div class="header">
        <h1>Product Category Management</h1>
    </div>
    
    <?php if (!empty($error)): ?>
        <div class="alert alert-error">
            ❌ <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success">
            ✓ <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>
    
    <div class="category-container">    
        <div class="category-list">
            <h2>Product Category List</h2> 

    <?php
        $stmt = $pdo->prepare("SELECT * FROM category");
        $stmt->execute();
        $category = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($category)) {
            echo '<table>';
            echo '<tr>
                    <th>Category ID</th>
                    <th>Category Name</th>
                    <th>Actions</th>
                    </tr>';
            
            foreach ($category as $cat) {
                if ($edit_id == $cat['cat_id']) {
                    echo '<tr>';
                    echo '<form action="" method="POST">';
                    echo '<td><input type="text" name="cat_id" value="' . htmlspecialchars($cat['cat_id']) . '" required style="width: 90%; padding: 5px;"></td>';
                    echo '<td><input type="text" name="cat_name" value="' . htmlspecialchars($cat['cat_name']) . '" required style="width: 90%; padding: 5px;"></td>';
                    echo '<td>
                            <input type="hidden" name="old_cat_id" value="' . htmlspecialchars($cat['cat_id']) . '">
                            <button type="submit" name="update" class="btn btn-success">Save</button>
                            <a href="' . $_SERVER['PHP_SELF'] . '"><button type="button" class="btn btn-secondary">Cancel</button></a>
                            </td>';
                    echo '</form>';
                    echo '</tr>';
                } else {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($cat['cat_id']) . '</td>';
                    echo '<td>' . htmlspecialchars($cat['cat_name']) . '</td>';
                    echo '<td>
                            <a href="?edit='. urlencode($cat['cat_id']) . '">
                                <button class="btn btn-secondary">Edit</button>
                            </a>
                            <a href="?delete='. urlencode($cat['cat_id']) . '"onclick="return confirm(\'Are you sure you want to delete this category?\')">
                                <button class="btn btn-danger">Delete</button>
                            </a>
                            </td>';
                    echo '</tr>';
                }
            }
            
            echo '</table>';
        } else {
            echo '<p style="text-align: center; color: #999; padding: 40px;">No categories available</p>';
        }
    ?>
</div>    
        
    <div class="add-category">
        <h2>Add New Category</h2>
        <form action="" method="POST">
            <label for="cat_id">Category ID: <span class="required">*</span></label><br>
            <input type="text" id="cat_id" name="cat_id" required 
                   placeholder="e.g., CA001, CA123"
                   value="<?= isset($_POST['cat_id']) && !empty($error) ? htmlspecialchars($_POST['cat_id']) : '' ?>"><br>
            <small style="color: #666;">Format: CA followed by numbers (e.g., CA001)</small><br><br>
            
            <label for="cat_name">Category Name: <span class="required">*</span></label><br>
            <input type="text" id="cat_name" name="cat_name" required
                   placeholder="Enter category name"
                   value="<?= isset($_POST['cat_name']) && !empty($error) ? htmlspecialchars($_POST['cat_name']) : '' ?>"><br><br>
            
            <input type="submit" name="add" value="Add Category">
        </form>
    </div>
    </div>
</div>
<?php 
include_once '_foot.php';
?>
</body>

<style>
    .main-content {
        margin: 20px;
    }
    .return-btn {
        background-color: #13688aa5;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .return-btn:hover {
    background-color: #1565c0;
    transform: translateY(-2px);
}
    .header {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        text-align: center;
        margin-bottom: 25px;
        margin-left: auto;
        margin-right: auto;
        max-width: 500px;
    }

    .header h1 {
        margin: 0;
        font-size: 26px;
        color: #333;
        letter-spacing: 1px;
    }

    .alert {
        padding: 15px;
        margin-left: auto;
        margin-right: auto;
        max-width: 1400px;
        border-radius: 4px;
        font-weight: bold;
        text-align: center;
        animation: slideDown 0.3s ease-out;
    }

    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .alert-error {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    .alert-success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    .category-container {
        display: flex;
        justify-content: space-between;
        gap: 20px;
        margin: 20px;
    }   
    
    .category-list, .add-category {
        background: #fff;
        padding: 30px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        flex: 1;
        margin: 10px;
    }   
    
    .category-list{
        max-height: 70vh;
        overflow-y: auto;
    }
    .category-list h2,
    .add-category h2 {
        font-size: 20px;
        margin-bottom: 15px;
        color: #444;
        border-left: 5px solid #2196f3;
        padding-left: 10px;
    }
    
    table {
        width: 100%;
        border-collapse: collapse;
    }
    
    th, td {
        padding: 10px;
        border: 1px solid #ddd;
        text-align: left;
        font-size: 18px;
    }
    
    th {
        background-color: #FFE0B2;
        font-weight: 600;
    }

    tr:hover {
        background-color: #f9f9f9;
    }
    
    form label {
        font-weight: 600;
        font-size: 18px;
        color: #333;
    }

    .required {
        color: red;
        font-weight: bold;
    }

    small {
        font-size: 12px;
        font-style: italic;
    }

    form input[type="text"],
    form input[type="number"],
    form select {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        margin-bottom: 5px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        font-size: 14px;
    }

    form input[type="text"]:focus,
    form input[type="number"]:focus,
    form select:focus {
        outline: none;
        border-color: #4CAF50;
        box-shadow: 0 0 5px rgba(76, 175, 80, 0.3);
    }

    form input::placeholder {
        color: #999;
    }
    
    form input[type="submit"] {
        background-color: #b8f9adff;
        color: black;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
        font-size: 16px;
        font-weight: bold;
        transition: background-color 0.3s;
    }
    
    form input[type="submit"]:hover {
        background-color: #7ee783ff;
    }

    .btn {
        padding: 6px 12px;
        border: none;
        border-radius: 3px;
        cursor: pointer;
        margin-right: 5px;
        font-size: 12px;
        transition: background-color 0.3s;
    }

.btn-secondary {
    background-color: #c8e6ffff;
    color: black;
    font-size: 15px;
}

.btn-secondary:hover {
    background-color: #64b3f8ff;
    transform: translateY(-2px);
}

.btn-danger {
    background-color: #ff948dff;
    color: black;
    font-size: 15px;
}

.btn-danger:hover {
    background-color: #ff5043ff;
    transform: translateY(-2px);
}

.btn-success {
    background-color: #b8f9adff;
    color: black;
    font-size: 15px;
}
.btn-success:hover {
    background-color: #7ee183ff;
    transform: translateY(-2px);
}
</style>