<?php 
include_once 'config/database.php';
include_once '_base.php';
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product & Inventory Management</title>
</head>

<body>
<?php include 'sidebar.php'; ?>
<div class="main-content">
    <div class="header">
        <h1>Product & Inventory Management</h1>
    </div>

    <div class="action-buttons">
        <a href="product_manage.php" class="action-btn">
            <div class="icon icon-blue">📦</div>
            <span>All<br>Product</span>
        </a>
        <a href="product_category.php" class="action-btn">
            <div class="icon icon-pink">🏷️</div>
            <span>Product<br>Category</span>
        </a>
        <a href="product_manage.php" class="action-btn">
            <div class="icon icon-orange">📋</div>
            <span>Product<br>Manage</span>
        </a>
    </div>
        <!-- Product List Section -->
        <section class="content-area">
            <div class="section-tab">Product List</div>  
            <a href="product_manage.php"><button class="add-pro-btn">+ Add New Product</button></a>     
            <div class="product-list">
                <?php
                $stmt = $pdo->prepare("SELECT * FROM products");
                $stmt->execute();
                $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (!empty($products)) {
                    echo '<table>';
                    echo '<tr>
                            <th>Product ID</th>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Supplier ID</th>
                            <th>Category</th>
                            <th>Stock Quantity</th>
                            <th>Actions</th>
                            </tr>';
                    
                    foreach ($products as $product) {
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($product['product_id']) . '</td>';
                        echo '<td>' . htmlspecialchars($product['product_name']) . '</td>';
                        echo '<td>$' . number_format($product['product_price'], 2) . '</td>';
                        echo '<td>' . htmlspecialchars($product['supplier_id']) . '</td>';
                        echo '<td>' . htmlspecialchars($product['cat_id']) . '</td>';
                        echo '<td>' . htmlspecialchars($product['stock_quantity']) . '</td>';
                        echo '<td>
                                <a href="product_manage.php?product=' . urlencode($product['product_id']) . '"><button class="btn btn-secondary">Edit</button></a>
                                <a href="product_manage.php?product=' . urlencode($product['product_id']) . '"><button class="btn btn-danger">Delete</button></a>
                                </td>';
                        echo '</tr>';
                    }
                    
                    echo '</table>';
                } else {
                    echo '<p style="text-align: center; color: #999; padding: 40px;">No products available</p>';
                }
                ?>
            </div>
        </section>

        <section class="bottom-sections">
            <div class="category-section">
                <div class="section-header">Product Category</div>
                <div class="section-content">
                    <a href="product_category.php?category=' . urlencode($cat['cat_id']) . '"><button class="cat-edit-btn" style="justify-content: right;">Edit</button></a>
                    <?php
                    $stmt = $pdo->prepare("SELECT * FROM category ");
                    $stmt->execute();
                    $category = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if (!empty($category)) {
                        echo '<table>';
                        echo '<tr>
                                <th>Category ID</th>
                                <th>Category Name</th>
                                </tr>';
                        foreach ($category as $cat) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($cat['cat_id']) . '</td>';
                            echo '<td>' . htmlspecialchars($cat['cat_name']) . '</td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo '<p style="text-align: center; color: #999; padding: 20px;">No categories available</p>';
                    }
                    ?>
                </div>
            </div>
    
            <!-- Product Manage -->
            <div class="manage-section">
                <div class="section-header">Product Manage</div>
                <div class="section-content">
                    <?php
                    $lowStockThreshold = 10;
                    $stmt = $pdo->prepare("SELECT product_name, stock_quantity, product_id FROM products WHERE stock_quantity < :threshold ORDER BY stock_quantity ASC");
                    $stmt->bindValue(':threshold', $lowStockThreshold, PDO::PARAM_INT);
                    $stmt->execute();
                    $lowStockProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    ?>

                    <div style="margin-top: 20px; padding: 8px; background-color: #fff3f3; border-radius: 8px; border: 1px solid #ff4848ff;">
                    <h3 style="margin-bottom: 10px; color:black;">⚠️ Low Stock Alert</h3>

    <?php if (!empty($lowStockProducts)): ?>
        <div style="max-height: 150px; overflow-y: auto; border-top:1px solid #f44336; border-bottom:1px solid #f44336;">
            <table style="width:100%; border-collapse: collapse;background-color: #fff;">
                <thead style="width:100%;position: sticky; top: 0; background-color: #fdd;">
                    <tr>
                        <th style="padding:8px; text-align:left; border-bottom:1px solid #000000ff;">Product Name</th>
                        <th style="padding:8px; text-align:left; border-bottom:1px solid #000000ff;">Current Stock</th>
                        <th style="padding:8px; text-align:left; border-bottom:1px solid #000000ff;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lowStockProducts as $prod): ?>
                    <tr>
                        <td style="padding:8px;"><?= htmlspecialchars($prod['product_name']) ?></td>
                        <td style="padding:8px;"><?= htmlspecialchars($prod['stock_quantity']) ?></td>
                        <td style="padding:8px;">
                        <a href="purchase_management.php?product=<?= urlencode($prod['product_id']) ?>"><button class="btn btn-secondary" style="padding:10px;">✎ Add</button></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p>All products have sufficient stock ✅</p>
    <?php endif; ?>
</div>


                </div>
            </div>
        </section>
</div>
<?php 
include_once '_foot.php';
?>
</body>
</html>
<style>
.main-content {
    margin: 10px;
    margin-bottom: 50px;
}

.header {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    text-align: center;
    margin:30px;
    margin-left: auto;
    margin-right: auto;
    max-width: 700px;
    }
.header h1 {
    margin: 0;
    font-size: 26px;
    color: #333;
    letter-spacing: 1px;
}
.add-pro-btn{
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
    margin-top: -30px;
    margin-bottom: 10px;
}

.action-buttons {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-bottom: 30px;
}

.action-btn {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 15px 25px;
    background-color: white;
    border: 2px solid #ddd;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    color: #333;
}

.action-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    border-color: #4CAF50;
}

.icon {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    border-radius: 6px;
}

.icon-blue { background-color: #4FC3F7; }
.icon-pink { background-color: #EC407A; }
.icon-orange { background-color: #FFA726; }

.content-area {
    background-color: white;
    padding: 15px;
    border-radius: 8px;
    margin-top: auto;
    margin-left: 30px;
    margin-right: 30px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.section-tab {
    display: inline-block;
    background-color: fdd;
    color: black;
    padding: 8px 15px;
    border-radius: 4px 4px 0 0;
    margin-bottom: -1px;
    font-weight: 600;
}

.product-list {
    min-height: 300px;
    max-height: 300px;
    border: 1px solid #ddd;
    padding: 20px;
    background-color: #fafafa;
    overflow-y: auto;
}

.bottom-sections {
    display: grid;
    grid-template-columns: 1fr 4fr;
    gap: 20px;
}

.category-section{
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    max-height: 300px;
    overflow-y: auto;
    width: 70vh;
    margin: 30px;
}

.manage-section {
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
    min-width: 0;
    height: auto;
    margin: 30px;
}
.section-content {
    min-height: 262px;
    border: 1px solid #ddd;
    padding: 20px;
    background-color: #fafafa;
}
.cat-edit-btn{
    background-color: #c8e6ffff;
    color: black;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 15px;
    transition: all 0.3s;
    margin-bottom: 10px;
}
.cat-edit-btn:hover{
    background-color: #64b3f8ff;
    transform: translateY(-2px);
}
.section-header {
    background-color: #fdd;
    padding: 10px 15px;
    font-weight: 600;
    color: #333;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 5px;
}

table th, table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

table th {
    background-color: #FFE0B2;
    font-weight: 600;
}

table tr:hover {
    background-color: #f5f5f5;
}

.btn {
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s;
}

.add-pro-btn{
    background-color: #b8f9adff;
    color: black;
    font-size: 15px;
}

.add-pro-btn:hover {
    background-color: #7ee183ff;
    transform: translateY(-2px);
}

.btn-secondary {
    background-color: #c8e6ffff;
    color: black;
    font-size: 15px;
}

.btn-secondary:hover {
    background-color: #64b3f8ff;
    transform: translateY(-2px);
}

.btn-danger {
    background-color: #ff948dff;
    color: black;
}

.btn-danger:hover {
    background-color: #ff5043ff;
    transform: translateY(-2px);
}
</style>
