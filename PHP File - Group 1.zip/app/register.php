<?php
session_start();
require_once 'config/database.php';

$usernameError = '';
$passwordError = '';
$confirmPasswordError = '';
$registerError = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirmPassword = trim($_POST['confirm_password']);

    $role = 'employee';

    // Validation
    if (empty($username)) {
        $usernameError = "Username cannot be empty!";
    }

    if (empty($password)) {
        $passwordError = "Password cannot be empty!";
    }

    if ($password !== $confirmPassword) {
        $confirmPasswordError = "Passwords do not match!";
    }

    if (empty($usernameError) && empty($passwordError) && empty($confirmPasswordError)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Check duplicate username
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);

        if ($stmt->fetch()) {
            $registerError = "Username already exists!";
        } else {
            $stmt = $pdo->prepare(
                "INSERT INTO users (username, password, role) VALUES (?, ?, ?)"
            );

            if ($stmt->execute([$username, $hashedPassword, $role])) {
                $_SESSION['register_success'] = "Employee registration successful! Please login.";
                header("Location: index.php");
                exit;
            } else {
                $registerError = "Registration failed. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register - Inventory System</title>
<style>
body { font-family: Arial; background: #f4f4f4; }
.register-box {
    width: 300px;
    margin: 100px auto;
    padding: 30px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px #aaa;
}
input {
    width: 100%;
    padding: 8px;
    margin: 5px 0;
    box-sizing: border-box;
}
button {
    width: 100%;
    padding: 8px;
    background: #007bff;
    color: #fff;
    border: none;
    cursor: pointer;
}
.error-msg {
    color: red;
    font-size: 0.9em;
    margin: 2px 0 5px 0;
}
label { display: block; margin-top: 10px; }
a { text-decoration: none; color: #007bff; }
</style>
</head>
<body>

<div class="register-box">
    <img src="images/logo.webp" alt="Inventory System Logo"
         style="display:block; margin:0 auto 20px auto; width:120px;">

    <h2>Employee Register</h2>

    <?php if ($registerError) echo "<div class='error-msg'>$registerError</div>"; ?>

    <form method="POST">
        <label>Username</label>
        <input type="text" name="username"
               value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>">
        <?php if ($usernameError) echo "<div class='error-msg'>$usernameError</div>"; ?>

        <label>Password</label>
        <input type="password" name="password">
        <?php if ($passwordError) echo "<div class='error-msg'>$passwordError</div>"; ?>

        <label>Confirm Password</label>
        <input type="password" name="confirm_password">
        <?php if ($confirmPasswordError) echo "<div class='error-msg'>$confirmPasswordError</div>"; ?>

        <button type="submit">Register</button>
    </form>

    <p style="margin-top:10px;">
        Already have an account? <a href="index.php">Login here</a>
    </p>
</div>

</body>
</html>
