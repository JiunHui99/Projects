<?php 
include 'sidebar.php'; 
include '_base.php';
include 'config/database.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sales Management</title>
        <link rel="stylesheet" href="styles.css">

        <style>
            .sales-management-container {
                margin: 10px;
                padding: 20px;
            }

            .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            }

            .sales-menu {
                margin-bottom: 20px;
                display: flex;
                gap: 0;
                border-bottom: 2px solid #000000ff;
            }

            .menu-button {
                padding: 10px 15px;
                border: none;
                background-color: #2c3e50;
                color: white;
                cursor: pointer;
            }

            .menu-button:hover {
                background-color: #007BFF;
            }

            .content-box {
                background: white;
                padding: 15px;
                border-radius: 10px;
                box-shadow: 0 2px 6px rgba(0,0,0,0.15);
                margin-right: 8px;
                margin-left: 8px;
            }

            .sales-table {
                width: 100%;
                border-collapse: collapse;
            }

            .sales-table th, .sales-table td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }

            .sales-table th {
                background-color: #f2f2f2;
            }

            .sub-button {
                margin-bottom: 15px;
                position: relative;
                text-align: right;
                margin-bottom: 10px;
            }

            .sales-rights-button {
                padding: 8px 12px;
                margin-right: 10px;
                border: none;
                background-color: #2c3e50;
                color: white;
                border-radius: 5px;
                cursor: pointer;

            }

            .sales-rights-button:hover {
                background-color: #007BFF;
            }

            .add-record-board {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.3);
                z-index: 1000;
                width: 400px;
                max-width: 90%;
            }

            #blur-layer{
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                backdrop-filter: blur(8px);
                background: rgba(0,0,0,0.4);
                z-index: 999;
            }

            .sales-board-popup .close-button {
                position: absolute;
                top: 10px;
                right: 10px;
                background-color: transparent;
                border: none;
                padding: 8px 12px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 14px;
                font-weight: bold;
                line-height: 1;
                width: auto;
                min-width: 24px;
            }

            .sales-board-popup .close-button:hover {
                background-color: #fd0707ff;
                color: white;
            }

            .paging {
                margin-top: 20px;
                text-align: center;
                padding: 15px;
            }

            .paging button, .paging .nav-button, .paging .page-number {
                padding: 8px 12px;
                margin: 0 3px;
                border: 1px solid #ddd;
                background-color: #f8f9fa;
                color: #333;
                cursor: pointer;
                border-radius: 4px;
                font-size: 14px;
            }

            .paging .page-number {
                background-color: #e8f0ff;
                color: #0b63d6;
                border-color: #d0e3ff;
            }

            .paging .page-number:hover:not(.active){
                background-color: #cfe0ff;
                color: #084aa1;
            }
            
            .paging button:hover:not(:disabled),
            .paging .nav-button:hover:not(:disabled){
                background-color: #007BFF;
                color: white;
                border-color: #007BFF;
            }

            .paging button.active,
            .paging .page-number.active{
                background-color: #007BFF;
                color: white;
                border-color: #007BFF;
                font-weight: bold;
            }

            .paging button:disabled,
            .paging .nav-button:disabled{
                background-color: #e9ecef;
                color: #6c757d;
                cursor: not-allowed;
                border-color: #ddd;
                opacity: 0.6;
            }

            .paging span {
                padding: 8px 5px;
                color: #6c757d;
                font-weight: bold;
            }

            .page-info {
                margin-top: 10px;
                color: #6c757d;
                font-size: 14px;
            }

            .dashboard {
                display: grid;
                gap: 10px;
                grid-template-columns: 1fr 1fr;
                padding: 20px;
            }
            
            .chart-box{
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 2px 6px rgba(0,0,0,0.15);
            }

            .chart-box h3{
                text-align: center;
                color: #23313fff;
                margin-bottom: 15px;
                margin-top: 0;
            }

            .chart-box.full-width {
                grid-column: 1/-1;
            }

            #line-chart, #pie-chart, #hori-bar-chart{
                width: 100% !important;
                height: 400px !important;
            }

            @media (max-width: 1200px){
                .dashboard{
                    grid-template-columns: 1fr;
                }

                .chart-box.full-width {
                    grid-column: 1;
                }

            }

            .delete-record {
                padding: 5px 10px;
                background-color: red;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            .delete-record:hover{
                background-color: #9d0707ff;
            }
        </style>
    </head>

    <body>
        <div id="blur-layer"></div>
        <div class="sales-board-popup" style="display: none;">
            <!-- the sales board popup will be loaded here (add sales record & generate report) -->
        </div>

        <div class="sales-management-container">

            <div class="header">
                <h1>Sales Management</h1>
            </div>

            <div class="separator-frame">
                <div class="sales-menu">
                    <button class="menu-button" id="record-page">Sales Records</button>
                    <button class="menu-button" id="statistics-page">Statistics</button>
                </div>

                <div id="sales-page-content">
                    <!-- the sale content will be loaded here (sales record & sales statistics) -->
                </div>
            </div>
        </div>
    </body>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="js/sales_control.js"></script>
