let currentPage = 1;

document.addEventListener("DOMContentLoaded",function(){

    showPartialPage('sales_management_page/sale_record.php');
    
    document.getElementById('record-page').addEventListener('click', function() {
        showPartialPage('sales_management_page/sale_record.php');
    });
        
    document.getElementById('statistics-page').addEventListener('click', function(){
        showPartialPage('sales_management_page/sale_statistic.php');
    });

})

function showPartialPage(filePath, page = null) {

    let url = filePath;
    if (page !== null && filePath.includes('sale_record.php')){
        url = filePath + '?page=' + page;
        currentPage = page;
    }

    fetch(url)
    .then(response => response.text())
    .then(html => {
        document.getElementById('sales-page-content').innerHTML = html;

        if (filePath.includes('sales_management_page/sale_record.php')){
            saleRecordPageButton();
            addDeleteListeners();
        }

        if (filePath.includes('sales_management_page/sale_statistic.php')){
            setTimeout(function(){
                createLineChart();
                createPieChart();
                createHorizontalBarChart();
            }, 100);

        }
    })
    .catch(error => {
        console.error('Error Loading Page:', error);
    });
    
    if (filePath.includes('sales_management_page/sale_statistic.php')){
        document.getElementById('statistics-page').style.backgroundColor = '#007BFF';
        document.getElementById('record-page').style.backgroundColor = '#2c3e50';
    } else {
        document.getElementById('record-page').style.backgroundColor = '#007BFF';
        document.getElementById('statistics-page').style.backgroundColor = '#2c3e50';
    }
}

function createLineChart(){
       
    const ctx = document.getElementById('line-chart');
    console.log("Canvas found:", ctx);
    
    if (!ctx){
        console.error('Canvas element not found!');
        return;
    }
    
    console.log('Canvas dimensions:', ctx.offsetWidth, ctx.offsetHeight);

    const existingChart = Chart.getChart(ctx);
    if (existingChart){
        existingChart.destroy();
    }

    fetch('sales_management_page/chart/linechart_data.php')
    .then(response => response.json())
    .then(data => {
        console.log('Chart data:', data);

        if (data.error){
            console.error('Data error:', data.error);
            return
        }
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.map(row => row.sales_date),
                datasets: [{
                    label: 'Sales Trend (Last 7 Days)',
                    data: data.map(row => parseFloat(row.daily_sales)),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value){
                                return 'RM ' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        })
    }).catch(error => {
        console.error('Linechart fetch error: ', error);
    });
}

function createPieChart(){

    const ctx = document.getElementById('pie-chart');
    console.log("Canvas found:", ctx);
    
    if (!ctx){
        console.error('Canvas element not found!');
        return;
    }
    
    console.log('Canvas dimensions:', ctx.offsetWidth, ctx.offsetHeight);

    const existingChart = Chart.getChart(ctx);
    if (existingChart){
        existingChart.destroy();
    }

    fetch('sales_management_page/chart/pie_data.php')
    .then(response => response.json())
    .then(data => {
        console.log('Chart data:', data);

        if (data.error){
            console.error('Data error:', data.error);
            return
        }
        
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: data.map(row => row.product_id),
                datasets: [{
                    label: 'Quantity Sold by Product (Top 5)',
                    data: data.map(row => parseFloat(row.quantity_sold_product)),
                    borderWidth: 1,
                    borderColor: '#fff',
                    backgroundColor: [
                        '#10e388ff',
                        '#0db3beff',
                        '#4472c4',
                        '#044ac4ff',
                        '#052356ff',
                    ],
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context){
                                return context.label + ': ' + context.parsed + ' units';
                            }
                        }
                    }
                }
            }
        })
    }).catch(error => {
        console.error("Pie chart fetch error: ", error);
    });
}

function createHorizontalBarChart(){
    const ctx = document.getElementById('hori-bar-chart');
    console.log("Canvas found:", ctx);
    
    if (!ctx){
        console.error('Canvas element not found!');
        return;
    }
    
    console.log('Canvas dimensions:', ctx.offsetWidth, ctx.offsetHeight);

    const existingChart = Chart.getChart(ctx);
    if (existingChart){
        existingChart.destroy();
    }

    fetch('sales_management_page/chart/horizontal_bar_data.php')
    .then(response => response.json())
    .then(data => {
        console.log('Chart data:', data);

        if (data.error){
            console.error('Data error:', data.error);
            return
        }
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.map(row => row.product_id),
                datasets: [{
                    label: 'revenue',
                    data: data.map(row => parseFloat(row.revenue)),
                    borderWidth: 1,
                    borderColor: '#fff',
                    backgroundColor: [
                        '#0db3beff',
                        '#4472c4',
                        '#052356ff',
                    ],
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value){
                                return 'RM ' + value.toLocaleString();
                            }
                        }
                    }
                },
                plugins:{
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context){
                                return 'RM ' + context.parsed.x.toLocaleString();
                            }
                        }
                    }
                }
            }
        })
    }).catch(error => {
        console.error("Bar chart fetch error: ", error);
    });
}


    
function loadSalesPage(page){
    currentPage = page;
    showPartialPage('sales_management_page/sale_record.php', page);
}

function reloadCurrentSalesPage(){
    loadSalesPage(currentPage);
}

function saleRecordPageButton(){
    const addRecordBTN = document.getElementById('add-record-board');

    if (addRecordBTN){
        addRecordBTN.addEventListener('click', function(){
            showBoardPopup('sales_management_page/add_sales_record_board.php');
        });
    }
}

function showBoardPopup(filePath){
    fetch(filePath)
    .then(response => response.text())
    .then(html => {
        const boardPopup = document.querySelector('.sales-board-popup');
        const blurLayer = document.getElementById('blur-layer');

        boardPopup.innerHTML = html;

        const scripts = boardPopup.querySelectorAll('script');
        scripts.forEach(oldScript => {
            const newScript = document.createElement('script');
            newScript.textContent = oldScript.textContent;
            document.body.appendChild(newScript);
            document.body.removeChild(newScript);
        });
        
        boardPopup.style.display = 'block';
        blurLayer.style.display = 'block';
        
        const closeButton = boardPopup.querySelector('.close-button');
        closeButton.addEventListener('click', function(){
            boardPopup.style.display = 'none';
            boardPopup.innerHTML = '';
            blurLayer.style.display = 'none';
        });
    })
    .catch(error => {
        console.error('Error Loading Board:', error);
    });

}

function addDeleteListeners(){
    const deleteButtons = document.querySelectorAll('.delete-record');

    console.log('Found delete button: ', deleteButtons.length);

    deleteButtons.forEach(button => {
        button.addEventListener('click', function(){
            const reportId = this.getAttribute('data-report-id');
            console.log('Delete button clicked, report ID: ', reportId);
            if (confirm('Are you sure you want to delete?')){
                deleteSalesRecord(reportId);
            }
        });
    });
}

function deleteSalesRecord(reportId) {
    fetch('sales_management_page/delete_record.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `sales_report_id=${reportId}`
    })
    .then(response => {

        console.log('Response status:', response.status);
        console.log('Response ok: ', response.ok);
        return response.text();
    })
    .then(text => {
        console.log('Raw response: ', text);
        
        try{
            const data = JSON.parse(text);
            if (data.success){
                alert('Sales report deleted successfully');
                reloadCurrentSalesPage();
            } else {
                alert('Error: ' + data.message);
            }
        } catch (e) {
            console.error('JSON parse error:', e);
            console.error('Response was: ', text);
            alert('Server error. Check console for details.');
        }
    })
    .catch(error => {
        console.error('Delete error: ', error);
        alert('Error deleting sales report. Please try again.');
    })
}






