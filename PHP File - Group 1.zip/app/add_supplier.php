
<?php
session_start();
require_once 'config/database.php';
include '_base.php';

$idError = $nameError = $contactError = $addressError = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $supplier_id = trim($_POST['supplier_id'] ?? '');
    $supplier_name = trim($_POST['supplier_name'] ?? '');
    $supplier_contact = trim($_POST['supplier_contact'] ?? '');
    $supplier_address = trim($_POST['supplier_address'] ?? '');

    // Validation
    if($supplier_id === ''){ 
        $idError = 'Supplier ID is required.'; 
    } elseif(!preg_match('/^SP\d{3}$/', $supplier_id)){
        $idError = 'Supplier ID must follow format "SPxxx" (e.g., SP001).';
    }

    if($supplier_name === ''){ 
        $nameError = 'Supplier name is required.'; 
    } elseif(!preg_match('/^[a-zA-Z\s]+$/', $supplier_name)){
        $nameError = 'Supplier name must contain only alphabets.';
    } else {
        $words = count(array_filter(explode(' ', $supplier_name)));
        if($words > 50){
            $nameError = "Supplier name must not exceed 50 words (current: $words).";
        }
    }

    if($supplier_contact === ''){
        $contactError = 'Contact is required.';
    } elseif(!preg_match('/^01\d-\d{7}$/', $supplier_contact)){
        $contactError = 'Contact must follow format "01x-xxxxxxx" (e.g., 012-3456789).';
    }

    if($supplier_address === ''){
        $addressError = 'Address is required.';
    } elseif(!preg_match('/^[a-zA-Z0-9\s,.\-\/]+$/', $supplier_address)){
        $addressError = 'Address can only contain letters, numbers, commas, periods, hyphens, and slashes.';
    } else {
        $words = count(array_filter(explode(' ', $supplier_address)));
        if($words > 100){
            $addressError = "Address must not exceed 100 words (current: $words).";
        }
    }

    // Check unique supplier_id only if ID is valid
    if(!$idError){
        $stmt = $pdo->prepare("SELECT supplier_id FROM suppliers WHERE supplier_id = ?");
        $stmt->execute([$supplier_id]);
        if($stmt->fetch()){
            $idError = 'Supplier ID already exists.';
        }
    }

    if(!$idError && !$nameError && !$contactError && !$addressError){
        $stmt = $pdo->prepare("INSERT INTO suppliers (supplier_id, supplier_name, supplier_contact, supplier_address) VALUES (?, ?, ?, ?)");
        if($stmt->execute([$supplier_id, $supplier_name, $supplier_contact, $supplier_address])){
            $success = 'Supplier added successfully.';
            // Redirect back to list
            header('Location: supplier_management.php');
            exit;
        } else {
            $nameError = 'Failed to add supplier.';
        }
    }
}

include 'sidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Supplier - Inventory System</title>
<style>
.main-content { margin: 10px; font-family: "Segoe UI", Arial, sans-serif; }
.return-btn { background-color: #13688aa5; color: white; padding: 10px; border: none; border-radius: 4px; cursor: pointer;}
.return-btn:hover { background-color: #1565c0; transform: translateY(-2px);}
.container { max-width: 550px; margin: 50px auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px #aaa; }
input, textarea { width: 100%; padding: 8px; margin: 15px 0; box-sizing: border-box; border-radius: 8px; font-size: 15px; }
button { padding: 8px 12px; background: #007bff; color: #fff; border: none; cursor: pointer; margin-top: 10px; }
.error-msg { color: red; font-size: 0.9em; margin-bottom: 7px; }
.back { display:inline-block; margin-bottom:10px; color:#007bff; text-decoration:none; }
.btn-add { display:inline-block; background-color: #b8f9adff; color: black; font-size: 15px; border:none; border-radius:4px; text-decoration:none; padding: 8px; margin-top:10px;}
.btn-add:hover{ background-color: #7ee183ff; transform: scale(1.1);}
</style>
</head>
<body>
<div class="main-content">
    <a href="supplier_management.php">
        <button class="return-btn"><strong>←</strong></button>
    </a>
<div class="container">

    <h2>Add Supplier</h2>

    <form method="POST">
        <label>Supplier ID</label>
        <input type="text" name="supplier_id" placeholder="e.g., SP001" value="<?php echo htmlspecialchars($_POST['supplier_id'] ?? ''); ?>">
        <?php if($idError) echo "<div class='error-msg'>".htmlspecialchars($idError)."</div>"; ?>

        <label>Supplier Name</label>
        <input type="text" name="supplier_name" placeholder="Alphabets only, max 50 words" value="<?php echo htmlspecialchars($_POST['supplier_name'] ?? ''); ?>">
        <?php if($nameError) echo "<div class='error-msg'>".htmlspecialchars($nameError)."</div>"; ?>

        <label>Contact</label>
        <input type="text" name="supplier_contact" placeholder="e.g., 012-3456789" value="<?php echo htmlspecialchars($_POST['supplier_contact'] ?? ''); ?>">
        <?php if($contactError) echo "<div class='error-msg'>".htmlspecialchars($contactError)."</div>"; ?>

        <label>Address</label>
        <textarea name="supplier_address" rows="3" placeholder="Max 100 words"><?php echo htmlspecialchars($_POST['supplier_address'] ?? ''); ?></textarea>
        <?php if($addressError) echo "<div class='error-msg'>".htmlspecialchars($addressError)."</div>"; ?>

        <button class="btn btn-add" type="submit">Add Supplier</button>
    </form>
</div></div>
<?php include_once '_foot.php'; ?>
</body>
</html>


