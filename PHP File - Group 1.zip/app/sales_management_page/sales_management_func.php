<?php
    require_once '../config/database.php';

    header('Content-Type: application/json');

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $orderId = trim($_POST['order_id']);
        $userId = intval(trim($_POST['user_id']));
        $productId = trim($_POST['product_id']);
        $quantity = intval($_POST['quantity']);
        $totalSales = floatval($_POST['total_sales']);
        $reportDate = date('Y-m-d H:i:s');

        // Insert new sales record
        if ($userId <= 0 || empty($orderId) || empty($productId) || empty($reportDate)) {
            echo json_encode(['success' => false, 'message' => 'All fields are required and must be valid.']);
            exit;
        }

        try{

            $checkStmt = $pdo->prepare("SELECT COUNT(*) AS count FROM sales_reports WHERE order_id = ?");
            $checkStmt->execute([$orderId]);

            if ($checkStmt->fetchcolumn() > 0){
                echo json_encode(['success' => false, 'message' => 'A sales record with this Order ID already exists.']);
                exit;
            }

            $idQueryStmt = $pdo->query("SELECT sales_report_id FROM sales_reports ORDER BY sales_report_id DESC LIMIT 1");
            $lastRecord = $idQueryStmt->fetch(PDO::FETCH_ASSOC);

            if ($lastRecord){
                $lastNumber = intval(substr($lastRecord['sales_report_id'], 2));
                $nextNumber = $lastNumber + 1;
            } else {
                $nextNumber = 1;
            }

            $salesReportId = 'SR' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

            $stmt = $pdo->prepare("INSERT INTO sales_reports (sales_report_id, user_id, order_id, product_id, report_date, total_sales) VALUES (?, ?, ?, ?, ?, ?)");
            $success = $stmt->execute([$salesReportId, $userId, $orderId, $productId, $reportDate, $totalSales]);

            if ($success) {
                try{
                    if ($quantity > 0){
                        $quantityStmt = $pdo->prepare("SELECT stock_quantity FROM products WHERE product_id = ?");
                        $quantityStmt->execute([$productId]);
                        $productQuantity = $quantityStmt->fetch(PDO::FETCH_ASSOC);

                        if($productQuantity && isset($productQuantity['stock_quantity'])){

                            $currentQuantity = intval($productQuantity['stock_quantity']);
                            $deductQuantity = max(0, $currentQuantity - $quantity);
    
                            $updateStmt = $pdo->prepare("UPDATE products SET stock_quantity = ? WHERE product_id = ?");
                            $updateStmt->execute([$deductQuantity, $productId]);
                        }
                    }
                    echo json_encode(['success' => true, 'message' => 'Sales record added successfully.']);
                } catch (PDOException $e){
                    echo json_encode(['success' => false, 'message' => 'Record added but failed updating product stock']);
                }
            }
            else {
                echo json_encode(['success' => false, 'message' => 'Failed to add sales record.']);
            }

        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Error message:' . $e->getMessage()]);
        }

        exit;
    }

?>