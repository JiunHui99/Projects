<?php
error_reporting(0);
ini_set('display_errors', 0);

require_once "../config/database.php";

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sales_report_id = $_POST['sales_report_id'] ?? '';

    if (empty($sales_report_id)){
        echo json_encode(['success' => false, 'message' => 'Sales report ID is required.']);
        exit;
    }

    try {
        $pdo->beginTransaction();
    
        $getStmt = $pdo->prepare("SELECT sr.product_id, sr.order_id, od.quantity
                                  FROM sales_reports sr
                                  JOIN order_details od ON sr.order_id = od.order_id AND sr.product_id = od.product_id
                                  WHERE sr.sales_report_id = ?");
        $getStmt->execute([$sales_report_id]);
        $reportData = $getStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$reportData){
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => 'Sales report not found.']);
            exit;
        }

        $product_id = $reportData['product_id'];
        $quantity_sold = $reportData['quantity'];
        $order_id = $reportData['order_id'];

        $updateProductStock = $pdo->prepare("UPDATE products
                                             SET stock_quantity = stock_quantity + ?
                                             WHERE product_id = ?");
        $updateProductStock->execute([$quantity_sold, $product_id]);

        $deleteStmt = $pdo->prepare("DELETE FROM sales_reports
                                     WHERE sales_report_id = ?");
        $deleteStmt->execute([$sales_report_id]);

        $pdo->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Sales report deleted successfully and stock is restored.',
            'details' => [
                'product_id' => $product_id,
                'quantity_restored' => $quantity_sold
            ]
        ]);
        exit;

    } catch (PDOException $e){
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

?>
