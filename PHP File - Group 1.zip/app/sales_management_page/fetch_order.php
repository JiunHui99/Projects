<?php
    require_once '../config/database.php';

    header('Content-Type: application/json');

    if (isset($_GET['fetch_order']) && isset($_GET['order_id'])){
        $order_id = trim($_GET['order_id']);

        try {
            $stmt = $pdo->prepare('SELECT od.product_id, p.product_price, od.quantity
                                   FROM order_details od
                                   JOIN products p ON od.product_id = p.product_id
                                   WHERE od.order_id = ?');

            $stmt->execute([$order_id]);
            $salesDetails = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($salesDetails) {
                $total_sales = $salesDetails['product_price'] * $salesDetails['quantity'];
                $salesDetails['total_sales'] = $total_sales;
                echo json_encode(['success' => true,
                                  'product_id' => $salesDetails['product_id'],
                                  'product_price' => $salesDetails['product_price'],
                                  'quantity' => $salesDetails['quantity'],
                                  'total_sales' => $total_sales]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Order ID not found.']);
            }
        } catch (PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }
    
    
?>