<?php 
    require_once '../config/database.php';
?>

<script>
    setTimeout(function(){
        console.log('Script loaded');

        const orderInput = document.getElementById('order_id');

        if(!orderInput) {
            console.error('Order Id input not found');
            return;
        }

        console.log('Order id found!');

        let debounceTimer;

        orderInput.addEventListener('input', function(){
            
            const orderId = this.value.trim();
            console.log('User typed:', orderId);

            clearTimeout(debounceTimer);

            document.getElementById('product_id').value = '';
            document.getElementById('price_per_unit').value = '0.00';
            document.getElementById('quantity').value = '0';
            document.getElementById('total_sales').value = '0.00';

            if (orderId === ''){
                console.log('Order ID is empty, skipping fetch.');
                return;
            }

            debounceTimer = setTimeout(function() {

                const url = `sales_management_page/fetch_order.php?fetch_order=1&order_id=${orderId}`;

                console.log('Fetching data from:', url);

                fetch(url)
                .then(response => {
                    console.log('Response received:', response.status);
                    console.log('Response OK? ', response.ok);
                    return response.text();
                })
                .then(text => {
                    console.log('Raw data:', text);
                    try{
                        const data =JSON.parse(text);
                        console.log('Parsed data:', data);

                        if (data.success) {
                            document.getElementById('product_id').value = data.product_id;
                            document.getElementById('price_per_unit').value = data.product_price;
                            document.getElementById('quantity').value = data.quantity;
                            document.getElementById('total_sales').value = data.total_sales.toFixed(2);
                            console.log('fields updated successfully');
                        } else { 
                            console.log('Server error: ', data.message);
                            alert(data.message);
                        }
                    } catch(e){
                        console.error('failed to parse JSON:',e);
                        console.error('Response was: ', text);
                        alert('Server returned invlid data.');
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    alert('Error fetching order details. Please try again.');
                });
            }, 1000); // debounce delay of 1000ms
        });

        // submit handler
        const form = document.getElementById('add_sales_record');

        form.addEventListener('submit', function(e){
            e.preventDefault();

            const formData = new FormData(form);

            fetch('sales_management_page/sales_management_func.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(text => {
                try{
                    const data = JSON.parse(text);
                
                    if(data.success){
                        alert(data.message);

                        document.querySelector('.sales-board-popup').style.display = 'none';
                        document.getElementById('blur-layer').style.display = 'none';

                        showPartialPage('sales_management_page/sale_record.php');
                    } else {
                        alert('Error: ' + data.message);
                    }
                } catch(e){
                    console.error('failed to parse JSON:',e);
                    alert('Server returned invalid data.');
                }
            })
            .catch(error => {
                alert('Error adding sales record. Please try again.');

            });
        });

        console.log('Event listener attached successfully');
    }, 100);

</script>

<style>
    .add-record-board {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        z-index: 1000;
        width: 400px;
        max-width: 90%;
    }

    .add-record-board h2 {
        margin-top: 0;
        text-align: center;
    }

    .add-record-board .close-button {
        position: absolute;
        top: 10px;
        right: 10px;
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
    }

    .add-record-board form {
        display: flex;
        flex-direction: column;
    }

    .add-record-board label {
        margin-top: 10px;
        margin-bottom: 5px;
    }

    .add-record-board input {
        padding: 8px;
        font-size: 14px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .add-record-board button[type="submit"] {
        margin-top: 15px;
        padding: 10px;
        background-color: #28a745;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    .add-record-board button[type="submit"]:hover {
        background-color: #218838;
    }


</style>
<div class="add-record-board">
    <button class="close-button" title="Close">X</button>
    <h2> Add New Sales Record </h2>
    <form method="POST" id="add_sales_record">
        <label for="order_id">Order ID:</label>
        <input type="text" id="order_id" name="order_id" required>

        <label for="user_id">User ID:</label>
        <input type="text" id="user_id" name="user_id" placeholder="1" required>

        <label for="product_id">Product ID:</label>
        <input type="text" id="product_id" name="product_id" placeholder="1001" required>

        <label for="price_per_unit">Price per unit:</label>
        <input type="number" step="0.01" id="price_per_unit" name="price_per_unit" value="0.00" min="0.00" required>

        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" value="0" min="0" required>

        <label for="total_sales">Total Sales:</label>
        <input type="number" step="0.01" id="total_sales" name="total_sales" value="0" readonly required>

        <label for="report_date">Report Date:</label>
        <input type="date" id="report_date" name="report_date" readonly
               value="<?php echo date('Y-m-d'); ?>" required>

        <button type="submit" name="add_sales_record">Add Record</button>
    </form>
</div>




