<?php
    require_once '../config/database.php';
?>

<div class="dashboard">
    <div class="chart-box">
        <h3> Sales Trend (Last 7 Days) </h3>
        <canvas id="line-chart"></canvas>
    </div>

    <div class="chart-box">
        <h3> Quantity Sold by Product (Top 5) </h3>
        <canvas id="pie-chart"></canvas>
    </div>

    <div class="chart-box full-width">
        <h3> Top 3 products by revenue </h3>
        <canvas id="hori-bar-chart"></canvas>
    </div>
</div>


