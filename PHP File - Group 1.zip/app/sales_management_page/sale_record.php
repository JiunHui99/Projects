<?php
    require_once '../config/database.php';

    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $records_per_page = 10;

    if ($page < 1){
        $page = 1;
    }

    $offset = ($page - 1) * $records_per_page;

    $count_query = $pdo->query('SELECT COUNT(*) as total 
                                FROM sales_reports sr
                                JOIN orders o ON o.order_id = sr.order_id
                                JOIN order_details od ON od.order_id = o.order_id
                                JOIN products p ON p.product_id = od.product_id');
    $total_records = $count_query->fetchColumn();
    $total_pages = ceil($total_records / $records_per_page);

    $stmt_db = $pdo->prepare('SELECT sr.sales_report_id,
                                   o.order_id, 
                                   sr.user_id, 
                                   p.product_id, 
                                   p.product_price, 
                                   od.quantity, 
                                   (p.product_price * od.quantity) AS total_sales, 
                                   sr.report_date
                            FROM sales_reports sr
                            JOIN orders o ON o.order_id = sr.order_id
                            JOIN order_details od ON od.order_id = o.order_id
                            JOIN products p ON p.product_id = od.product_id
                            ORDER BY sr.report_date DESC
                            LIMIT :offset, :lim');
    $stmt_db->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt_db->bindValue(':lim', $records_per_page, PDO::PARAM_INT);
    $stmt_db->execute();
?>

<div class="sub-button">
    <button class="sales-rights-button" id="add-record-board" title="Add Sales Record">+</button>
</div>

<div class="content-box">
    <table class="sales-table">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>User ID</th>
                <th>Product ID</th>
                <th>Price Per Unit</th>
                <th>Quantity</th>
                <th>Total Sales</th>
                <th>Report Date</th>
                <th></th>
            </tr>
        </thead>

        <tbody>

            <?php
            if($stmt_db->rowCount() == 0){
                echo '<tr><td colspan="8">No sales records found.</td></tr>';
            } else{

                while($row = $stmt_db->fetch(PDO::FETCH_ASSOC)){ ?>

                <tr>
                    <td><?= htmlspecialchars($row['order_id']) ?></td>
                    <td><?= htmlspecialchars($row['user_id']) ?></td>
                    <td><?= htmlspecialchars($row['product_id']) ?></td>
                    <td>$<?= htmlspecialchars($row['product_price'],2) ?></td>
                    <td><?= htmlspecialchars($row['quantity']) ?></td>
                    <td>$<?= htmlspecialchars($row['total_sales'],2) ?></td>
                    <td><?= htmlspecialchars($row['report_date']) ?></td>
                    <td>
                        <button class="delete-record" data-report-id="<?= htmlspecialchars($row['sales_report_id']) ?>"> 
                            delete
                        </button>
                    </td>
                </tr>

                <?php } ?>

            <?php } ?>
        </tbody>
    </table>
</div>

<div class="paging" id="page-navigation">
    <?php if ($total_pages > 1): ?>

        <?php if ($page > 1): ?>
            <button class="nav-button" onclick="loadSalesPage(<?= $page - 1 ?>)"><< prev</button>
        <?php else: ?>
            <button class="nav-button" disabled><< prev</button>
        <?php endif; ?>

        <?php 
            $max_visible = 5;
            $start_page = max(1, $page - floor($max_visible / 2));
            $end_page = min($total_pages, $start_page + $max_visible - 1);

            if ($end_page - $start_page < $max_visible - 1) {
                $start_page = max(1, $end_page - $max_visible + 1);
            }

            for ($i = $start_page; $i <= $end_page; $i++):
                if ($i === $page): ?>
                    <button class="page-number active" aria-current="page"><?= $i ?></button>
                <?php else: ?>
                    <button class="page-number" onclick="loadSalesPage(<?= $i ?>)"><?= $i ?></button>
                <?php endif;
            endfor; 
        ?>

        <?php if ($page < $total_pages): ?>
            <button class="nav-button" onclick="loadSalesPage(<?= $page + 1 ?>)">next >></button>
        <?php else: ?>
            <button class="nav-button" disabled>next >></button>
        <?php endif; ?>

        <div class="page-info">
            Page <?= $page ?> of <?= $total_pages ?> (<?= $total_records ?> total records)
        </div>

    <?php endif; ?>
</div>



