<?php
    error_reporting(0);
    ini_set('display_errors', 0);

    require_once "../../config/database.php";

    header('Content-Type: application/json');

    try{
        $dataStmt = $pdo->query("SELECT DATE(o.order_date) as sales_date, SUM(sr.total_sales) as daily_sales, COUNT(DISTINCT o.order_id) as order_count 
                                 FROM orders o 
                                 INNER JOIN sales_reports sr ON o.order_id = sr.order_id
                                 WHERE o.order_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                                 GROUP BY DATE(o.order_date)
                                 ORDER BY sales_date");

        $data = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($data)){
            echo json_encode([]);
        }
        else {
            echo json_encode($data);
        }

    } catch (PDOException $e){
        echo json_encode(['error' => $e->getMessage()]);
    }
?>