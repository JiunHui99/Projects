<?php
    error_reporting(0);
    ini_set('display_errors', 0);

    require_once "../../config/database.php";

    header('Content-Type: application/json');

    try{
        $dataStmt = $pdo->query("SELECT p.product_id, SUM(od.quantity) as quantity_sold_product
                                 FROM order_details od
                                 JOIN products p ON od.product_id = p.product_id
                                 GROUP BY p.product_id
                                 ORDER BY quantity_sold_product DESC
                                 LIMIT 5");

        $data = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($data)){
            echo json_encode([]);
        }
        else {
            echo json_encode($data);
        }

    } catch (PDOException $e){
        echo json_encode(['error' => $e->getMessage()]);
    }
?>