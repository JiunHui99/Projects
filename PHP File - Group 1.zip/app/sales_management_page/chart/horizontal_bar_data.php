<?php
    error_reporting(0);
    ini_set('display_errors', 0);

    require_once "../../config/database.php";

    header('Content-Type: application/json');

    try{
        $dataStmt = $pdo->query("SELECT product_id, SUM(total_sales) as revenue
                                 FROM sales_reports
                                 GROUP BY product_id
                                 ORDER BY revenue DESC
                                 LIMIT 3");

        $data = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($data)){
            echo json_encode([]);
        }
        else {
            echo json_encode($data);
        }

    } catch (PDOException $e){
        echo json_encode(['error' => $e->getMessage()]);
    }
?>