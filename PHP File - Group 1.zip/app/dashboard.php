<?php
session_start();

// 只允许 employee / admin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['employee', 'admin'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['username'];
$role = $_SESSION['role'];

include 'sidebar.php';
include '_base.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Dashboard - Inventory System</title>
</head>
<body>

<div class="main-content">

    <!-- User info -->
    <a href="profile.php" class="user-info">
        <img src="https://cdn-icons-png.flaticon.com/512/149/149071.png" alt="User Icon">
        <span><?php echo htmlspecialchars($username); ?></span>
    </a>

    <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>

    <!-- Dashboard Charts (Employee & Admin Only) -->
    <div class="row">
        <div class="chart-box">
            <div id="purchaseStatusChart"></div>
        </div>

        <div class="chart-box">
            <div id="supplierProductChart"></div>
        </div>
    </div>

    <div class="chart-full">
        <div id="deliveryHistoryChart"></div>
    </div>

</div>

<!-- Highcharts CDN -->
<script src="https://code.highcharts.com/highcharts.js"></script>

<script>
// ==================== Chart 1: Purchase Orders By Status ====================
Highcharts.chart('purchaseStatusChart', {
    chart: { type: 'pie' },
    title: { text: 'Purchase Orders By Status' },
    series: [{
        name: 'Orders',
        data: [
            { name: 'Pending', y: 0 },
            { name: 'Complete', y: 0 },
            { name: 'Incomplete', y: 3 }
        ]
    }]
});

// ==================== Chart 2: Product Count Assigned To Supplier ====================
Highcharts.chart('supplierProductChart', {
    chart: { type: 'column' },
    title: { text: 'Product Count Assigned To Supplier' },
    xAxis: { categories: ['Hermès', 'Chanel'] },
    yAxis: { title: { text: 'Product Count' } },
    series: [{
        name: 'Suppliers',
        data: [2, 2],
        colorByPoint: true
    }]
});

// ==================== Chart 3: Delivery History Per Day ====================
Highcharts.chart('deliveryHistoryChart', {
    chart: { type: 'line' },
    title: { text: 'Delivery History Per Day' },
    xAxis: { categories: ['2023-04-26', '2023-04-27', '2023-04-28'] },
    yAxis: { title: { text: 'Products Delivered' } },
    series: [{
        name: 'Product Delivered',
        data: [4, 2, 10]
    }]
});
</script>

<?php include_once '_foot.php'; ?>
</body>
</html>

<style>
.main-content {
    padding: 20px;
}

.user-info {
    position: absolute;
    top: 20px;
    right: 20px;
    display: flex;
    align-items: center;
    background: #fff;
    padding: 5px 10px;
    border-radius: 20px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    cursor: pointer;
    text-decoration: none;
    color: inherit;
}

.user-info img {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    margin-right: 10px;
}

.user-info span {
    font-weight: bold;
}

.row {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 20px;
}

.chart-box {
    width: 48%;
    background: white;
    padding: 15px;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
}

.chart-full {
    width: 100%;
    background: white;
    padding: 15px;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
}

#purchaseStatusChart,
#supplierProductChart,
#deliveryHistoryChart {
    width: 100%;
    height: 350px;
}
</style>
