<?php
include_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$role = $_SESSION['role'] ?? null;

if (!in_array($role, ['employee', 'admin'])) {
    header("Location: index.php");
    exit;
}
?>

<div class="sidebar">
    <h2>INVENTORY SYSTEM</h2>

    <a href="dashboard.php">Dashboard</a>

    <a href="product&inventory_management.php">Product & Inventory Management</a>

    <a href="purchase_management.php">Purchase Management</a>

    <a href="sales_management.php">Sales Management</a>

    <a href="supplier_management.php">Supplier Management</a>

    <?php if ($role === 'admin'): ?>
        <a href="user_management.php">User Management</a>
    <?php endif; ?>

    <a href="logout.php">Logout</a>
</div>

<style>
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100%;
    background: #2c3e50;
    color: #fff;
    padding-top: 20px;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 20px;
    letter-spacing: 1px;
}

.sidebar a {
    display: block;
    color: #fff;
    padding: 12px 20px;
    text-decoration: none;
    margin: 5px 0;
    border-radius: 4px;
    transition: background 0.3s, padding-left 0.3s;
}

.sidebar a:hover {
    background: #34495e;
    padding-left: 30px;
}
</style>