<?php
session_start();
require_once 'config/database.php';

if(!isset($_GET['id']) || trim($_GET['id']) === ''){
    die('Invalid supplier ID.');
}

$supplier_id = $_GET['id'];

$stmt = $pdo->prepare("DELETE FROM suppliers WHERE supplier_id = ?");
if($stmt->execute([$supplier_id])){
    $_SESSION['delete_success'] = 'Supplier deleted successfully.';
    header('Location: supplier_management.php');
    exit;
} else {
    die('Failed to delete supplier.');
}

?>