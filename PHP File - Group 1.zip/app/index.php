<?php
session_start();
require_once 'config/database.php';

$usernameError = '';
$passwordError = '';
$loginError = '';
$registerSuccess = '';

if(isset($_SESSION['register_success'])) {
    $registerSuccess = $_SESSION['register_success'];
    unset($_SESSION['register_success']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username)) {
        $usernameError = "Username cannot be empty!";
    }
    if (empty($password)) {
        $passwordError = "Password cannot be empty!";
    }

    if (empty($usernameError) && empty($passwordError)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role']; // employee/admin
            header("Location: dashboard.php");
            exit;
        } else {
            $loginError = "Invalid username or password!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Inventory System</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; }
        .login-box { width: 300px; margin: 100px auto; padding: 30px; background: #fff; border-radius: 8px; box-shadow: 0 0 10px #aaa; }
        input { width: 100%; padding: 8px; margin: 5px 0; box-sizing: border-box; }
        button { width: 100%; padding: 8px; background: #28a745; color: #fff; border: none; cursor: pointer; }
        .error-msg { color: red; font-size: 0.9em; margin: 2px 0 5px 0; }
        .success-msg { color: green; font-size: 0.9em; margin: 2px 0 5px 0; }
        label { display: block; margin-top: 10px; }
        a { text-decoration: none; color: #007bff; }
    </style>
</head>
<body>
    <div class="login-box">
        <!-- Logo -->
        <img src="images/logo.webp" alt="Inventory System Logo" style="display:block; margin:0 auto 20px auto; width:120px;">

        <h2>Login</h2>

        <?php 
        if($registerSuccess) echo "<p class='success-msg'>$registerSuccess</p>";
        if($loginError) echo "<p class='error-msg'>$loginError</p>";
        ?>

        <form method="POST" action="">
            <label>Username</label>
            <input type="text" name="username" value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>">
            <?php if($usernameError) echo "<div class='error-msg'>$usernameError</div>"; ?>

            <label>Password</label>
            <input type="password" name="password">
            <?php if($passwordError) echo "<div class='error-msg'>$passwordError</div>"; ?>

            <button type="submit">Login</button>
        </form>

        <p style="margin-top:10px;">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>