<?php
session_start();
require_once('config/database.php'); 
include '_base.php';
include 'sidebar.php'; 

if(!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['employee','admin'])){
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];
$msg = "";

$avatar_path = 'uploads/default.png';
if (!is_dir('uploads/')) mkdir('uploads/', 0755, true);

$stmt = $pdo->prepare("SELECT avatar FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
if($user && !empty($user['avatar'])) $avatar_path = 'uploads/' . $user['avatar'];

if(isset($_POST['upload_avatar'])){
    if(isset($_FILES['avatar']) && $_FILES['avatar']['error'] === 0){
        $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
        $allowed = ['jpg','jpeg','png','gif'];
        if(in_array(strtolower($ext), $allowed)){
            $new_name = 'user_'.$user_id.'.'.$ext;
            $destination = 'uploads/'.$new_name;
            if(move_uploaded_file($_FILES['avatar']['tmp_name'], $destination)){
                $pdo->prepare("UPDATE users SET avatar = ? WHERE user_id = ?")->execute([$new_name, $user_id]);
                $avatar_path = $destination;
                $msg = "Profile picture uploaded successfully!";
            } else $msg = "Failed to move uploaded file.";
        } else $msg = "Invalid file type.";
    } else $msg = "No file selected.";
}

if(isset($_POST['change_password'])){
    $old_password = trim($_POST['old_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    if(empty($old_password) || empty($new_password) || empty($confirm_password)){
        $msg = "Password fields cannot be empty.";
    } else {
        $stmt = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $user_pw = $stmt->fetch();
        if($user_pw && password_verify($old_password, $user_pw['password'])){
            if($new_password === $confirm_password){
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?")->execute([$hashed, $user_id]);
                $msg = "Password updated successfully!";
            } else $msg = "New password and confirmation do not match.";
        } else $msg = "Old password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Profile</title>
<style>
.container { max-width:800px; margin:30px auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 3px 10px rgba(0,0,0,0.2); }
.avatar-box { text-align:center; margin-bottom:20px; }
.avatar-box img { width:140px; height:140px; border-radius:10px; object-fit:cover; border:2px solid #007bff; margin: 20px; }
input[type="file"], input[type="password"], input[type="text"] { width:100%; padding:8px 10px; margin-bottom:10px; border-radius:5px; border:1px solid #ccc; }
button { display:inline-block; background-color: #b8f9adff; color: black; font-size: 15px; border:none; border-radius:4px; text-decoration:none; padding: 8px; margin-top:10px; margin: 10px; }
button:hover {  background-color: #7ee183ff; transform: scale(1.1); }
.msg { color:green; margin-top:10px; }
.back-link { display:inline-block; margin-top:10px; color:#007bff; text-decoration:none; }
.back-link:hover { text-decoration:underline; }
.return-btn { background-color: #13688aa5; color: white; padding: 10px; border: none; border-radius: 4px; cursor: pointer;}
.return-btn:hover { background-color: #1565c0; transform: translateY(-2px);}
.container h2,p {text-align: center;}
.header {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    text-align: center;
    margin-bottom: 10px;
    margin-left: auto;
    margin-right: auto;
    max-width: 500px;
}

.header h1 {
    margin: 0;
    font-size: 26px;
    color: #333;
    letter-spacing: 1px;
}
</style>
</head>
<body>
<div class="main-content">
    <a href="dashboard.php">
        <button class="return-btn"><strong>←</strong></button>
    </a>
    <div class="header">
        <h1>User Profile</h1>
    </div>
<div class="container">
    <div class="avatar-box">
        <img src="<?php echo $avatar_path; ?>" alt="Avatar">
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="avatar" accept="image/*" required>
            <button type="submit" name="upload_avatar">Upload Profile Picture</button>
        </form>
    </div>
    
    <h2><?php echo htmlspecialchars($username); ?></h2>
    <p><strong>Role:</strong> <?php echo htmlspecialchars(ucfirst($role)); ?></p>

    <form method="post">
        <h2>______________________________________________</h2>
        <h3>Change Password</h3>
        <input type="password" name="old_password" placeholder="Old Password" required>
        <input type="password" name="new_password" placeholder="New Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
        <button type="submit" name="change_password">Update Password</button>
    </form>

    <?php if($msg): ?>
        <div class="msg"><?php echo $msg; ?></div>
    <?php endif; ?>

</div></div>
<?php include '_foot.php'?>
</body>
</html>