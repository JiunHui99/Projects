<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
    die("Access denied.");
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm  = trim($_POST['confirm_password']);
    $role     = $_POST['role']; 

    if($password !== $confirm){
        $_SESSION['success'] = "Passwords do not match.";
        header("Location: user_management.php");
        exit;
    }

    // Check duplicate username
    $check = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
    $check->execute([$username]);

    if ($check->rowCount() > 0) {
        $_SESSION['success'] = "Username already exists.";
        header("Location: user_management.php");
        exit;
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare(
        "INSERT INTO users (username, password, role) VALUES (?, ?, ?)"
    );
    $stmt->execute([$username, $hashed, $role]);

    $_SESSION['success'] = "New user added successfully!";
    header("Location: user_management.php");
    exit;
}
?>