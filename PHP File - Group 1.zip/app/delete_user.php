<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
    die("Access denied.");
}

if(!isset($_GET['id'])){
    die("Invalid request.");
}

$id = $_GET['id'];

if($id == $_SESSION['user_id']){
    $_SESSION['success'] = "You cannot delete yourself.";
    header("Location: user_management.php");
    exit;
}

try {
    // Start transaction
    $pdo->beginTransaction();
    
    // Temporarily disable foreign key checks
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    
    // Delete from sales_reports
    $stmt = $pdo->prepare("DELETE FROM sales_reports WHERE user_id = ?");
    $stmt->execute([$id]);
    
    // Delete from stock_reports
    $stmt = $pdo->prepare("DELETE FROM stock_reports WHERE user_id = ?");
    $stmt->execute([$id]);
    
    // Delete the user
    $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
    $stmt->execute([$id]);
    
    // Re-enable foreign key checks
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

    if($stmt->rowCount() > 0){
        $pdo->commit();
        $_SESSION['success'] = "User deleted successfully.";
    } else {
        $pdo->rollBack();
        $_SESSION['success'] = "User not found or already deleted.";
    }
    
} catch(PDOException $e) {
    // Re-enable foreign key checks and rollback
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    if($pdo->inTransaction()){
        $pdo->rollBack();
    }
    $_SESSION['success'] = "Failed to delete user: " . $e->getMessage();
}

header("Location: user_management.php");
exit;
?>