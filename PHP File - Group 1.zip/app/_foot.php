<div class="footer">
    <p>&copy; <?php echo date("Y"); ?> Inventory System. All rights reserved.</p>
</div>
<style>
.footer {
    width: 100%;
    background-color: #d7d7d8ff;
    color: black;
    text-align: center;
    padding: 10px 0;
    margin-top: 30px;
}
</style>