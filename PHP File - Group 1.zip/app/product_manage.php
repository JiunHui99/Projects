<?php 
include_once 'config/database.php';
include_once '_base.php';

// update product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $new_product_id = trim($_POST['product_id']);
    $product_name = trim($_POST['product_name']);
    $cat_id = trim($_POST['cat_id']);
    $product_price = trim($_POST['product_price']);
    $supplier_id = trim($_POST['supplier_id']);
    $stock_quantity = trim($_POST['stock_quantity']);
    $old_product_id = $_POST['old_product_id'];
    
    // Validation
    if (empty($new_product_id) || empty($product_name) || empty($cat_id) || 
        empty($product_price) || empty($supplier_id) || empty($stock_quantity)) {
        $error = "All fields are required!";
    } elseif (!is_numeric($product_price) || $product_price < 0) {
        $error = "Product price must be a positive number!";
    } elseif (!is_numeric($stock_quantity) || $stock_quantity < 0) {
        $error = "Stock quantity must be a positive number!";
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE product_id = ? AND product_id != ?");
        $stmt->execute([$new_product_id, $old_product_id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $error = "Error: Product ID already exists!";
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE products SET 
                    product_id = ?, 
                    product_name = ?, 
                    cat_id = ?, 
                    product_price = ?, 
                    supplier_id = ?, 
                    stock_quantity = ? 
                    WHERE product_id = ?");
                
                $stmt->execute([
                    $new_product_id, 
                    $product_name, 
                    $cat_id, 
                    $product_price, 
                    $supplier_id, 
                    $stock_quantity, 
                    $old_product_id
                ]);
                
                header("Location: " . $_SERVER['PHP_SELF'] . "?success=update");
                exit();
            } catch (PDOException $e) {
                $error = "Error updating product: " . $e->getMessage();
            }
        }
    }
}

// add product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $product_id = trim($_POST['product_id']);
    $product_name = trim($_POST['product_name']);
    $cat_id = trim($_POST['cat_id']);
    $product_price = trim($_POST['product_price']);
    $supplier_id = trim($_POST['supplier_id']);
    $stock_quantity = trim($_POST['stock_quantity']);

    // Validation
    if (empty($product_id) || empty($product_name) || empty($cat_id) || 
        empty($product_price) || empty($supplier_id) || empty($stock_quantity)) {
        $error = "All fields are required!";
    } elseif (!is_numeric($product_price) || $product_price < 0) {
        $error = "Product price must be a positive number!";
    } elseif (!is_numeric($stock_quantity) || $stock_quantity < 0) {
        $error = "Stock quantity must be a positive number!";
    } else {
        // Check if product_id already exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            $error = "Product ID already exists! Please use a different Product ID.";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO products (product_id, product_name, cat_id, product_price, supplier_id, stock_quantity) 
                                       VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$product_id, $product_name, $cat_id, $product_price, $supplier_id, $stock_quantity]);

                header("Location: " . $_SERVER['PHP_SELF'] . "?success=add");
                exit();
            } catch (PDOException $e) {
                $error = "Error adding product: " . $e->getMessage();
            }
        }
    }
}

// delete product
if (isset($_GET['delete'])) {
    $product_id = $_GET['delete'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM products WHERE product_id = ?");
        $stmt->execute([$product_id]);
        
        header("Location: " . $_SERVER['PHP_SELF'] . "?success=delete");
        exit();
    } catch (PDOException $e) {
        $error = "Error deleting product: " . $e->getMessage();
    }
}

// Check for success message
if (isset($_GET['success'])) {
    if ($_GET['success'] == 'add') {
        $success = "Product added successfully!";
    } elseif ($_GET['success'] == 'update') {
        $success = "Product updated successfully!";
    } elseif ($_GET['success'] == 'delete') {
        $success = "Product deleted successfully!";
    }
}

// get edit id
$edit_id = $_GET['edit'] ?? null;

?>

<body>

    <?php include 'sidebar.php'; ?>

<div class="main-content">

    <a href="product&inventory_management.php">
        <button class="return-btn"><strong>←</strong></button>
    </a>

    <div class="header">
        <h1>Product Management</h1>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-error">
            ❌ <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success">
            ✓ <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <div class="category-container">    
        <div class="category-list">
        <h2>Product List</h2> 
<?php
$stmt = $pdo->prepare("SELECT * FROM products");
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// get categories
$catStmt = $pdo->prepare("SELECT * FROM category");
$catStmt->execute();
$categories = $catStmt->fetchAll(PDO::FETCH_ASSOC);

// get suppliers
$supStmt = $pdo->prepare("SELECT * FROM suppliers");
$supStmt->execute();
$suppliers = $supStmt->fetchAll(PDO::FETCH_ASSOC);

if (!empty($products)) {
    echo '<table>';
    echo '<tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Product Category</th>
            <th>Product Price</th>
            <th>Product Supplier</th>
            <th>Stock Quantity</th>
            <th>Actions</th>
          </tr>';
    
    foreach ($products as $product) {
        if ($edit_id == $product['product_id']) {
            echo '<tr>';
            echo '<form action="" method="POST">';
            echo '<td><input type="text" name="product_id" value="' . htmlspecialchars($product['product_id']) . '" required style="width: 90%; padding: 5px;"></td>';
            echo '<td><input type="text" name="product_name" value="' . htmlspecialchars($product['product_name']) . '" required style="width: 90%; padding: 5px;"></td>';
            echo '<td><select name="cat_id" required style="width: 95%; padding: 5px;">';

            foreach ($categories as $cat) {
                $selected = ($cat['cat_id'] == $product['cat_id']) ? 'selected' : '';
                echo '<option value="' . htmlspecialchars($cat['cat_id']) . '" ' . $selected . '>'
                        . htmlspecialchars($cat['cat_name']) .
                     '</option>';
            }

            echo '</select></td>';
            echo '<td><input type="number" step="0.01" min="0" name="product_price" value="' . htmlspecialchars($product['product_price']) . '" required style="width: 90%; padding: 5px;"></td>';
            echo '<td><select name="supplier_id" required style="width: 95%; padding: 5px;">';

            foreach ($suppliers as $sup) {
                $selected = ($sup['supplier_id'] == $product['supplier_id']) ? 'selected' : '';
                echo '<option value="' . htmlspecialchars($sup['supplier_id']) . '" ' . $selected . '>'
                        . htmlspecialchars($sup['supplier_name']) .
                     '</option>';
            }

            echo '</select></td>';
            echo '<td><input type="number" min="0" name="stock_quantity" value="' . htmlspecialchars($product['stock_quantity']) . '" required style="width: 90%; padding: 5px;"></td>';
            echo '<td>
                    <input type="hidden" name="old_product_id" value="' . htmlspecialchars($product['product_id']) . '">
                    <button type="submit" name="update" class="btn btn-success">Save</button>
                    <a href="' . $_SERVER['PHP_SELF'] . '">
                        <button type="button" class="btn btn-secondary">Cancel</button>
                    </a>
                  </td>';
            echo '</form>';
            echo '</tr>';
        } else {
            // Get category name
            $catName = '';
            foreach ($categories as $cat) {
                if ($cat['cat_id'] == $product['cat_id']) {
                    $catName = $cat['cat_name'];
                    break;
                }
            }
            
            // Get supplier name
            $supName = '';
            foreach ($suppliers as $sup) {
                if ($sup['supplier_id'] == $product['supplier_id']) {
                    $supName = $sup['supplier_name'];
                    break;
                }
            }
            
            // NORMAL ROW
            echo '<tr>';
            echo '<td>' . htmlspecialchars($product['product_id']) . '</td>';
            echo '<td>' . htmlspecialchars($product['product_name']) . '</td>';
            echo '<td>' . htmlspecialchars($catName) . '</td>';
            echo '<td>RM ' . number_format($product['product_price'], 2) . '</td>';
            echo '<td>' . htmlspecialchars($supName) . '</td>';
            echo '<td>' . htmlspecialchars($product['stock_quantity']) . '</td>';
            echo '<td>
                    <a href="?edit=' . urlencode($product['product_id']) . '">
                        <button class="btn btn-secondary">Edit</button>
                    </a>
                    <a href="?delete=' . urlencode($product['product_id']) . '" onclick="return confirm(\'Are you sure you want to delete this product?\')">
                        <button class="btn btn-danger">Delete</button>
                    </a>
                  </td>';
            echo '</tr>';
        }
    }
    
    echo '</table>';

} else {
    echo '<p style="text-align: center; color: #999; padding: 40px;">No products available</p>';
}
?>

</div>    
        
<div class="add-product">
    <h2>Add New Product</h2>
    <form action="" method="POST">

        <label for="product_id">Product ID: <span class="required">*</span></label><br>
        <input type="text" id="product_id" name="product_id" required 
               placeholder="Enter unique product ID" 
               value="<?= isset($_POST['product_id']) && !empty($error) ? htmlspecialchars($_POST['product_id']) : '' ?>"><br><br>

        <label for="product_name">Product Name: <span class="required">*</span></label><br>
        <input type="text" id="product_name" name="product_name" required
               placeholder="Enter product name"
               value="<?= isset($_POST['product_name']) && !empty($error) ? htmlspecialchars($_POST['product_name']) : '' ?>"><br><br>

        <label for="cat_id">Product Category: <span class="required">*</span></label><br>
        <select id="cat_id" name="cat_id" required>
            <option value="">-- Select Category --</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['cat_id'] ?>" 
                    <?= (isset($_POST['cat_id']) && !empty($error) && $_POST['cat_id'] == $cat['cat_id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat['cat_name']) ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="product_price">Product Price (RM): <span class="required">*</span></label><br>
        <input type="number" step="0.01" min="0" id="product_price" name="product_price" required
               placeholder="0.00"
               value="<?= isset($_POST['product_price']) && !empty($error) ? htmlspecialchars($_POST['product_price']) : '' ?>"><br><br>

        <label for="supplier_id">Product Supplier: <span class="required">*</span></label><br>
        <select id="supplier_id" name="supplier_id" required>
            <option value="">-- Select Supplier --</option>
            <?php foreach ($suppliers as $sup): ?>
                <option value="<?= $sup['supplier_id'] ?>"
                    <?= (isset($_POST['supplier_id']) && !empty($error) && $_POST['supplier_id'] == $sup['supplier_id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($sup['supplier_name']) ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="stock_quantity">Stock Quantity: <span class="required">*</span></label><br>
        <input type="number" min="0" id="stock_quantity" name="stock_quantity" required
               placeholder="0"
               value="<?= isset($_POST['stock_quantity']) && !empty($error) ? htmlspecialchars($_POST['stock_quantity']) : '' ?>"><br><br>

        <input type="submit" name="add" value="Add Product">
    </form>
</div>

</div>
<div class="category-view-container">
<div class="category-view">
    <h2>Category List</h2> 
    <?php
    $catStmt = $pdo->prepare("SELECT * FROM category");
    $catStmt->execute();
    $category = $catStmt->fetchAll(PDO::FETCH_ASSOC);

     if (!empty($category)) {
            echo '<table>';
            echo '<tr>
                    <th>Category ID</th>
                    <th>Category Name</th>
                 </tr>';
            foreach ($category as $cat) {
                echo '<tr>';
                    echo '<td>' . htmlspecialchars($cat['cat_id']) . '</td>';
                    echo '<td>' . htmlspecialchars($cat['cat_name']) . '</td>';
                echo '</tr>';
            }echo '</table>';
        } else {
            echo '<p style="text-align: center; color: #999; padding: 40px;">No categories available</p>';
        } ?>
</div>
<div class="supplier-view">
    <h2>Supplier List</h2>
    <?php
    $supStmt = $pdo->prepare("SELECT * FROM suppliers");
    $supStmt->execute();
    $suppliers = $supStmt->fetchAll(PDO::FETCH_ASSOC);
         if (!empty($suppliers)) {
            echo '<table>';
            echo '<tr>
                    <th>Supplier ID</th>
                    <th>Supplier Name</th>
                 </tr>';
            foreach ($suppliers as $sup) {
                echo '<tr>';
                    echo '<td>' . htmlspecialchars($sup['supplier_id']) . '</td>';
                    echo '<td>' . htmlspecialchars($sup['supplier_name']) . '</td>';
                echo '</tr>';
            }echo '</table>';
        } else {
            echo '<p style="text-align: center; color: #999; padding: 40px;">No categories available</p>';
        } ?>
</div>
</div>
</div>
<?php 
include_once '_foot.php';
?>
</body>
<style>

.main-content {
    margin: 10px;
    font-family: "Segoe UI", Arial, sans-serif;
}

.return-btn {
        background-color: #13688aa5;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
}
.return-btn:hover {
    background-color: #1565c0;
    transform: translateY(-2px);
}

.header {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    text-align: center;
    margin-bottom: 10px;
    margin-left: auto;
    margin-right: auto;
    max-width: 500px;
}

.header h1 {
    margin: 0;
    font-size: 26px;
    color: #333;
    letter-spacing: 1px;
}

.alert {
    padding: 15px;
    margin-bottom: 20px;
    margin-left: auto;
    margin-right: auto;
    max-width: 1400px;
    border-radius: 8px;
    font-weight: bold;
    text-align: center;
}
.alert-error {
    background: #fdecea;
    color: #b71c1c;
    border: 1px solid #f5c6cb;
}
.alert-success {
    background: #e8f5e9;
    color: #1b5e20;
    border: 1px solid #c8e6c9;
}

.category-container {
    display: flex;
    gap: 5px;
    align-items: flex-start;
}
.category-list{
    width:60%;
}
.add-product {
    width:40%;
}
.category-list,
.add-product {
    background: #fff;
    padding: 25px;
    margin: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.12);
    max-height: 500px;
    overflow-y: auto;
}
.category-list h2,
.add-product h2 {
    font-size: 20px;
    margin-bottom: 15px;
    color: #444;
    border-left: 5px solid #2196f3;
    padding-left: 10px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}
th {
    background: #FFE0B2;
    padding: 12px;
    font-weight: 600;
    color: #black;
    border-bottom: 2px solid #bbdefb;
}
td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    font-size: 16px;
}
tr:hover {
    background: #f5faff;
}

form label {
    font-weight: 600;
    font-size: 14px;
    color: #333;
}

.required {
    color: red;
}

form input[type="text"],
form input[type="number"],
form select {
    width: 100%;
    padding: 10px;
    margin: 6px 0 18px 0;
    border: 1px solid #ccc;
    border-radius: 6px;
    background: #fafafa;
    transition: 0.2s;
}

form input:focus,
form select:focus {
    outline: none;
    border-color: #2196f3;
    background: white;
    box-shadow: 0 0 4px rgba(33,150,243,0.4);
}

form input[type="submit"] {
    width: 100%;
    padding: 12px;
    background: #b8f9adff;
    color: black;
    font-size: 16px;
    font-weight: 700;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.2s;
}
form input[type="submit"]:hover {
    background: #7ee783ff;
}

.btn {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    margin: 2px;
}

.btn-secondary {
    background-color: #c8e6ffff;
    color: black;
    font-size: 15px;
}

.btn-secondary:hover {
    background-color: #64b3f8ff;
    transform: translateY(-2px);
}

.btn-danger {
    background-color: #ff948dff;
    color: black;
    font-size: 15px;
}

.btn-danger:hover {
    background-color: #ff5043ff;
    transform: translateY(-2px);
}

.btn-success {
    background-color: #b8f9adff;
    color: black;
    font-size: 15px;
}
.btn-success:hover {
    background-color: #7ee183ff;
    transform: translateY(-2px);
}
.category-view-container{
    padding:20px;
    margin:15px;
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.12);
    display: flex;
    gap: 50px;
    align-items: flex-start;
    justify-content: center; 
}
.category-view,
.supplier-view {
    background: #fafafa;
    padding: 15px 20px;
    border-radius: 10px;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.06);
    width: 45%;
    max-height: 300px; 
    overflow-y: auto;
}
.category-view h2,
.supplier-view h2 {
    font-size: 18px;
    font-weight: 600;
    border-left: 5px solid #2196f3;
    padding-left: 12px;
    margin-bottom: 12px;
}
.category-view::-webkit-scrollbar,
.supplier-view::-webkit-scrollbar,
.add-product::-webkit-scrollbar,
.category-list::-webkit-scrollbar {
    width: 8px;
}
.category-view::-webkit-scrollbar-thumb,
.supplier-view::-webkit-scrollbar-thumb,
.add-product::-webkit-scrollbar-thumb,
.category-list::-webkit-scrollbar-thumb  {
    background: #bdbdbd;
    border-radius: 5px;
}
</style>