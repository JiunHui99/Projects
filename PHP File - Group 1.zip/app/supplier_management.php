<?php
session_start();
require_once 'config/database.php';
include_once '_base.php';

$searchQuery = '';
if(isset($_GET['search'])){
	$searchQuery = trim($_GET['search']);
	$stmt = $pdo->prepare("SELECT supplier_id, supplier_name, supplier_contact, supplier_address FROM suppliers WHERE supplier_id LIKE ? OR supplier_name LIKE ? ORDER BY supplier_name");
	$stmt->execute(["%{$searchQuery}%","%{$searchQuery}%"]);
} else {
	$stmt = $pdo->prepare("SELECT supplier_id, supplier_name, supplier_contact, supplier_address FROM suppliers ORDER BY supplier_name");
	$stmt->execute();
}

$suppliers = $stmt->fetchAll();

$deleteSuccess = '';
if(isset($_SESSION['delete_success'])){
	$deleteSuccess = $_SESSION['delete_success'];
	unset($_SESSION['delete_success']);
}

include 'sidebar.php';
include '_base.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Supplier Management - Inventory System</title>
<style>
.main-content {
    margin: 10px;
    font-family: "Segoe UI", Arial, sans-serif;
}
.return-btn {
        background-color: #13688aa5;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
}
.return-btn:hover {
    background-color: #1565c0;
    transform: translateY(-2px);
}
.container { max-width: 900px; margin: 50px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #aaa; }
h2 { text-align: center; margin-bottom: 20px; }
.table-container{
    max-height: 30vh;
    overflow-y: auto;
}
table { width: 100%;border-collapse: collapse;margin-top: 5px;}
table th, table td {     
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;}
table th {    background-color: #FFE0B2;
    font-weight: 600; }
table tr:hover {
    background-color: #f5f5f5;
}
.btn {
    padding: 8px 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 15px;
    transition: all 0.3s;
	display:inline-block
}
.btn:hover{
	transform: scale(1.1);
}
.button-edit{ display:inline-block; background-color: #c8e6ffff; color: black; font-size: 15px; border-radius:4px; text-decoration:none; }
.button-edit:hover{ background-color: #64b3f8ff;transform: scale(1.1);}

.button-delete {display:inline-block; background-color: #ff948dff; color: black; font-size: 15px; border-radius:4px; text-decoration:none; }
.button-delete:hover {background-color: #ff5043ff; transform: scale(1.1);}

.search-form { margin-bottom:15px; text-align:right; }
.search-form input[type="text"] { padding:5px; width:200px; }
.search-form button { padding:6px; background-color: #f3d8ffff;border: 0px;border-radius: 8px; }
.search-form button:hover{ background-color: #e3b5f7ff;transform: scale(1.1);}

.top-actions { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
.add-supplier{background-color: #b8f9adff;
    color: black;
    font-size: 15px;
	text-decoration: none;
    border: 0px;
    border-radius: 8px;
    padding: 8px;}
.add-supplier:hover{
	background-color: #7ee183ff;
	transform: scale(1.1);
}
.success-msg { background: #e8f5e9;
    color: #1b5e20;
    border: 1px solid #c8e6c9; 
    padding:10px;
    margin:50px; }
</style>
</head>
<body>
<div class="main-content">
    <a href="dashboard.php">
        <button class="return-btn"><strong>←</strong></button>
    </a>
<div class="container">
	<h2>Supplier Management</h2>

	<?php if($deleteSuccess): ?>
		<div class="success-msg"><?php echo htmlspecialchars($deleteSuccess); ?></div>
	<?php endif; ?>

	<div class="top-actions">
		<div>
			<a href="add_supplier.php" class="btn add-supplier">Add Supplier</a>
		</div>

		<form method="GET" class="search-form">
			<input type="text" name="search" placeholder="Search supplier name or ID..." value="<?php echo htmlspecialchars($searchQuery); ?>">
			<button type="submit">Search</button>
		</form>
	</div>

    <div class="table-container"><table>
		<thead>
			<tr>
				<th>ID</th>
				<th>Supplier Name</th>
				<th>Contact</th>
				<th>Address</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php if(count($suppliers) > 0): ?>
				<?php foreach($suppliers as $s): ?>
				<tr>
					<td><?php echo htmlspecialchars($s['supplier_id']); ?></td>
					<td><?php echo htmlspecialchars($s['supplier_name']); ?></td>
					<td><?php echo htmlspecialchars($s['supplier_contact']); ?></td>
					<td><?php echo htmlspecialchars($s['supplier_address']); ?></td>
					<td>
						<a href="edit_supplier.php?id=<?php echo urlencode($s['supplier_id']); ?>" class="btn button-edit">Edit</a>
						<a href="delete_supplier.php?id=<?php echo urlencode($s['supplier_id']); ?>" class="btn button-delete" onclick="return confirm('Are you sure you want to delete this supplier?');">Delete</a>
					</td>
				</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr><td colspan="5">No suppliers found.</td></tr>
			<?php endif; ?>
		</tbody>
	</table></div>
</div></div>
<?php 
include_once '_foot.php';
?>
</body>
</html>