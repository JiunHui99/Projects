<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f4f4;
        margin-left: 250px;
        padding: 10px;
    }
    .body::-webkit-scrollbar{
        width: 8px;
    }
    .body.body::-webkit-scrollbar-thumb{
        background: #bdbdbd;
        border-radius: 5px;
    }
</style>