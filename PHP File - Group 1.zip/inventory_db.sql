-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2025 at 04:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` varchar(20) NOT NULL,
  `cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
('CA001', 'Backpack'),
('CA002', 'CrossBody'),
('CA003', 'Handle Bag'),
('CA004', 'Shoulder Bag'),
('CA005', 'Tote Bag');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` varchar(20) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_contact` int(20) DEFAULT NULL,
  `customer_address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_contact`, `customer_address`) VALUES
('CUST2025120111593060', 'CCC', 1234567890, 'sxdcwdcswedfc'),
('CUST2025121410525715', 'zain', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` varchar(20) NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `order_date` datetime NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `order_date`, `total_price`) VALUES
('O001', 'CUST2025120111593060', '2025-12-09 14:18:03', 29900.00),
('O002', 'CUST2025121410525715', '2025-12-09 12:38:57', 29900.00),
('O003', 'CUST2025120111593060', '2025-12-10 12:41:40', 19900.00),
('O004', 'CUST2025121410525715', '2025-12-10 12:41:40', 13900.00),
('O005', 'CUST2025120111593060', '2025-12-15 12:43:21', 16900.00),
('O006', 'CUST2025121410525715', '2025-12-15 12:43:21', 13900.00),
('O007', 'CUST2025120111593060', '2025-12-15 12:43:21', 29900.00),
('O008', 'CUST2025120111593060', '2025-12-15 12:43:21', 19900.00),
('O009', 'CUST2025121410525715', '2025-12-16 12:43:21', 13900.00),
('O010', 'CUST2025121410525715', '2025-12-17 12:45:29', 19900.00),
('O011', 'CUST2025120111593060', '2025-12-18 12:45:29', 13900.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_detail_id` varchar(20) NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_detail_id`, `order_id`, `product_id`, `quantity`) VALUES
('OD001', 'O001', '1001', 100),
('OD002', 'O002', '1001', 100),
('OD003', 'O003', '1002', 100),
('OD004', 'O004', '1003', 100),
('OD005', 'O005', '1004', 100),
('OD006', 'O006', '1003', 100),
('OD007', 'O007', '1001', 100),
('OD008', 'O008', '1002', 100),
('OD009', 'O009', '1003', 100),
('OD010', 'O010', '1002', 100),
('OD011', 'O011', '1003', 100);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` varchar(20) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` decimal(6,2) NOT NULL,
  `supplier_id` varchar(20) NOT NULL,
  `cat_id` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `stock_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_price`, `supplier_id`, `cat_id`, `image`, `stock_quantity`) VALUES
('1001', 'Alva', 299.00, 'SP001', 'CA002', '/CrossBody/Alva1.webp', 9),
('1002', 'Brennan', 199.00, 'SP002', 'CA002', 'CrossBody/Brennan1.webp', 0),
('1003', 'Pan', 139.00, 'SP002', 'CA002', 'CrossBody/Pan1.webp', 0),
('1004', 'Satin', 169.00, 'SP002', 'CA002', 'CrossBody/Satin1.webp', 16),
('1005', 'Soni', 169.00, 'SP003', 'CA002', 'CrossBody/Soni1.webp', 11),
('1006', 'Caca', 399.00, 'SP005', 'CA002', 'CrossBody/Caca1.png', 20),
('1007', 'Clara', 199.00, 'SP003', 'CA003', 'HandleBag/Clara1.webp', 15),
('1008', 'Enola', 199.00, 'SP004', 'CA003', 'HandleBag/Enola1.webp', 19),
('1009', 'Nano', 299.00, 'SP005', 'CA003', 'HandleBag/Nano1.png', 16),
('1010', 'Krystal', 299.00, 'SP005', 'CA003', 'HandleBag/Krystal1.webp', 30),
('1011', 'Cargo', 199.00, 'SP005', 'CA004', 'ShoulderBag/Cargo1.jpg', 28),
('1012', 'Meridian', 159.00, 'SP001', 'CA004', 'ShoulderBag/Meridian1.webp', 1),
('1013', 'Mini', 159.00, 'SP001', 'CA004', 'ShoulderBag/Mini1.png', 18),
('1014', 'Nancy', 299.00, 'SP002', 'CA004', 'ShoulderBag/Nancy1.webp', 30),
('1015', 'Petra', 299.00, 'SP002', 'CA004', 'ShoulderBag/Petra1.jpg', 35),
('1016', 'Boulogne', 699.00, 'SP001', 'CA003', 'ShoulderBag/Boulogne1.png', 20),
('1017', 'Coco', 299.00, 'SP001', 'CA003', 'ShoulderBag/Coco1.webp', 7),
('1018', 'Casi', 159.00, 'SP003', 'CA005', 'ToteBag/Casi1.webp', 19),
('1019', 'Colla', 199.00, 'SP003', 'CA005', 'ToteBag/Colla1.webp', 13),
('1020', 'Sabine', 299.00, 'SP004', 'CA005', 'ToteBag/Sabine1.jpg', 18),
('1021', 'Young', 139.00, 'SP004', 'CA005', 'ToteBag/Young1.webp', 12),
('1022', 'Ong', 399.00, 'SP001', 'CA005', 'ToteBag/Ong1.png', 20),
('1023', 'Balida', 59.00, 'SP001', 'CA001', 'Backpack/Balida1.jpg', 5),
('1024', 'Buffy', 199.00, 'SP002', 'CA001', 'Backpack/Buffy1.WEBP', 13),
('1025', 'Hazel', 139.00, 'SP002', 'CA001', 'Backpack/Hazel1.webp', 15),
('1026', 'Siro', 169.00, 'SP003', 'CA001', 'Backpack/Siro1.jpg', 25);

-- --------------------------------------------------------

--
-- Table structure for table `sales_reports`
--

CREATE TABLE `sales_reports` (
  `sales_report_id` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `report_date` datetime NOT NULL,
  `total_sales` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_reports`
--

INSERT INTO `sales_reports` (`sales_report_id`, `user_id`, `order_id`, `product_id`, `report_date`, `total_sales`) VALUES
('SR0001', 1, 'O001', '1001', '2025-12-18 05:33:13', 29900.00),
('SR0003', 4, 'O003', '1002', '2025-12-18 05:58:22', 19900.00),
('SR0004', 5, 'O004', '1003', '2025-12-18 05:58:35', 13900.00),
('SR0005', 1, 'O005', '1004', '2025-12-18 05:58:49', 16900.00),
('SR0006', 5, 'O006', '1003', '2025-12-18 05:59:04', 13900.00),
('SR0007', 5, 'O007', '1001', '2025-12-18 15:26:46', 29900.00),
('SR0008', 4, 'O008', '1002', '2025-12-18 15:27:37', 19900.00),
('SR0009', 1, 'O009', '1003', '2025-12-18 15:27:48', 13900.00),
('SR0010', 5, 'O010', '1002', '2025-12-22 18:56:02', 19900.00),
('SR0011', 1, 'O011', '1003', '2025-12-22 18:56:15', 13900.00),
('SR0012', 1, 'O002', '1001', '2025-12-23 12:16:01', 29900.00);

-- --------------------------------------------------------

--
-- Table structure for table `stock_order`
--

CREATE TABLE `stock_order` (
  `stock_order_id` varchar(20) NOT NULL,
  `supplier_id` varchar(20) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_ordered` datetime NOT NULL,
  `date_received` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_reports`
--

CREATE TABLE `stock_reports` (
  `stock_report_id` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `report_date` datetime NOT NULL,
  `current_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` varchar(20) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `supplier_contact` varchar(100) NOT NULL,
  `supplier_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `supplier_name`, `supplier_contact`, `supplier_address`) VALUES
('SP001', 'A Company', '011-2233445', 'Jln A street a'),
('SP002', 'B Company', '012-3344556', 'Jln B street b'),
('SP003', 'C Company', '013-4455667', 'Jln C street c'),
('SP004', 'D Company', '014-5566778', 'Jln D street d'),
('SP005', 'E Company', '015-6677889', 'Jln E street e');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','employee') NOT NULL,
  `avatar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`, `avatar`) VALUES
(1, 'admin', '$2y$10$HfX0PfwcMxOgJ5Pb2/c9lO6q6F7Z5XxCw7HBtOa3vKQvpfu5xAe3S', 'admin', NULL),
(4, 'John', '$2y$10$ZKYgAsYw3JG8WG1pubLMduedbI9c681lXuXKgxHanS4h0xImgEeve', 'employee', 'user_4.jpg'),
(5, 'KKK', '$2y$10$GDmWX/0gzzHdmtzgPRrCa./.T9rTTFBY2O.V.nC.apBREnJbLW3F2', 'admin', 'user_5.jpg'),
(10, 'a', '$2y$10$mVNDn2ZU7nVxlTc8/z1rCOZ808x8ilp/.WDDXQdt3x8MZpEtxKY.a', 'employee', 'user_10.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_detail_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `sales_reports`
--
ALTER TABLE `sales_reports`
  ADD PRIMARY KEY (`sales_report_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `sales_reports_ibfk_1` (`user_id`),
  ADD KEY `sales_reports_ibfk_3` (`product_id`);

--
-- Indexes for table `stock_order`
--
ALTER TABLE `stock_order`
  ADD PRIMARY KEY (`stock_order_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `stock_reports`
--
ALTER TABLE `stock_reports`
  ADD PRIMARY KEY (`stock_report_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`cat_id`) REFERENCES `category` (`cat_id`);

--
-- Constraints for table `sales_reports`
--
ALTER TABLE `sales_reports`
  ADD CONSTRAINT `sales_reports_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `sales_reports_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `sales_reports_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `stock_order`
--
ALTER TABLE `stock_order`
  ADD CONSTRAINT `stock_order_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`),
  ADD CONSTRAINT `stock_order_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `stock_reports`
--
ALTER TABLE `stock_reports`
  ADD CONSTRAINT `stock_reports_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `stock_reports_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
