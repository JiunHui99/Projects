package BorrowManagementModule;

import java.time.LocalDate;

public class Borrow {
    private String borrowId;
    private String userId;
    private String bookId;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private boolean returned;

    public Borrow() {
        this("", "", "", LocalDate.now(), LocalDate.now(), LocalDate.now(), false);
    }

    public Borrow(String borrowId, String userId, String bookId, LocalDate borrowDate, LocalDate dueDate,
            LocalDate returnDate, boolean returned) {
        this.borrowId = borrowId;
        this.userId = userId;
        this.bookId = bookId;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.returned = returned;
    }

    // GETTER
    public String getBorrowId() {
        return borrowId;
    }

    public String getUserId() {
        return userId;
    }

    public String getBookId() {
        return bookId;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public boolean isReturned() {
        return returned;
    }

    // SETTER
    public void setBorrowId(String borrowId) {
        this.borrowId = borrowId;
    }

    public void setUserId(String userId) {
        if (userId == null || userId.trim().isEmpty()) {
            throw new IllegalArgumentException("User ID cannot be empty!");
        }
        this.userId = userId;
    }

    public void setBookId(String bookId) {
        if (bookId == null || bookId.trim().isEmpty()) {
            throw new IllegalArgumentException("Book ID cannot be empty!");
        }
        this.bookId = bookId;
    }

    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public void setReturned(boolean returned) {
        this.returned = returned;
    }

    @Override
    public String toString() {
        return String.format("%-12s %-12s %-12s %-20s %-20s %-20s %-10s",
            borrowId,
            userId,
            bookId,
            borrowDate.toString(),
            dueDate.toString(),
            (returnDate != null ? returnDate.toString() : "Not Returned"),
            returned ? "Yes" : "No"
        );
    }
}