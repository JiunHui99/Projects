package BorrowManagementModule;

import BookManagementModule.Book;
import BookManagementModule.bookController;
import UserManagementModule.memberController;
import java.sql.*;
import java.time.LocalDate;
import java.util.Scanner;

public class borrowController {

    private Connection connection;
    private Scanner input;

    final static String url = "jdbc:mysql://localhost:3306/library";
    final static String username = "root";
    final static String password = "";

    public borrowController() {
        try {
            this.connection = DriverManager.getConnection(url, username, password);
            this.input = new Scanner(System.in);
        } catch (SQLException e) {
            System.out.println("(!) Database connection failed: " + e.getMessage());
        }
    }

    public void borrowSession() {
        int choice;

        do {
            displayBorrowMenu();

            while (!input.hasNextInt()) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Invalid input! Please enter a number between 1 and 5.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                input.next();
                displayBorrowMenu();
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1:
                    bookController bookController = new bookController();
                    bookController.readBook();
                    clear();
                    break;

                case 2:
                    clear();
                    borrowBook();
                    break;

                case 3:
                    clear();
                    checkDueDate();
                    break;

                case 4:
                    clear();
                    returnBook();
                    break;

                case 5:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Returned to previous menu...");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                default:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Invalid choice! Please enter a number between 1 and 5.\n");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }

        } while (choice != 5);
    }



    public void borrowBook() {
        showAvailableBooks();

        System.out.print("\nPress 'ENTER' to continue...");
        input.nextLine();

        String userId = memberController.loggedInMember.getUserId();
        int borrowLimit = memberController.loggedInMember.getBorrowLimit();

        if (hasReachedBorrowLimit(userId, borrowLimit)) {
            System.out.println("(!) You have reached your borrowing limit. Please return a book first.\n");
            return;
        }

        String bookId;

        do {
            System.out.print("Enter the Book ID you want to borrow [Press 0 to cancel] > ");
            bookId = input.nextLine().trim();

            if (bookId.equals("0")) {
                clear();
                System.out.println("Returning to previous menu...\n");
                return;
            }

            if (!isBookAvailable(bookId)) {
                System.out.println("(!) Invalid Book ID or the book is not available. Please try again.\n");

            } else {
                break;
            }
        } while (true);

        processBorrowing(userId, bookId);
    }

    public void showAvailableBooks() {
        System.out.println("                                                  =======================================");
        System.out.println("                                                 |                                       | ");
        System.out.println("                                                 | ==  A v a i l a b l e   B o o k s  == |");
        System.out.println("                                                 |                                       | ");
        System.out.println("                                                  =======================================");
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-10s %-50s %-30s %-20s %-10s %-5s%n", "Book ID", "Book Title", "Author", "Genre", "Year",
                "Availability");
        System.out.println(
                "-----------------------------------------------------------------------------------------------------------------------------------------");

        String query = "SELECT * FROM book WHERE availability = true";
        try (PreparedStatement pstmt = connection.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {

            boolean booksFound = false;

            while (rs.next()) {
                booksFound = true;

                Book book = new Book(
                        rs.getString("book_id"),
                        rs.getString("book_title"),
                        rs.getString("author"),
                        rs.getString("genre"),
                        rs.getInt("publicationYear"),
                        rs.getBoolean("availability"));
                System.out.println(book);
            }

            if (!booksFound) {
                System.out.println("                                                  (!) No available books to borrow.");
                return;
            }

        } catch (SQLException e) {
            System.out.println("(!) Error: Failde to fetch available books: " + e.getMessage());
        }
    }

    private boolean hasReachedBorrowLimit(String userId, int limit) {
        String query = "SELECT COUNT(*) AS borrow_count FROM borrowing WHERE user_id = ? AND returned = false";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("borrow_count") >= limit;
            }
        } catch (SQLException e) {
            System.out.println("(!) Error checking borrow limit: " + e.getMessage());
        }
        return false;
    }

    private boolean isBookAvailable(String bookId) {
        String query = "SELECT * FROM book WHERE book_id = ? AND availability = true";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, bookId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println("(!) Error: Failed to check the book availability: " + e.getMessage());
            return false;
        }
    }

    private void processBorrowing(String userId, String bookId) {
        String borrowId = generateBorrowId();
        LocalDate borrowDate = LocalDate.now();
        LocalDate dueDate = borrowDate.plusWeeks(2);

        String insertQuery = "INSERT INTO borrowing (borrow_id, user_id, book_id, borrow_date, due_date, returned) VALUES (?, ?, ?, ?, ?, false)";
        String updateQuery = "UPDATE book SET availability = false WHERE book_id = ?";

        try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery);
             PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {

            insertStmt.setString(1, borrowId);
            insertStmt.setString(2, userId);
            insertStmt.setString(3, bookId);
            insertStmt.setDate(4, Date.valueOf(borrowDate));
            insertStmt.setDate(5, Date.valueOf(dueDate));
            insertStmt.executeUpdate();

            updateStmt.setString(1, bookId);
            updateStmt.executeUpdate();

            clear();
            System.out.println("                                               ======================================================");
            System.out.println("                                          Book borrowed successfully! Please return it before the due date.");
            System.out.println("                                               ======================================================");

        } catch (SQLException e) {
            System.out.println("(!) Error: Failed to process borrowing: " + e.getMessage());
        }
    }



    public void checkDueDate() {
        String userId = memberController.loggedInMember.getUserId();

        System.out.println("                                                ===========================================");
        System.out.println("                                               |                                           | ");
        System.out.println("                                               | ==  Your Borrowed Books and Due Dates  == |");
        System.out.println("                                               |                                           | ");
        System.out.println("                                                ===========================================");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-15s %-10s %-50s %-15s %-15s %-15s %-10s%n","Borrow ID", "Book ID", "Title", "Borrow Date", "Due Date", "Days Left", "Status");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------");

        String query = "SELECT br.borrow_id, b.book_id, b.book_title, br.borrow_date, br.due_date " +
                "FROM borrowing br JOIN book b ON br.book_id = b.book_id " +
                "WHERE br.user_id = ? AND br.returned = false";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, userId);
            ResultSet rs = pstmt.executeQuery();

            boolean borrowsFound = false;

            while (rs.next()) {
                borrowsFound = true;

                String borrowId = rs.getString("borrow_id");
                String bookId = rs.getString("book_id");
                String title = rs.getString("book_title");
                LocalDate borrowDate = rs.getDate("borrow_date").toLocalDate();
                LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                LocalDate today = LocalDate.now();
                long daysLeft = java.time.temporal.ChronoUnit.DAYS.between(today, dueDate);

                String status = daysLeft < 0 ? "Overdue" : "On Time";

                System.out.printf("%-15s %-10s %-50s %-15s %-15s %-15s %-10s%n",
                        borrowId, bookId, title, borrowDate, dueDate, daysLeft, status);
            }

            if (!borrowsFound) {
                System.out.println("                                                    (!) You have no active borrowed books.");
            }

            System.out.print("\nPress 'ENTER' to continue...");
            input.nextLine();
            clear();

        } catch (SQLException e) {
            System.out.println("(!) Error: Failed to check due dates: " + e.getMessage());
        }
    }



    public void returnBook() {
        String userId = memberController.loggedInMember.getUserId();

        System.out.println("                                 ================================================");
        System.out.println("                                |                                                | ");
        System.out.println("                                | ==  Your Borrowed Books (Not Yet Returned)  == |");
        System.out.println("                                |                                                | ");
        System.out.println("                                 ================================================");
        System.out.println("------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-10s %-50s %-30s %-15s %-15s%n", "Book ID", "Title", "Author", "Borrow Date", "Due Date");
        System.out.println("------------------------------------------------------------------------------------------------------------------------");

        String query = "SELECT b.book_id, b.book_title, b.author, br.borrow_date, br.due_date " +
                "FROM borrowing br JOIN book b ON br.book_id = b.book_id " +
                "WHERE br.user_id = ? AND br.returned = false";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, userId);
            ResultSet rs = pstmt.executeQuery();

            boolean borrowsFound = false;
            while (rs.next()) {

                borrowsFound = true;
                System.out.printf("%-10s %-50s %-30s %-15s %-15s%n",
                        rs.getString("book_id"),
                        rs.getString("book_title"),
                        rs.getString("author"),
                        rs.getDate("borrow_date"),
                        rs.getDate("due_date"));
            }

            if (!borrowsFound) {
                System.out.println("                                                      (!) You have no books to return.");
                return;
            }

            String bookId;

            do {
                System.out.print("\nEnter the Book ID you want to return [Press 0 to cancel] > ");
                bookId = input.nextLine().trim();

                if (bookId.equals("0")) {
                    clear();
                    System.out.println("Returning to previous menu...\n");
                    return;
                }

                String checkQuery = "SELECT * FROM borrowing WHERE user_id = ? AND book_id = ? AND returned = false";
                try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
                    checkStmt.setString(1, userId);
                    checkStmt.setString(2, bookId);
                    ResultSet checkRs = checkStmt.executeQuery();

                    if (checkRs.next()) {
                        break;
                    } else {
                        System.out.println("(!) Invalid Book ID or the book is already returned.");
                    }
                }

            } while (true);

            String updateBorrowing = "UPDATE borrowing SET returned = true, return_date = ? WHERE user_id = ? AND book_id = ? AND returned = false";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateBorrowing)) {
                updateStmt.setDate(1, Date.valueOf(LocalDate.now()));
                updateStmt.setString(2, userId);
                updateStmt.setString(3, bookId);
                updateStmt.executeUpdate();
            }

            String updateBook = "UPDATE book SET availability = true WHERE book_id = ?";
            try (PreparedStatement updateBookStmt = connection.prepareStatement(updateBook)) {
                updateBookStmt.setString(1, bookId);
                updateBookStmt.executeUpdate();
            }

            clear();
            System.out.println("                                               ======================================================");
            System.out.println("                                              Book returned successfully. Thanks for your cooperation!");
            System.out.println("                                               ======================================================");

        } catch (SQLException e) {
            System.out.println("(!) Error: Failed when returning book: " + e.getMessage());
        }
    }



    // STAFF FUNCTION
    public void viewRecords() {
        System.out.println("                          ====================================");
        System.out.println("                         |                                    | ");
        System.out.println("                         | ==  B O R R O W  R E C O R D S  == |");
        System.out.println("                         |                                    | ");
        System.out.println("                          ====================================");
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.printf("%-12s %-12s %-12s %-15s %-15s %-15s %-10s%n",
                "Borrow ID", "User ID", "Book ID", "Borrow Date", "Due Date", "Return Date", "Returned");
        System.out.println("-----------------------------------------------------------------------------------------------");

        String query = "SELECT * FROM borrowing";

        try (PreparedStatement pstmt = connection.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {

            boolean recordsFound = false;

            while (rs.next()) {
                recordsFound = true;
                String borrowId = rs.getString("borrow_id");
                String userId = rs.getString("user_id");
                String bookId = rs.getString("book_id");
                LocalDate borrowDate = rs.getDate("borrow_date").toLocalDate();
                LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                LocalDate returnDate = null;
                if (rs.getDate("return_date") != null) {
                    returnDate = rs.getDate("return_date").toLocalDate();
                }
                boolean returned = rs.getBoolean("returned");

                System.out.printf("%-12s %-12s %-12s %-15s %-15s %-15s %-10s%n",
                        borrowId, userId, bookId, borrowDate, dueDate,
                        (returnDate != null ? returnDate.toString() : "-"),
                        (returned ? "Yes" : "No"));
            }

            if (!recordsFound) {
                System.out.println("                            (!) No borrow records found.");
            }

            System.out.print("\nPress 'ENTER' to continue...");
            input.nextLine();
            clear();

        } catch (SQLException e) {
            System.out.println("(!) Error viewing borrow records: " + e.getMessage());
        }
    }


    
    private String generateBorrowId() {
        String nextId = "BR001";
        String query = "SELECT borrow_id FROM borrowing ORDER BY borrow_id DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                String lastId = rs.getString("borrow_id");
                int num = Integer.parseInt(lastId.substring(2));
                num++;
                nextId = String.format("BR%03d", num);
            }

        } catch (SQLException e) {
            System.out.println("(!) Error: Failed to generate new borrow ID " + e.getMessage());
        }

        return nextId;
    }
    
    public void displayBorrowMenu() {
        System.out.println(" ");
        System.out.println("                                                          ---------------------------");
        System.out.println("                                                          --  T A S K   M E N U -- ");
        System.out.println("                                                          ---------------------------");
        System.out.println(" ");
        System.out.println("                                                     ------------------------------------");
        System.out.println("                                                    |        [1] Browse Books            |");
        System.out.println("                                                    |        [2] Borrow Books            |");
        System.out.println("                                                    |        [3] Check Due Dates         |");
        System.out.println("                                                    |        [4] Return Books            |");
        System.out.println("                                                    |        [5] Return to member menu   |");
        System.out.println("                                                     ------------------------------------");
        System.out.println(" ");
        System.out.print("                                                            Enter your choice [1-5] > ");
    }

    public void clear() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}