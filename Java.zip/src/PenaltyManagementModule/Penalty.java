package PenaltyManagementModule;

import java.time.LocalDate;

public class Penalty {
    private String penaltyId;
    private String borrowId;
    private String userId;
    private double penaltyAmount;
    private LocalDate penaltyDate;
    private String status;
    private static double totalUnpaidAmount = 0.0;

    public Penalty() {
        this("", "", "", 0.0, LocalDate.now(), "" );
    }

    public Penalty(String penaltyId, String borrowId, String userId, double penaltyAmount, LocalDate penaltyDate, String status) {
        this.penaltyId = penaltyId;
        this.borrowId = borrowId;
        this.userId = userId;
        this.penaltyAmount = penaltyAmount;
        this.penaltyDate = penaltyDate;
        this.status = status;
    }

    // GETTER
    public String getPenaltyId() {
        return penaltyId;
    }

    public String getBorrowId() {
        return borrowId;
    }

    public String getUserId() {
        return userId;
    }

    public double getPenaltyAmount() {
        return penaltyAmount;
    }

    public LocalDate getPenaltyDate() {
        return penaltyDate;
    }

    public String getStatus() {
        return status;
    }

    public static double getTotalUnpaidAmount() {
        return totalUnpaidAmount;
    }

    // SETTER
    public void setPenaltyId(String penaltyId) {
        this.penaltyId = penaltyId;
    }

    public void setBorrowId(String borrowId) {
        this.borrowId = borrowId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setPenaltyAmount(double penaltyAmount) {
        this.penaltyAmount = penaltyAmount;
    }

    public void setPenaltyDate(LocalDate penaltyDate) {
        this.penaltyDate = penaltyDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    

    public static void addTotalUnpaidAmount(double totalUnpaidAmount) {
        Penalty.totalUnpaidAmount += totalUnpaidAmount;
    }

    public static void resetTotalUnpaidAmount() {
        totalUnpaidAmount = 0.0;
    }

    @Override
    public String toString() {
        return String.format("%-12s %-12s %-12s %-25.2f %-20s %-10s", penaltyId, borrowId, userId, penaltyAmount, penaltyDate.toString(), status);
    }
    
}
