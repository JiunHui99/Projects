package PenaltyManagementModule;

import BorrowManagementModule.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class penaltyController {

    private Connection connection;
    private Scanner input;

    final static String url = "jdbc:mysql://localhost:3306/library";
    final static String username = "root";
    final static String password = "";

    public penaltyController() {
        try {
            this.connection = DriverManager.getConnection(url, username, password);
            this.input = new Scanner(System.in);
        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("(!) Database connection failed: " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }
    }

    public void viewPenalty(String userId) {

        try {
            System.out.println("                               =======================================");
            System.out.println("                              |                                       | ");
            System.out.println("                              | ==  P E N A L T Y   R E C O R D S  == |");
            System.out.println("                              |                                       | ");
            System.out.println("                               =======================================");
            System.out.println("--------------------------------------------------------------------------------------------");
            System.out.printf("%-12s %-12s %-12s %-25s %-20s %-10s%n", "Penalty ID", "Borrow ID", "User ID", "Penalty Amount(RM)", "Penalty Date", "Status");
            System.out.println("--------------------------------------------------------------------------------------------");

            String query = "SELECT * FROM penalty WHERE user_id = ?";

            boolean hasUnpaidPenalty = false;

            try (PreparedStatement pstmt = connection.prepareStatement(query)) {
                pstmt.setString(1, userId);
                ResultSet rs = pstmt.executeQuery();

                boolean hasPenalties = false;
                Penalty.resetTotalUnpaidAmount();

                while (rs.next()) {
                    hasPenalties = true;

                    Penalty penalty = new Penalty();
                    penalty.setPenaltyId(rs.getString("penalty_id"));
                    penalty.setBorrowId(rs.getString("borrow_id"));
                    penalty.setUserId(rs.getString("user_id"));
                    penalty.setPenaltyAmount(rs.getDouble("penalty_amount"));
                    penalty.setPenaltyDate(rs.getDate("penalty_date").toLocalDate());
                    penalty.setStatus(rs.getString("status"));

                    if (penalty.getStatus().equalsIgnoreCase("Unpaid")) {
                        Penalty.addTotalUnpaidAmount(penalty.getPenaltyAmount());
                        hasUnpaidPenalty = true;
                    }

                    System.out.println(penalty.toString());
                }

                if (!hasPenalties) {
                    System.out.println("                                Hooray! You have no penalty records.");

                    System.out.print("\nPress 'ENTER' to continue...");
                    input.nextLine();
                    clear();
                    return;
                }

                // Show total unpaid amount
                System.out.printf("\n                                Total Unpaid Penalty Amount: RM%-9.2f%n\n", Penalty.getTotalUnpaidAmount());

                // If has unpaid penalty, ask user to pay
                if (hasUnpaidPenalty) {
                    String choice;

                    do {
                        System.out.print("\nDo you want to pay your unpaid penalties now? [Y/N] > ");
                        choice = input.nextLine().trim().toUpperCase();

                        if (choice.equals("Y")) {
                            clear();
                            payPenalty(userId);
                            break;

                        } else if (choice.equals("N")) {
                            clear();
                            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                            System.out.println("  Returned to previous menu...");
                            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                            break;

                        } else {
                            System.out.println("(!) Invalid choice! Please enter 'Y' or 'N'.");
                        }

                    } while (true);

                } else {
                    System.out.println("All your penalties are already paid!");

                    System.out.print("\nPress 'ENTER' to continue...");
                    input.nextLine();
                    clear();
                }
            }

        } catch (SQLException e) {
            System.out.println("(!) Error processing penalty: " + e.getMessage());
        }
    }


    
    public void payPenalty(String userId) {
        try {
            String query = "SELECT * FROM penalty WHERE user_id = ? AND status = 'Unpaid'";

            List<String> unpaidPenaltyIds = new ArrayList<>();

            try (PreparedStatement pstmt = connection.prepareStatement(query)) {
                pstmt.setString(1, userId);
                ResultSet rs = pstmt.executeQuery();

                boolean hasUnpaid = false;
                System.out.println("                      =======================================");
                System.out.println("                     |                                       | ");
                System.out.println("                     | ==      Your Unpaid Penalties      == |");
                System.out.println("                     |                                       | ");
                System.out.println("                      =======================================");
                System.out.println("--------------------------------------------------------------------------------------------");
                System.out.printf("%-12s %-12s %-12s %-25s %-20s %-10s%n","Penalty ID", "Borrow ID", "User ID", "Penalty Amount(RM)", "Penalty Date", "Status");
                System.out.println("--------------------------------------------------------------------------------------------");

                while (rs.next()) {
                    hasUnpaid = true;

                    String penaltyId = rs.getString("penalty_id");
                    String borrowId = rs.getString("borrow_id");
                    double amount = rs.getDouble("penalty_amount");
                    LocalDate penaltyDate = rs.getDate("penalty_date").toLocalDate();

                    unpaidPenaltyIds.add(penaltyId);

                    System.out.printf("%-12s %-12s %-12s %-25.2f %-20s %-10s%n",
                            penaltyId, borrowId, userId, amount, penaltyDate, "Unpaid");
                }

                if (!hasUnpaid) {
                    System.out.println("You have no unpaid penalties.");
                    System.out.print("\nPress 'ENTER' to continue...");
                    input.nextLine();
                    return;
                }

                String payChoice;

                do {
                    System.out.print("\nEnter Penalty ID to pay [Press 0 to cancel or 'ALL' to pay all] > ");
                    payChoice = input.nextLine().trim().toUpperCase();

                    if (payChoice.equals("0")) {
                        clear();
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Payment cancelled. Returning to previous menu..");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        break;
                    }

                    if (payChoice.equals("ALL")) {
                        for (String penaltyId : unpaidPenaltyIds) {
                            String updateQuery = "UPDATE penalty SET status = 'Paid' WHERE penalty_id = ?";
                            try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                                updateStmt.setString(1, penaltyId);
                                updateStmt.executeUpdate();
                            }
                        }
                        clear();
                        System.out.println("                                               ======================================================");
                        System.out.println("                                                      All penalties have been paid. Thank you!");
                        System.out.println("                                               ======================================================");
                        break;

                    } else if (unpaidPenaltyIds.contains(payChoice)) {
                        String updateQuery = "UPDATE penalty SET status = 'Paid' WHERE penalty_id = ?";
                        try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                            updateStmt.setString(1, payChoice);
                            updateStmt.executeUpdate();
                        }
                        clear();
                        System.out.println("                                        ======================================================");
                        System.out.println("                                            Penalty " + payChoice + " has been paid successfully. Thank you!");
                        System.out.println("                                        ======================================================");
                        break;

                    } else {
                        System.out.println("(!) Invalid Penalty ID. Please try again.");
                    }

                } while (true);

            }

        } catch (SQLException e) {
            System.out.println("(!) Error: Failed while paying penalties: " + e.getMessage());
        }
    }



    // STAFF FUNCTION
    public void applyPenalty() {

        String query = "SELECT * FROM borrowing WHERE " +
               "((return_date IS NOT NULL AND return_date > due_date) " +
               "OR (return_date IS NULL AND due_date < CURDATE())) " +
               "AND borrow_id NOT IN (SELECT borrow_id FROM penalty)";
        LocalDate today = LocalDate.now();
        int appliedCount = 0;
    
        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
    
            System.out.println("                             ===============================================");
            System.out.println("                            |                                               | ");
            System.out.println("                            | ==  O V E R D U E  B O O K  R E C O R D S  == |");
            System.out.println("                            |                                               | ");
            System.out.println("                             ===============================================");
            System.out.println("---------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-12s %-12s %-12s %-20s %-20s %-20s %-10s\n","Borrow ID", "User ID", "Book ID", "Borrow Date", "Due Date", "Return Date", "Returned");
            System.out.println("---------------------------------------------------------------------------------------------------------------");
    
            List<Borrow> overdueBorrows = new ArrayList<>();
            boolean hasRecord = false;
    
            while (rs.next()) {
                hasRecord = true;
                Borrow borrow = new Borrow(
                        rs.getString("borrow_id"),
                        rs.getString("user_id"),
                        rs.getString("book_id"),
                        rs.getDate("borrow_date").toLocalDate(),
                        rs.getDate("due_date").toLocalDate(),
                        rs.getDate("return_date") != null ? rs.getDate("return_date").toLocalDate() : null,
                        rs.getBoolean("returned")
                );
                overdueBorrows.add(borrow);
                System.out.println(borrow);
            }
    
            if (!hasRecord) {
                System.out.println("                                    No overdue records found.\n");

                System.out.print("Press 'ENTER' to continue...");
                input.nextLine();
                clear();

                return;
            }
    
            String choice;
            do {
                System.out.print("\nApply penalties for ALL overdue records? [Y/N] > ");
                choice = input.nextLine().trim().toUpperCase();

                if (choice.equals("Y")) {

                    for (Borrow borrow : overdueBorrows) {
                        String borrowId = borrow.getBorrowId();
                        String userId = borrow.getUserId();
                        double penaltyAmount = 20.00;
                        String penaltyId = generatePenaltyId();

                    String checkQuery = "SELECT * FROM penalty WHERE borrow_id = ?";
                    try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
                        checkStmt.setString(1, borrowId);
                        ResultSet checkRs = checkStmt.executeQuery();

                        if (checkRs.next()) {
                            continue;
                        }
                    }

                    String insertQuery = "INSERT INTO penalty (penalty_id, borrow_id, user_id, penalty_amount, penalty_date, status) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                        insertStmt.setString(1, penaltyId);
                        insertStmt.setString(2, borrowId);
                        insertStmt.setString(3, userId);
                        insertStmt.setDouble(4, penaltyAmount);
                        insertStmt.setDate(5, Date.valueOf(today));
                        insertStmt.setString(6, "Unpaid");
    
                        insertStmt.executeUpdate();
                        appliedCount++;
                    }
                    }

                    clear();
                    System.out.println("                                               ======================================================");
                    System.out.println("                                                  Successfully applied " + appliedCount + " penalties.");
                    System.out.println("                                               ======================================================");
                    break;

                } else if (choice.equals("N")) {
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(" (!) Penalty application cancelled.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                } else {
                    System.out.println("(!) Invalid choice! Please choose 'Y' or 'N'.");
                }

            } while (true);
    
        } catch (SQLException e) {
            System.out.println("(!) Error: Fail to retrieve borrow records: " + e.getMessage());
        }
    }



    private String generatePenaltyId() {

        String nextId = "P001";
        String query = "SELECT penalty_id FROM penalty ORDER BY penalty_id DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                String lastId = rs.getString("penalty_id");
                int num = Integer.parseInt(lastId.substring(1));
                num++;
                nextId = String.format("P%03d", num);
            }

        } catch (SQLException e) {
            System.out.println("(!) Error: Failed to generate new penalty ID " + e.getMessage());
        }
        return nextId;
    }

    public void clear() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

}
