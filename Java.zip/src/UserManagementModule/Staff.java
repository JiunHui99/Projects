package UserManagementModule;

public class Staff extends User {
    private String role;

    public Staff() {
        this("", "", "", "", "");
    }

    public Staff(String userId, String name, String phoneNumber, String password, String role) {
        super(userId, name, phoneNumber, password);
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    @Override
    public void showMenu() {
        System.out.println(" ");
        System.out.println("                                                           -------------------------");
        System.out.println("                                                          --  S T A F F   M E N U -- ");
        System.out.println("                                                           -------------------------");
        System.out.println(" ");
        System.out.println("                                                         ------------------------------");
        System.out.println("                                                       |      [1] Book Management       |");
        System.out.println("                                                       |      [2] Track Borrow Records  |");
        System.out.println("                                                       |      [3] Apply Penalties       |");
        System.out.println("                                                       |      [4] View Staff            |");
        System.out.println("                                                       |      [5] Search Member         |");
        System.out.println("                                                       |      [6] Remove Member         |");
        System.out.println("                                                       |      [7] Logout                |");
        System.out.println("                                                         ------------------------------");
        System.out.print("                                                             Enter your choice [1-7] > ");
    }
    

    public String toString() {
        String getMaskedPassword = new String(new char[password.length()]).replace("\0", "*"); 

        return String.format("%-10s %-30s %-20s %-20s %-10s", 
            getUserId(), 
            getName(), 
            getPhoneNumber(), 
            getMaskedPassword, 
            getRole()
        );
    }
}
