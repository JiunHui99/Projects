package UserManagementModule;

import BorrowManagementModule.borrowController;
import PenaltyManagementModule.penaltyController;
import java.sql.*;
import java.util.Scanner;

public class memberController {

    private Connection connection;
    private Scanner input;
    private Member member;
    public static Member loggedInMember;

    final static String url = "jdbc:mysql://localhost:3306/library";
    final static String username = "root";
    final static String password = "";

    public memberController() {
        try {
            this.connection = DriverManager.getConnection(url, username, password);
            this.input = new Scanner(System.in);
        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Database connection failed: " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        }
    }

    public void memberAccessMenu() {
        int choice;

        do {
            displayAccessMenu();

            while (!input.hasNextInt()) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Invalid input! Please enter a number between 1 and 3.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                input.next();
                displayAccessMenu();
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Register Session Selected!");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

                    memberRegister();
                    break;

                case 2:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Login Session Selected!");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    memberLogin();
                    break;

                case 3:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Successfully Returned to Main Menu..");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                default:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Invalid choice! Please enter a number between [1-3].");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            }

        } while (choice != 3);
    }



    public void memberRegister() {

        boolean valid;
        boolean repeat = true;

        while (repeat) {
            clear();
            Member newMember = new Member();
            System.out.println(" ");
            System.out.println("                                                          ------------------------------------------------");
            System.out.println("                                                         |                                                | ");
            System.out.println("                                                         | --  M E M B E R    R E G I S T R A T I O N  -- |");
            System.out.println("                                                         |                                                | ");
            System.out.println("                                                          ------------------------------------------------");
            System.out.println(" ");

            // === User ID (Auto Generated) ===
            newMember.setUserId(generateMemberId());

            // === User Name ===
            do {
                valid = true;
                try {
                    System.out.print("                                                           Enter Your Name [Press 0 to cancel] > ");
                    String name = input.nextLine();

                    if (name.equals("0")) {
                        clear();
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Returned to previous menu...");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

                        return;
                    }

                    newMember.setName(name);

                } catch (IllegalArgumentException e) {
                    System.out.println("                                                           Error: " + e.getMessage());
                    valid = false;
                }
            } while (!valid);

            // === Phone Number ===
            do {
                valid = true;
                try {
                    System.out.print("                                                           Enter Your Phone Number [e.g +60 11-22223333] > +60 ");
                    newMember.setPhoneNumber(input.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("                                                           Error: " + e.getMessage());
                    valid = false;
                }
            } while (!valid);

            // === Password ===
            do {
                valid = true;
                try {
                    System.out.print("                                                           Enter Your Password > ");
                    newMember.setPassword(input.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("                                                           Error: " + e.getMessage());
                    valid = false;
                }
            } while (!valid);

            // === Role ===
            do {
                valid = true;
                try {
                    System.out.print("                                                           Choose Your Role [Student/Faculty] > ");
                    newMember.setRole(input.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("                                                           Error: " + e.getMessage());
                    valid = false;
                }
            } while (!valid);

            String query = "INSERT INTO user (user_id, user_name, phoneNumber, password, role) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(query)) {

                pstmt.setString(1, newMember.getUserId());
                pstmt.setString(2, newMember.getName());
                pstmt.setString(3, newMember.getPhoneNumber());
                pstmt.setString(4, newMember.getPassword());
                pstmt.setString(5, newMember.getRole());

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Registration successful!");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(" ");
                    System.out.println("                                                                                                                                                                          ");
                    System.out.println("                                                            W e l c o m e  '" + newMember.getName() + "',  Y o u r   M e m b e r   I D   i s: " + newMember.getUserId());
                    System.out.println("                                                                                                                                                                          ");
                } else {
                    System.out.println("                                                         Error: Unable to register member. Please try again.\n");
                }

                // LOOP
                String choice;
                do {
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.print("                                                           Do you want to register more accounts? [Y/N]: ");
                    choice = input.nextLine().trim().toUpperCase();

                    if (choice.equals("Y")) {
                        break;

                    } else if (choice.equals("N")) {
                        repeat = false;
                        clear();
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Returned to previous menu..");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

                        break;

                    } else {
                        System.out.println("                                                           Invalid input! Please enter 'Y' or 'N'.\n");
                    }

                } while (true);

            } catch (SQLException e) {
                System.out.println("                                                           Error: Failed to register member " + e.getMessage());
            }
        }
    }



    public void memberLogin() {
        int attempts = 1;

        while (attempts <= 3) {
            System.out.println(" ");
            System.out.println("                                                          ----------------------------------");
            System.out.println("                                                         |                                  | ");
            System.out.println("                                                         | --  M E M B E R    L O G I N  -- |");
            System.out.println("                                                         |                                  | ");
            System.out.println("                                                          ----------------------------------");
            System.out.println(" ");
            System.out.println("                                                         --------- Member Login ---------- " + " attempts " + attempts);
            System.out.println(" ");
            System.out.print("                                                          Enter member ID [e.g M000] > ");
            String memberId = input.nextLine().trim().toUpperCase();

            System.out.print("                                                          Enter Password [e.g abc123] > ");
            String password = input.nextLine().trim();

            try {
                String query = "SELECT * FROM user WHERE user_id = ? AND password = ?";
                PreparedStatement stmt = connection.prepareStatement(query);

                stmt.setString(1, memberId);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    member = new Member(
                            rs.getString("user_id"),
                            rs.getString("user_name"),
                            rs.getString("phoneNumber"),
                            rs.getString("password"),
                            rs.getString("role"));

                    loggedInMember = member;

                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Login successful. Welcome, " + member.getName());
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    rs.close();
                    memberMenu();
                    return;

                } else {
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(" Invalid member ID or password! Please Try Again.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    attempts++;
                }

            } catch (SQLException e) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Login error: " + e.getMessage());
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                return;
            }
        }
        clear();
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("  Too many failed attempts. Returned to the main menu..");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }



    public void memberMenu() {
        int choice;

        do {
            member.showMenu();

            while (!input.hasNextInt()) {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Invalid input! Please enter a number between [1-4].");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                input.next();
                member.showMenu();
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1:
                    clear();
                    viewProfile();
                    break;

                case 2:
                    clear();
                    borrowController borrowController = new borrowController();
                    borrowController.borrowSession();
                    break;

                case 3:
                    clear();
                    penaltyController penaltyController = new penaltyController();
                    String userId = memberController.loggedInMember.getUserId();
                    penaltyController.viewPenalty(userId);
                    break;

                case 4:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Successfully Logged out Account..");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                default:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Invalid choice! Please enter a number between [1-4].");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }

        } while (choice != 4);
    }



    public void viewProfile() {

        System.out.println(" ");
        System.out.println("                                                        ------------------------------------------");
        System.out.println("                                                      -- Y O U R   C U R R E N T   P R O F I L E --");
        System.out.println("                                                        ------------------------------------------");
        System.out.println(" ");
        System.out.println(member.toString());

        // LOOP
        String choice;
        do {
            System.out.println("----------------------------------------------------------------------------------------------------------------------");
            System.out.print("                                                      Would you like to update your profile? [Y/N] > ");
            choice = input.nextLine().trim().toUpperCase();

            if (choice.equals("Y")) {
                clear();
                updateProfile();
                break;

            } else if (choice.equals("N")) {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Returned to previous menu..");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                break;

            } else {

                System.out.println("   Invalid choice! Please enter 'Y' or 'N'.\n");
            }

        } while (true);
    }



    public void updateProfile() {
        System.out.println(" ");
        System.out.println("                                                            ------------------------------");
        System.out.println("                                                          --- U P D A T E   P R O F I L E ---");
        System.out.println("                                                            ------------------------------");
        System.out.println(" ");
        System.out.print("                                                         Enter new Name [leave blank to keep] > ");
        String newName = input.nextLine().trim();
        if (newName.isEmpty()) {
            newName = member.getName();
        }

        System.out.print("                                                         Enter new Phone Number [leave blank to keep] > +60 ");
        String newPhoneNumber = input.nextLine().trim();
        if (newPhoneNumber.isEmpty()) {
            newPhoneNumber = member.getPhoneNumber();
        }

        System.out.print("                                                         Enter new Password [leave blank to keep] > ");
        String newPassword = input.nextLine().trim();
        if (newPassword.isEmpty()) {
            newPassword = member.getPassword();
        }

        String query = "UPDATE user SET user_name = ?, phoneNumber = ?, password = ? WHERE user_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newName);
            pstmt.setString(2, newPhoneNumber);
            pstmt.setString(3, newPassword);
            pstmt.setString(4, member.getUserId());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                member.setName(newName);
                member.setPhoneNumber(newPhoneNumber);
                member.setPassword(newPassword);

                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println(" Profile updated successfully!");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            } else {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Error: Unable to update profile. Please try again.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            }

        } catch (SQLException e) {
            clear();
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Error: Failed to update profile " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        }
    }



    // STAFF FUNCTION
    public void removeMember() {

        System.out.println(" ");
        System.out.println("                                                            ------------------------------");
        System.out.println("                                                          --- R E M O V E   M E M B E R ---");
        System.out.println("                                                            ------------------------------");
        System.out.println(" ");

        String memberId;
        do {
            System.out.print("                                                         Enter Member ID [Press 0 to cancel] > ");
            memberId = input.nextLine().trim();

            if (memberId.equals("0")) {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Returned to previous menu...");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                return;
            }

            if (!memberId.matches("M\\d{3}")) {
                System.out.println("                                                         Invalid Member ID format! [e.g: M000].\n");
            } else {
                break;
            }

        } while (true);

        String selectQuery = "SELECT * FROM user WHERE user_id = ?";
        String deleteQuery = "DELETE FROM user WHERE user_id = ?";

        try (PreparedStatement selectStmt = connection.prepareStatement(selectQuery);
                PreparedStatement deleteStmt = connection.prepareStatement(deleteQuery)) {

            selectStmt.setString(1, memberId);
            ResultSet rs = selectStmt.executeQuery();

            if (!rs.next()) {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Member with ID '" + memberId + "' not found.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

                return;
            }

            String id = rs.getString("user_id");
            String name = rs.getString("user_name");
            String phoneNumber = rs.getString("phoneNumber");
            String password = rs.getString("password");
            String role = rs.getString("role");

            Member member = new Member(id, name, phoneNumber, password, role);

            clear();
            System.out.println(" ");
            System.out.println("                                                            -------------------------------");
            System.out.println("                                                          --- M E M B E R   D E T A I L S ---");
            System.out.println("                                                            -------------------------------");
            System.out.println(" ");
            System.out.println(member.toString());

            String reply;
            do {
                System.out.print("                                                           Remove this member? [Y/N] > ");
                reply = input.nextLine().trim().toUpperCase();

                if (reply.equals("Y")) {
                    deleteStmt.setString(1, memberId);
                    int rowsAffected = deleteStmt.executeUpdate();

                    if (rowsAffected > 0) {
                        clear();
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("   Member with ID '" + memberId + "' has been successfully removed.");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

                    } else {
                        clear();
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Failed to remove this member.");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    }
                    break;
                
                } else if (reply.equals("N")){
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Member removal cancelled.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                } else {
                    System.out.println("                                                         Invalid choice! Please enter 'Y' or 'N'.\n");
                }

            } while (true);

        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Error: Unable to remove this member. " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }
    }


    
    private String generateMemberId() {

        String nextId = "M001";

        String query = "SELECT user_id FROM user ORDER BY user_id DESC LIMIT 1";

        try (
                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                String lastId = rs.getString("user_id");
                int num = Integer.parseInt(lastId.substring(1));
                num++;
                nextId = String.format("M%03d", num);
            }

        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("   Error: Failed to generate new user ID " + e.getMessage());
        }

        return nextId;
    }
    public void displayAccessMenu() {
        System.out.println(" ");
        System.out.println("                                                        ----------------------------");
        System.out.println("                                                      -- M E M B E R   S E S S I O N --");
        System.out.println("                                                        ----------------------------");
        System.out.println(" ");
        System.out.println("                                                     -----------------------------------");
        System.out.println("                                                    |       [1] Register Account        |");
        System.out.println("                                                    |       [2] Login Account           |");
        System.out.println("                                                    |       [3] Return to Main Page     |");
        System.out.println("                                                     -----------------------------------");
        System.out.println(" ");
        System.out.print("                                                          Enter your choice [1-3] > ");
    }
    

    public void clear() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

}