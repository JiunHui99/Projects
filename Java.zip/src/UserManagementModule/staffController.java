package UserManagementModule;

import BookManagementModule.bookController;
import BorrowManagementModule.borrowController;
import PenaltyManagementModule.penaltyController;
import java.sql.*;
import java.util.Scanner;

public class staffController {

    private Connection connection;
    private Scanner input;
    private Staff staff;

    final static String url = "jdbc:mysql://localhost:3306/library";
    final static String username = "root";
    final static String password = "";

    public staffController() {
        try {
            this.connection = DriverManager.getConnection(url, username, password);
            this.input = new Scanner(System.in);
        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Database connection failed: " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }
    }

    public void staffAccessMenu() {
        int choice;

        do {
            displayAccessMenu();

            while (!input.hasNextInt()) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("Invalid input! Please enter a number between 1 and 2.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                input.next();
                displayAccessMenu();
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Login Session Selected");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    staffLogin();
                    break;

                case 2:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Returned to Main Menu...");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                default:
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Invalid choice! Please enter a number between [1-2].");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }

        } while (choice != 2);
    }

    public void staffLogin() {
        int attempts = 1;

        while (attempts <= 3) {
            System.out.println(" ");
            System.out.println("                                                          -------------------------------");
            System.out.println("                                                         |                               | ");
            System.out.println("                                                         | --  S T A F F   L O G I N  -- |");
            System.out.println("                                                         |                               | ");
            System.out.println("                                                          -------------------------------");
            System.out.println(" ");
            System.out.println("                                                         --------- Staff Login ---------- " + " attempts " + attempts);
            System.out.println(" ");
            System.out.print("                                                          Enter staff ID [e.g S000] > ");
            String staffId = input.nextLine().trim().toUpperCase();

            System.out.print("                                                          Enter Password [e.g abc123] > ");
            String password = input.nextLine().trim();

            try {
                String query = "SELECT * FROM staff WHERE staff_id = ? AND password = ?";
                PreparedStatement stmt = connection.prepareStatement(query);
                stmt.setString(1, staffId);
                stmt.setString(2, password);

                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    staff = new Staff(
                            rs.getString("staff_id"),
                            rs.getString("staff_name"),
                            rs.getString("phoneNumber"),
                            rs.getString("password"),
                            rs.getString("role"));

                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("   Login successful! Welcome, " + staff.getName() + "!");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    staffMenu();
                    return;

                } else {
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(" Invalid staff ID or password.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    attempts++;
                }

            } catch (SQLException e) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("   Login error: " + e.getMessage());
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                return;
            }
        }
        clear();
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("  Too many failed attempts. Returned to the main menu.");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    }

    public void staffMenu() {
        int choice;

        do {
            staff.showMenu();

            while (!input.hasNextInt()) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Invalid input! Please enter a number between 1 and 5.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                input.next();
                staff.showMenu();
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1:
                    bookController bookController = new bookController();
                    bookController.bookSession();
                    break;

                case 2:
                    clear();
                    borrowController borrowController = new borrowController();
                    borrowController.viewRecords();
                    break;

                case 3:
                    clear();
                    penaltyController penaltyController = new penaltyController();
                    penaltyController.applyPenalty();
                    break;

                case 4:
                    clear();
                    viewAllStaff();
                    break;

                case 5:
                    clear();
                    searchProfile();
                    break;

                case 6:
                    clear();
                    memberController memberController = new memberController();
                    memberController.removeMember();
                    break;

                case 7:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Successfully Logged Out Account...");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                default:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("Invalid choice! Please enter a number between [1-6].");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }

        } while (choice != 7);
    }

    public void viewAllStaff() {
        System.out.println(" ");
        System.out.println("   ----------------------");
        System.out.println(" -- S T A F F   L I S T --");
        System.out.println("   ----------------------");
        System.out.println(" ");
        System.out.printf("%-10s %-30s %-20s %-20s %-10s\n", "Staff ID", "Name", "Phone", "Password", "Role");
        System.out.println("------------------------------------------------------------------------------------------");

        String query = "SELECT * FROM staff";
        try (PreparedStatement stmt = connection.prepareStatement(query);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Staff staff = new Staff(
                        rs.getString("staff_id"),
                        rs.getString("staff_name"),
                        rs.getString("phoneNumber"),
                        rs.getString("password"),
                        rs.getString("role"));
                System.out.println(staff);
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving staff: " + e.getMessage());
        }

        System.out.print("\nPress 'ENTER' to continue...");
        input.nextLine();
        clear();
    }

    public void searchProfile() {

        System.out.println(" ");
        System.out.println("                                                        -----------------------------");
        System.out.println("                                                      -- S E A R C H   P R O F I L E --");
        System.out.println("                                                        -----------------------------");
        System.out.println(" ");
        System.out.print("                                                       Enter Member ID to search [e.g M000] > ");
        String memberId = input.nextLine().trim();
        Member member = null;

        String query = "SELECT * FROM user WHERE user_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, memberId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                member = new Member();
                member.setUserId(rs.getString("user_id"));
                member.setName(rs.getString("user_name"));
                member.setPhoneNumber(rs.getString("phoneNumber"));
                member.setPassword(rs.getString("password"));
                member.setRole(rs.getString("role"));
            }

            if (member == null) {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("   Member ID not found.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                return;
            }

            System.out.println(" ");
            System.out.println("                                                        -----------------------------");
            System.out.println("                                                      -- M E M B E R   P R O F I L E --");
            System.out.println("                                                        -----------------------------");
            System.out.println(" ");
            System.out.println(member.toString());

            // UPDATE
            String reply;

            do {
                System.out.print("                                                      Update Member Profile? [Y/N] > ");
                reply = input.nextLine().trim().toUpperCase();

                if (reply.equals("Y")) {
                    clear();
                    updateProfile(member);
                    break;

                } else if (reply.equals("N")) {
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Returned to previous menu...");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                } else {
                    System.out.println("                                                      Invalid choice! Please enter 'Y' or 'N'.\n");
                }

            } while (true);

        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("   Error: Failed to retrieve user profile" + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }

    }

    private void updateProfile(Member member) {

        System.out.println(" ");
        System.out.println("                                                        -----------------------------");
        System.out.println("                                                      -- U P D A T E   P R O F I L E --");
        System.out.println("                                                        -----------------------------");
        System.out.println(" ");

        System.out.print("                                                           Name [" + member.getName() + "](Must be 5 character long)> ");
        String newName = input.nextLine().trim();
        if (newName.isEmpty())
            newName = member.getName();

        System.out.print("                                                           Phone Number [+60 " + member.getPhoneNumber() + "] > +60 ");
        String newPhoneNumber = input.nextLine().trim();
        if (newPhoneNumber.isEmpty())
            newPhoneNumber = member.getPhoneNumber();

        String maskedPassword = "*".repeat(member.getPassword().length());

        System.out.print("                                                           Password [" + maskedPassword + "] > ");
        String newPassword = input.nextLine().trim();
        if (newPassword.isEmpty())
            newPassword = member.getPassword();

        String query = "UPDATE user SET user_name = ?, phoneNumber = ?, password = ? WHERE user_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(4, member.getUserId());
            pstmt.setString(1, newName);
            pstmt.setString(2, newPhoneNumber);
            pstmt.setString(3, newPassword);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                member.setName(newName);
                member.setPhoneNumber(newPhoneNumber);
                member.setPassword(newPassword);

                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Profile updated successfully!");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            } else {

                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Error: Unable to update profile. Please try again.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }

        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Error: Failed to update profile " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }
    }



    public void displayAccessMenu() {
        System.out.println(" ");
        System.out.println("                                                        ----------------------------");
        System.out.println("                                                      -- S T A F F   S E S S I O N --");
        System.out.println("                                                        ----------------------------");
        System.out.println(" ");
        System.out.println("                                                     -----------------------------------");
        System.out.println("                                                    |                                   |");
        System.out.println("                                                    |      [1] Login Account            |");
        System.out.println("                                                    |      [2] Return to Main Page      |");
        System.out.println("                                                    |                                   |");
        System.out.println("                                                     -----------------------------------");
        System.out.println(" ");
        System.out.print("                                                           Enter your choice [1-2] > ");
    }

    public void clear() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}
