package UserManagementModule;

public abstract class User {
    protected String userId;
    protected String name;
    protected String phoneNumber;
    protected String password;
    protected String role;

    public User() {
        this("", "", "", "");
    }

    // Parameter Constructor
    public User(String userId, String name, String phoneNumber, String password) {
        this.userId = userId;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.password = password;
    }

    // GETTER
    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getPassword() {
        return password;
    }
    
    // SETTER
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty!\n");
        }

        if (!name.matches("[a-zA-Z ]+")) {
            throw new IllegalArgumentException("Name can only contain alphabet!\n");
        }

        if (name.length() < 5) {
            throw new IllegalArgumentException("Name must be at least 5 characters long!\n");
        }

        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Phone number cannot be empty!\n");
        }

        if (!phoneNumber.matches("[\\d\\s\\-+]+")) {
            throw new IllegalArgumentException("Phone number can only contain digits, hyphens and plus sign!\n");
        }

        if (phoneNumber.length() < 11 || phoneNumber.length() > 13) {
            throw new IllegalArgumentException("Phone number must be between 11 and 13 digits long!\n");
        }
        
        this.phoneNumber = phoneNumber;
    }

    public void setPassword(String password) {
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty!\n");
        }

        if (password.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters long!\n");
        }

        if (!password.matches(".*[A-Z].*")) {
            throw new IllegalArgumentException("Password must contain at least one uppercase letter!\n");
        }

        if (!password.matches(".*[a-z].*")) {
            throw new IllegalArgumentException("Password must contain at least one lowercase letter!\n");
        }

        if (!password.matches(".*\\d.*")) {
            throw new IllegalArgumentException("Password must contain at least one digit!\n");
        }

        if (!password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
            throw new IllegalArgumentException("Password must contain at least one special character!\n");
        }

        this.password = password;
    }

    public abstract void showMenu();

}


