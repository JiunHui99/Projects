package UserManagementModule;

public class Member extends User {
    private String role;

    public Member() {
        this("", "", "", "", "");
    }
    public Member(String userId, String name, String phoneNumber, String password, String role) {
        super(userId, name, phoneNumber, password);
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    public int getBorrowLimit() {
        return role.equalsIgnoreCase("Faculty") ? 5 : 3;
    }

    public void setRole(String role) {
        String roleTrimmed = role.trim().toLowerCase();

        if (role == null || role.trim().isEmpty()) {
            throw new IllegalArgumentException("Role cannot be empty!\n");
        }

        if (!roleTrimmed.equals("student") && !roleTrimmed.equals("faculty")) {
            throw new IllegalArgumentException("Role must be either 'Student' or 'Faculty'!\n");
        }

        this.role = roleTrimmed.substring(0, 1).toUpperCase() + roleTrimmed.substring(1);
    }

    @Override
    public void showMenu() {
        System.out.println(" ");
        System.out.println("                                                          ----------------------------");
        System.out.println("                                                          --  M E M B E R   M E N U -- ");
        System.out.println("                                                          ----------------------------");
        System.out.println(" ");
        System.out.println("                                                        --------------------------------- ");
        System.out.println("                                                       |      [1] Profile Settings       |");
        System.out.println("                                                       |      [2] Borrowing & Returns    |");
        System.out.println("                                                       |      [3] Penalty Information    |");
        System.out.println("                                                       |      [4] Logout                 |");
        System.out.println("                                                        --------------------------------- ");
        System.out.println(" ");
        System.out.print("                                                             Enter your choice [1-4] > ");
    }

    public String toString() {
        String maskedPassword = new String(new char[password.length()]).replace("\0", "*");

        return  "                                                     ---------------------------------------------\n" +
                "                                                           Member ID      : " + userId + "\n" +
                "                                                           Name           : " + name + "\n" +
                "                                                           Phone Number   : +60 " + phoneNumber + "\n" +
                "                                                           Password       : " + maskedPassword + "\n" +
                "                                                           Role           : " + role + "\n" +
                "                                                     ---------------------------------------------";
    }

}
