package BookManagementModule;

import java.sql.*;
import java.util.Scanner;

public class bookController {

    private Connection connection;
    private Scanner input;

    final static String url = "jdbc:mysql://localhost:3306/library";
    final static String username = "root";
    final static String password = "";

    public bookController() {
        try {
            this.connection = DriverManager.getConnection(url, username, password);
            this.input = new Scanner(System.in);
        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Database connection failed: " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }
    }

    public void bookSession() {
        int choice;

        clear();

        do {
            displayBookMenu();

            while (!input.hasNextInt()) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Invalid input! Please enter a number between 1 and 5.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                input.next();
                displayBookMenu();
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1:
                    createBook();
                    break;

                case 2:
                    readBook();
                    clear();
                    break;

                case 3:
                    updateBook();
                    break;

                case 4:
                    deleteBook();
                    break;

                case 5:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Returned to previous menu...");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;

                default:
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Invalid choice! Please enter a number between 1 and 5.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }

        } while (choice != 5);
    }



    public void createBook() {

        boolean valid;
        boolean repeat = true;

        while (repeat) {
            clear();
            Book newBook = new Book();
            System.out.println(" ");
            System.out.println("                                                       ------------------------------");
            System.out.println("                                                      |                              | ");
            System.out.println("                                                      | --  B O O K  C R E A T E  -- |");
            System.out.println("                                                      |                              | ");
            System.out.println("                                                       ------------------------------");
            System.out.println(" ");

            // === Book ID (Auto Generated) ===
            newBook.setBookId(generateBookId());

            // === Book Title ===
            do {
                valid = true;
                try {
                    System.out.print("                                                 Enter Book Title [Press 0 to cancel] > ");
                    String choice = input.nextLine();

                    if (choice.equals("0")) {
                        clear();
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Returned to previous menu...");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        return;
                    }

                    newBook.setBookTitle(choice);

                } catch (IllegalArgumentException e) {
                    System.out.println("                                                 Error: " + e.getMessage());
                    valid = false;
                }
            } while (!valid);

            // === Book Author ===
            do {
                valid = true;
                try {
                    System.out.print("                                                 Enter Book Author > ");
                    newBook.setAuthor(input.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("                                                 Error: " + e.getMessage());
                    valid = false;
                }
            } while (!valid);

            // === Book Genre ===
            do {
                valid = true;
                try {
                    System.out.print("                                                 Enter Book Genre > ");
                    newBook.setGenre(input.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("                                                 Error: " + e.getMessage());
                    valid = false;
                }
            } while (!valid);

            // === Book Year ===
            do {
                valid = true;
                try {
                    System.out.print("                                                 Enter Publication Year > ");
                    String yearInput = input.nextLine();
                    newBook.setPublicationYear(yearInput);
                } catch (IllegalArgumentException e) {
                    System.out.println("                                                 Error: " + e.getMessage());
                    valid = false;
                }
            } while (!valid);

            // === Book Availability (Default) ===
            newBook.setAvailability(true);

            String query = "INSERT INTO book (book_id, book_title, author, genre, publicationYear, availability) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(query)) {

                pstmt.setString(1, newBook.getBookId());
                pstmt.setString(2, newBook.getBookTitle());
                pstmt.setString(3, newBook.getAuthor());
                pstmt.setString(4, newBook.getGenre());
                pstmt.setInt(5, newBook.getPublicationYear());
                pstmt.setBoolean(6, newBook.isAvailable());

                pstmt.executeUpdate();

                // OUTPUT
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("                                                 Book '" + newBook.getBookTitle() + "' added successfully! (Book ID: "
                        + newBook.getBookId() + ")");
                // LOOP
                String choice;
                do {
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.print("                                                 Do you want to add more books? (Y/N) > ");
                    choice = input.nextLine().trim().toUpperCase();

                    if (choice.equals("Y")) {
                        break;

                    } else if (choice.equals("N")) {
                        repeat = false;
                        clear();
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Returned to previous menu...");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        break;

                    } else {
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Invalid input! Please enter 'Y' or 'N'.\n");
                    }

                } while (true);

            } catch (SQLException e) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Error: Failed to create book " + e.getMessage());
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }
        }
    }



    public void readBook() {

        clear();
        System.out.println(" ");
        System.out.println("                                                       --------------------------------");
        System.out.println("                                                      |                                | ");
        System.out.println("                                                      | --  B O O K  S E C T I O N  -- |");
        System.out.println("                                                      |                                | ");
        System.out.println("                                                       --------------------------------");
        System.out.println(" ");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-10s %-50s %-30s %-20s %-10s %-5s%n ", "Book ID", "Book Title", "Author", "Genre", "Year","Availability");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");

        String query = "SELECT * FROM book";
        try (PreparedStatement pstmt = connection.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {

            boolean booksFound = false;

            // OUTPUT : Has Record
            while (rs.next()) {
                booksFound = true;

                Book book = new Book(
                        rs.getString("book_id"),
                        rs.getString("book_title"),
                        rs.getString("author"),
                        rs.getString("genre"),
                        rs.getInt("publicationYear"),
                        rs.getBoolean("availability"));

                System.out.println(book);
            }

            // OUTPUT : No Record
            if (!booksFound) {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  No books found in the library.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.print("\nPress 'ENTER' to continue...");
            input.nextLine();

        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("\nError: Failed to retrieve books! " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        }
    }



    public void updateBook() {

        clear();
        readBook();

        System.out.println("                                                           --------------------------");
        System.out.println("                                                          --- U P D A T E   B O O K S ---");
        System.out.println("                                                           --------------------------");

        String bookId;

        do {
            System.out.print("                                                Enter the Book ID to update [Press 0 to cancel] > ");
            bookId = input.nextLine();

            if (bookId.equals("0")) {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Returned to previous menu...");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                return;
            }

            if (bookId.isEmpty()) {
                System.out.println("                                                You must enter a book ID!\n");
            }

        } while (bookId.isEmpty());

        String selectQuery = "SELECT * FROM book WHERE book_id = ?";
        String updateQuery = "UPDATE book SET book_title = ?, author = ?, genre = ?, publicationYear = ?, availability = ? WHERE book_id = ?";

        try (PreparedStatement selectStmt = connection.prepareStatement(selectQuery);
                PreparedStatement updateStmt = connection.prepareStatement(updateQuery);) {

            selectStmt.setString(1, bookId);
            try (ResultSet rs = selectStmt.executeQuery()) {

                if (!rs.next()) {
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Book with ID '" + bookId + "' not found.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    return;
                }

                clear();
                // Show current data
                String currentTitle = rs.getString("book_title");
                String currentAuthor = rs.getString("author");
                String currentGenre = rs.getString("genre");
                int currentYear = rs.getInt("publicationYear");
                boolean currentAvailability = rs.getBoolean("availability");

                System.out.println("                                                       ------------------------------------------");
                System.out.println("                                                      -- C U R R E N T   B O O K   D E T A I L S --");
                System.out.println("                                                       ------------------------------------------");
                System.out.println("                                                            Book Title       : " + currentTitle);
                System.out.println("                                                            Author           : " + currentAuthor);
                System.out.println("                                                            Genre            : " + currentGenre);
                System.out.println("                                                            Publication Year : " + currentYear);
                System.out.println("                                                            Availability     : " + (currentAvailability ? "Available" : "Borrowed"));

                // Get new values (Enter to skip)
                System.out.print("\n                                                        Enter new title [leave blank to keep] > ");
                String title = input.nextLine().trim();
                if (title.isEmpty())
                    title = currentTitle;

                System.out.print("                                                        Enter new author [leave blank to keep] > ");
                String author = input.nextLine().trim();
                if (author.isEmpty())
                    author = currentAuthor;

                System.out.print("                                                        Enter new genre [leave blank to keep] > ");
                String genre = input.nextLine().trim();
                if (genre.isEmpty())
                    genre = currentGenre;

                Book tempBook = new Book();

                int year = currentYear;
                boolean valid;

                do {
                    valid = true;
                    try {
                        System.out.print("                                                        Enter new publication year [leave blank to keep] > ");
                        String yearInput = input.nextLine().trim();

                        if (yearInput.isEmpty()) {
                            year = currentYear;
                        } else {
                            tempBook.setPublicationYear(yearInput);
                            year = Integer.parseInt(yearInput.trim());
                        }

                    } catch (IllegalArgumentException e) {
                        System.out.println("                                                        Error: " + e.getMessage());
                        valid = false;
                    }

                } while (!valid);

                boolean availability;
                while (true) {
                    System.out.print("                                                        Is the book available? [Y/N, leave blank to keep] > ");
                    String availableInput = input.nextLine().trim().toUpperCase();
                    if (availableInput.isEmpty()) {
                        availability = currentAvailability;
                        break;
                    } else if (availableInput.equals("Y")) {
                        availability = true;
                        break;
                    } else if (availableInput.equals("N")) {
                        availability = false;
                        break;
                    } else {
                        System.out.println("\n                                                        Please enter 'Y', 'N', or leave blank.");
                    }
                }

                // Execute update
                updateStmt.setString(1, title);
                updateStmt.setString(2, author);
                updateStmt.setString(3, genre);
                updateStmt.setInt(4, year);
                updateStmt.setBoolean(5, availability);
                updateStmt.setString(6, bookId);

                int updated = updateStmt.executeUpdate();
                if (updated > 0) {
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Book updated successfully!");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                } else {
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Book update failed.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                }
            }

        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Error: Book update failed " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }
    }



    public void deleteBook() {

        clear();
        readBook();

        System.out.println("                                                           --------------------------");
        System.out.println("                                                          --- D E L E T E   B O O K S ---");
        System.out.println("                                                           --------------------------");

        String bookId;

        do {
            System.out.print("                                                Enter the Book ID to delete [Press 0 to cancel] > ");
            bookId = input.nextLine().trim();

            if (bookId.equals("0")) {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Returned to previous menu...");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                return;
            }

            if (bookId.isEmpty()) {        
                System.out.println("                                                You must enter a book ID!\n");
            }

        } while (bookId.isEmpty());

        String selectQuery = "SELECT * FROM book WHERE book_id = ?";
        String deleteQuery = "DELETE FROM book WHERE book_id = ?";

        try (PreparedStatement selectStmt = connection.prepareStatement(selectQuery);
            PreparedStatement deleteStmt = connection.prepareStatement(deleteQuery)) {

            selectStmt.setString(1, bookId);
            ResultSet rs = selectStmt.executeQuery();

            if (!rs.next()) {
                clear();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("  Book with ID " + bookId + " not found.");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                return;
            }

            clear();

            // Show the book details before delete
            String bookTitle = rs.getString("book_title");
            String author = rs.getString("author");
            String genre = rs.getString("genre");
            int publicationYear = rs.getInt("publicationYear");
            boolean availability = rs.getBoolean("availability");

            System.out.println("                                                           --------------------------");
            System.out.println("                                                          --- B O O K   D E T A I L S ---");
            System.out.println("                                                           --------------------------");
            System.out.println(" ");
            System.out.println("                                                            Book Title       : " + bookTitle);
            System.out.println("                                                            Author           : " + author);
            System.out.println("                                                            Genre            : " + genre);
            System.out.println("                                                            Publication Year : " + publicationYear);
            System.out.println("                                                            Availability     : " + (availability ? "Available" : "Borrowed"));

            String choice;
            do {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.print("                                                             Delete this book? [Y/N] > ");
                choice = input.nextLine().trim().toUpperCase();

                if (choice.equals("Y")) {
                    deleteStmt.setString(1, bookId);
                    int rowsAffected = deleteStmt.executeUpdate();

                    if (rowsAffected > 0) {
                        clear();
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Book with ID '" + bookId + "' has been successfully deleted.");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    } else {
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("  Failed to delete the book.");
                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    }
                    break;

                } else if (choice.equals("N")) {
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(" Book deletion cancelled.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
                } else {
                    System.out.println("                                                             Invalid input! Please enter 'Y' or 'N'.");
                }

            } while (true);

        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Error: Unable to delete book. " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }
    }



    private String generateBookId() {

        String nextId = "B001";
        String query = "SELECT book_id FROM book ORDER BY book_id DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                String lastId = rs.getString("book_id");
                int num = Integer.parseInt(lastId.substring(1));
                num++;
                nextId = String.format("B%03d", num);
            }

        } catch (SQLException e) {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("  Error: Failed to generate new book ID " + e.getMessage());
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }

        return nextId;
    }

    public void displayBookMenu() {
        System.out.println(" ");
        System.out.println("                                                          -------------------------------------------------");
        System.out.println("                                                         | --  B O O K   M A N A G E M E N T   M E N U  -- |");
        System.out.println("                                                          -------------------------------------------------");
        System.out.println(" ");
        System.out.println("                                                              ----------------------------------------");
        System.out.println("                                                             |          [1] Create Books              |");
        System.out.println("                                                             |          [2] Browse Books              |");
        System.out.println("                                                             |          [3] Update Books              |");
        System.out.println("                                                             |          [4] Remove Books              |");
        System.out.println("                                                             |          [5] Return to previous menu   |");
        System.out.println("                                                              ----------------------------------------");
        System.out.println(" ");
        System.out.print("                                                                       Enter your choice [1-5] > ");
    }

    public void clear() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

}
