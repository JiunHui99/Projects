package BookManagementModule;

import java.time.LocalDate;

public class Book {

    private String bookId;
    private String bookTitle;
    private String author;
    private String genre;
    private int publicationYear;
    private boolean availability;

    public Book() {
        this("", "", "", "", 0, false);
    }

    public Book(String bookId, String bookTitle, String author, String genre,  int publicationYear, boolean availability) {

        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.genre = genre;
        this.author = author;
        this.publicationYear = publicationYear;
        this.availability = availability;
    }

    // Getters & Setters
    public String getBookId() {
        return bookId;
    }
    
    public String getBookTitle() {
        return bookTitle;
    }
    
    public String getGenre() {
        return genre;
    }
    
    public String getAuthor() {
        return author;
    }
    
    public int getPublicationYear() {
        return publicationYear;
    }
    
    public boolean isAvailable() {
        return availability;
    }

    // SETTER
    public void setBookId(String bookId) {
        this.bookId = bookId;
    }
    
    public void setBookTitle(String bookTitle) {
        if (bookTitle == null || bookTitle.trim().isEmpty()) {
            throw new IllegalArgumentException("Book title cannot be empty!\n");
        }

        if (bookTitle.length() < 5 || bookTitle.length() > 100) {
            throw new IllegalArgumentException("Book title must be between 5 and 100 characters long!\n");
        }

        this.bookTitle = bookTitle;
    }
    
    public void setAuthor(String author) {
        if (author == null || author.trim().isEmpty()) {
            throw new IllegalArgumentException("Author name cannot be empty!\n");
        }

        if (!author.matches("[a-zA-Z ]+")) {
            throw new IllegalArgumentException("Author name can only contain alphabet!\n");
        }

        if (author.length() < 5 || author.length() > 30) {
            throw new IllegalArgumentException("Author name must be between 5 and 30 characters long!\n");
        }

        this.author = author;
    }

    public void setGenre(String genre) {
        if (genre == null || genre.trim().isEmpty()) {
            throw new IllegalArgumentException("Book genre cannot be empty!\n");
        }

        if (!genre.matches("[a-zA-Z \\-\\&'/]+")) {
            throw new IllegalArgumentException("Genre can only contain alphabet!\n");
        }

        if (genre.length() < 5 || genre.length() > 30) {
            throw new IllegalArgumentException("Book genre must be between 5 and 30 characters long!\n");
        }

        this.genre = genre;
    }
    
    public void setPublicationYear(String yearInput) {
        
        if (yearInput == null || yearInput.trim().isEmpty()) {
            throw new IllegalArgumentException("Publication year cannot be empty!\n");
        }

        try {
            int year = Integer.parseInt(yearInput.trim());
            int currentYear = LocalDate.now().getYear();

            if (year < 1500 || year > currentYear) {
                throw new IllegalArgumentException("Publication year must be between 1500 and " + currentYear + ".\n");
            }

            this.publicationYear = year;

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid input! Publication year must be a valid number.\n");
        }
    }
    
    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    @Override
    public String toString() {
        return String.format("%-10s %-50s %-30s %-20s %-10d %-5s",
            bookId,
            bookTitle,
            author,
            genre,
            publicationYear,
            availability ? "Available" : "Borrowed"
        );
    }
}
