package Main;

import UserManagementModule.*;
import java.util.Scanner;

public class SystemMain {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        int mainChoice = 0;
        clear();

        do {
            displayMain();

            while (!input.hasNextInt()) {
                clear();
                System.out.println("                           Invalid input! Please enter a number between 1 and 3.\n");
                input.next();
                displayMain();
            }

            mainChoice = input.nextInt();
            input.nextLine();

            switch (mainChoice) {

                case 1:
                    clear();
                    System.out.println("   ----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("    Member Role Selected!"                                                         );
                    System.out.println("   ----------------------------------------------------------------------------------------------------------------------------------------");

                    memberController memberController = new memberController();
                    memberController.memberAccessMenu();
                    break;

                case 2:
                    clear();
                    System.out.println("   ----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("    Staff Role Selected!");
                    System.out.println("   ----------------------------------------------------------------------------------------------------------------------------------------");

                    staffController staffController = new staffController();
                    staffController.staffAccessMenu();
                    break;
            
                case 3:
                    clear();
                    System.out.println("   ----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("    Thank you for using Library Management System. Goodbye!");
                    System.out.println("   ----------------------------------------------------------------------------------------------------------------------------------------");

                    break;

                default:
                    clear();
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("  Invalid choice! Please select a number between 1 and 3.");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
            }

        } while (mainChoice != 3);
            
        input.close();
    }

    public static void displayMain() {

        System.out.println(" ");
        System.out.println("                                                          -----------------------------------------------------------");
        System.out.println("                                                         |                                                           | ");
        System.out.println("                                                         | --  L I B R A R Y   M A N A G E M E N T   S Y S T E M  -- |");
        System.out.println("                                                         |                                                           | ");
        System.out.println("                                                          ----------------------------------------------------------");
        System.out.println(" ");
        System.out.println("                                                             [1] Member");
        System.out.println("                                                             [2] Staff");
        System.out.println("                                                             [3] Exit Program");
        System.out.println(" ");
        System.out.print("                                                             Enter your choice [1-3] > ");
;
    }

    public static void clear() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}
